package com.example.yandexmusichud.lyrics;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.lyrics.LyricLine;
import net.minecraft.class_243;
import org.joml.Quaternionf;

public class SubtitleBubble {
    public final LyricLine line;
    public final long spawnSystemTimeMs;
    public float screenX;
    public float screenY;
    public class_243 worldPos;
    public Quaternionf worldRot;
    public boolean isSurfaceAttached = false;
    public boolean isFastPaced = false;

    public SubtitleBubble(LyricLine line, float screenX, float screenY) {
        this(line, screenX, screenY, false);
    }

    public SubtitleBubble(LyricLine line, float screenX, float screenY, boolean isFastPaced) {
        this.line = line;
        this.spawnSystemTimeMs = System.currentTimeMillis();
        this.screenX = screenX;
        this.screenY = screenY;
        this.isFastPaced = isFastPaced;
    }

    public SubtitleBubble(LyricLine line, class_243 worldPos, Quaternionf worldRot) {
        this(line, worldPos, worldRot, false, false);
    }

    public SubtitleBubble(LyricLine line, class_243 worldPos, Quaternionf worldRot, boolean isSurfaceAttached) {
        this(line, worldPos, worldRot, isSurfaceAttached, false);
    }

    public SubtitleBubble(LyricLine line, class_243 worldPos, Quaternionf worldRot, boolean isSurfaceAttached, boolean isFastPaced) {
        this.line = line;
        this.spawnSystemTimeMs = System.currentTimeMillis();
        this.worldPos = worldPos;
        this.worldRot = worldRot;
        this.isSurfaceAttached = isSurfaceAttached;
        this.isFastPaced = isFastPaced;
    }

    public float getScale(long currentTimeMs) {
        long age;
        String anim = HudConfig.INSTANCE.subtitlesAnimation;
        if (anim == null) {
            anim = "KARAOKE_BOUNCE";
        }
        if ((age = currentTimeMs - this.spawnSystemTimeMs) < 0L) {
            return 0.0f;
        }
        if (this.isFastPaced) {
            if (age < 60L) {
                float t = (float)age / 60.0f;
                return 0.85f + 0.18f * SubtitleBubble.easeOutBack(t);
            }
            return 1.0f;
        }
        switch (anim.toUpperCase()) {
            case "ELASTIC_POP": {
                if (age < 450L) {
                    float t = (float)age / 450.0f;
                    return 0.5f + 0.5f * (1.0f + 0.75f * (float)(Math.sin((double)t * Math.PI * 2.5) * Math.exp((double)(-t) * 3.5)));
                }
                return 1.0f;
            }
            case "WAVE_FLOAT": {
                float base = age < 300L ? 0.7f + 0.3f * SubtitleBubble.easeOutCubic((float)age / 300.0f) : 1.0f;
                return base + 0.035f * (float)Math.sin((double)(currentTimeMs - this.spawnSystemTimeMs) / 380.0);
            }
            case "SLIDE_FADE": {
                if (age < 280L) {
                    return 0.82f + 0.18f * SubtitleBubble.easeOutCubic((float)age / 280.0f);
                }
                return 1.0f;
            }
            case "PULSE_GLOW": {
                float base = age < 220L ? (float)age / 220.0f : 1.0f;
                return base + 0.045f * (float)Math.sin((double)(currentTimeMs - this.spawnSystemTimeMs) / 180.0);
            }
            case "CLASSIC": {
                if (age < 180L) {
                    return (float)age / 180.0f;
                }
                return 1.0f;
            }
        }
        if (age < 320L) {
            float t = (float)age / 320.0f;
            return 0.88f + 0.12f * SubtitleBubble.easeOutCubic(t);
        }
        return 1.0f;
    }

    public float getOffsetX(long currentTimeMs) {
        if (this.isFastPaced) {
            return 0.0f;
        }
        String anim = HudConfig.INSTANCE.subtitlesAnimation;
        long age = currentTimeMs - this.spawnSystemTimeMs;
        float drift = (float)Math.cos((double)(currentTimeMs - this.spawnSystemTimeMs) / 840.0) * 1.0f;
        if ("SLIDE_FADE".equalsIgnoreCase(anim)) {
            if (age < 320L) {
                float t = (float)age / 320.0f;
                return -28.0f * (1.0f - t * t * t) + drift;
            }
        } else if ("WAVE_FLOAT".equalsIgnoreCase(anim)) {
            return (float)Math.sin((double)(currentTimeMs - this.spawnSystemTimeMs) / 600.0) * 2.5f + drift;
        }
        return drift;
    }

    public float getOffsetY(long currentTimeMs) {
        float t;
        String anim = HudConfig.INSTANCE.subtitlesAnimation;
        long age = currentTimeMs - this.spawnSystemTimeMs;
        float breath = (float)Math.sin((double)(currentTimeMs - this.spawnSystemTimeMs) / 520.0) * 1.8f;
        float kineticEntry = 0.0f;
        if (this.isFastPaced) {
            if (age < 60L) {
                float t2 = (float)age / 60.0f;
                kineticEntry = 3.0f * (1.0f - t2 * t2);
            }
            return kineticEntry;
        }
        if (age < 320L) {
            t = (float)age / 320.0f;
            kineticEntry = 10.0f * (1.0f - SubtitleBubble.easeOutCubic(t));
        }
        if ("WAVE_FLOAT".equalsIgnoreCase(anim)) {
            return (float)Math.sin((double)(currentTimeMs - this.spawnSystemTimeMs) / 320.0) * 3.5f + breath + kineticEntry;
        }
        if ("SLIDE_FADE".equalsIgnoreCase(anim) && age < 280L) {
            t = (float)age / 280.0f;
            return 10.0f * (1.0f - t * t) + breath;
        }
        return breath + kineticEntry;
    }

    public float getExitOffsetY(long trackPosMs) {
        if (trackPosMs > this.line.endMs) {
            long overtime = trackPosMs - this.line.endMs;
            float t = Math.min(1.0f, (float)overtime / (this.isFastPaced ? 140.0f : 400.0f));
            return (this.isFastPaced ? -5.0f : -12.0f) * SubtitleBubble.easeOutCubic(t);
        }
        return 0.0f;
    }

    public float getOverallAlpha(long trackPosMs, long currentTimeMs) {
        long ageSystem = currentTimeMs - this.spawnSystemTimeMs;
        if (ageSystem < 0L) {
            return 0.0f;
        }
        long fadeDur = this.isFastPaced ? 45L : 250L;
        float sysAlpha = 1.0f;
        if (ageSystem < fadeDur) {
            sysAlpha = (float)ageSystem / (float)fadeDur;
        }
        if (trackPosMs > this.line.endMs) {
            long overtime = trackPosMs - this.line.endMs;
            long fadeOutDur = this.isFastPaced ? 140L : 600L;
            if (overtime >= fadeOutDur) {
                return 0.0f;
            }
            float fadeOut = 1.0f - (float)overtime / (float)fadeOutDur;
            return sysAlpha * fadeOut;
        }
        return sysAlpha;
    }

    public boolean isExpired(long trackPosMs, long currentTimeMs) {
        long expireBuffer = this.isFastPaced ? 150L : 600L;
        if (trackPosMs > this.line.endMs + expireBuffer) {
            return true;
        }
        long maxAge = this.isFastPaced ? 2500L : 10000L;
        return currentTimeMs - this.spawnSystemTimeMs > maxAge;
    }

    private static float easeOutBack(float t) {
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        return 1.0f + c3 * (float)Math.pow(t - 1.0f, 3.0) + c1 * (float)Math.pow(t - 1.0f, 2.0);
    }

    private static float easeOutCubic(float t) {
        float f = t - 1.0f;
        return f * f * f + 1.0f;
    }
}

