package com.example.yandexmusichud.hud;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.hud.ColorWheelWidget;
import com.example.yandexmusichud.hud.FavoritesScreen;
import com.example.yandexmusichud.hud.KeybindSetupScreen;
import com.example.yandexmusichud.hud.ModernButtonWidget;
import com.example.yandexmusichud.hud.ModernSliderWidget;
import com.example.yandexmusichud.hud.MusicHudRenderer;
import com.example.yandexmusichud.hud.NiaAuthorScreen;
import com.example.yandexmusichud.hud.NiaFoxMaidModel;
import com.example.yandexmusichud.hud.SystemDiagnosticsScreen;
import com.example.yandexmusichud.network.NowPlayingClient;
import com.example.yandexmusichud.network.TrackState;
import com.example.yandexmusichud.stats.SessionStatsManager;
import com.example.yandexmusichud.texture.CustomBackgroundManager;
import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.function.Supplier;
import net.minecraft.class_1068;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_5605;
import net.minecraft.class_5609;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7920;
import net.minecraft.class_8685;
import org.lwjgl.glfw.GLFW;

public class HudEditScreen
extends class_437 {
    private static final class_2960 TWITCH_ICON = class_2960.method_60655("yandexmusichud", "textures/gui/twitch_icon.png");
    private boolean dragging = false;
    private int dragOffsetX;
    private int dragOffsetY;
    private boolean dragging2DSub = false;
    private int dragSubOffsetX;
    private int dragSubOffsetY;
    private int subPreviewW = 180;
    private int subPreviewH = 26;
    private int hudX;
    private int hudY;
    private int hudWidth;
    private int hudHeight;
    private int panelX = 14;
    private int panelY = 14;
    private int panelWidth = 310;
    private int panelHeight = 264;
    private int helpX = 336;
    private int helpY = 14;
    private int helpWidth = 280;
    private int helpHeight = 264;
    private int currentTab = 0;
    private float tabIndicatorX = -1.0f;
    private float tabIndicatorW = -1.0f;
    private long tabSwitchStartTime = 0L;
    private long lastFrameTime = 0L;
    private int paletteTarget = 0;
    private ColorWheelWidget paletteColorWheel;
    private List<String> availablePngBackgrounds = List.of();
    private String feedbackToast = null;
    private long feedbackToastTime = 0L;
    private int feedbackColor = 58879;
    private boolean alertSoundPlayed = false;
    private final List<EasterEggParticle> easterEggParticles = new ArrayList<EasterEggParticle>();
    private int niaEasterEggClicks = 0;
    private long lastNiaClickTime = 0L;
    private final List<HelpEntry> helpEntries = new ArrayList<HelpEntry>();
    private final class_437 parent;
    private class_591 playerModel;
    private Supplier<class_8685> skinTexturesSupplier = null;
    private boolean isPlayerSlim = false;

    private void ensurePlayerModel() {
        class_310 mc;
        class_310 class_3102 = mc = this.field_22787 != null ? this.field_22787 : class_310.method_1551();
        if (mc == null) {
            return;
        }
        boolean slim = false;
        if (mc.field_1724 != null) {
            try {
                class_8685 st = mc.field_1724.method_52814();
                if (st != null) {
                    slim = st.comp_1629() == class_7920.field_41122;
                }
            }
            catch (Throwable ignored) {}
        } else {
            if (this.skinTexturesSupplier == null && mc.method_53462() != null) {
                this.skinTexturesSupplier = mc.method_1582().method_73544(mc.method_53462(), false);
            }
            if (this.skinTexturesSupplier != null && this.skinTexturesSupplier.get() != null) {
                class_8685 st = this.skinTexturesSupplier.get();
                if (st != null) {
                    slim = st.comp_1629() == class_7920.field_41122;
                }
            }
        }
        if (this.playerModel != null && this.isPlayerSlim == slim) {
            return;
        }
        this.isPlayerSlim = slim;
        try {
            class_5609 modelData = class_591.method_32028((class_5605)class_5605.field_27715, (boolean)slim);
            class_630 rootPart = modelData.method_32111().method_32112(64, 64);
            this.playerModel = new class_591(rootPart, slim);
            this.playerModel.method_2805(true);
        }
        catch (Throwable t) {
            try {
                this.playerModel = NiaFoxMaidModel.createPlayerModel();
                this.playerModel.method_2805(true);
            }
            catch (Throwable throwable) {

            }
        }
    }

    public HudEditScreen() {
        this(null);
    }

    public HudEditScreen(class_437 parent) {
        super((class_2561)class_2561.method_43470((String)"\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"));
        this.parent = parent;
    }

    protected void method_25426() {
        super.method_25426();
        this.refreshBackgroundList();
        this.recalculateHudDimensions();
        this.hudX = HudConfig.INSTANCE.getAbsoluteX(this.field_22789, this.hudWidth);
        this.hudY = HudConfig.INSTANCE.getAbsoluteY(this.field_22790, this.hudHeight);
        this.hudX = Math.max(0, Math.min(this.hudX, this.field_22789 - this.hudWidth));
        this.hudY = Math.max(0, Math.min(this.hudY, this.field_22790 - this.hudHeight));
        this.panelX = 14;
        this.panelWidth = Math.min(310, this.field_22789 - 28);
        this.panelHeight = Math.min(264, this.field_22790 - 28);
        this.panelY = Math.max(14, (this.field_22790 - this.panelHeight) / 2);
        if (this.field_22789 >= 640) {
            this.helpX = this.panelX + this.panelWidth + 12;
            this.helpWidth = Math.min(290, this.field_22789 - this.helpX - 14);
            this.helpY = this.panelY;
            this.helpHeight = this.panelHeight;
        } else if (this.currentTab == 2) {
            this.helpX = this.panelX + 10;
            this.helpWidth = this.panelWidth - 20;
            this.helpY = this.panelY + 26;
            this.helpHeight = this.panelHeight - 34;
        }
        this.initColorWheels();
        this.buildTabWidgets();
    }

    private void initColorWheels() {
        int contentX = this.panelX + 10;
        int contentY = this.panelY + 48;
        int initialRgb = this.getCurrentTargetColor();
        this.paletteColorWheel = new ColorWheelWidget(contentX + 6, contentY + 34, 82, initialRgb, rgb -> {
            this.setCurrentTargetColor((int)rgb);
            HudConfig.save();
        });
    }

    private int getCurrentTargetColor() {
        return switch (this.paletteTarget) {
            case 0 -> HudConfig.INSTANCE.hudBackgroundColor;
            case 1 -> HudConfig.INSTANCE.progressBarColor;
            case 2 -> HudConfig.INSTANCE.subtitlesColor;
            case 3 -> HudConfig.INSTANCE.subtitlesBgColor;
            case 4 -> HudConfig.INSTANCE.subtitlesActiveColor;
            default -> 0xFFFFFF;
        };
    }

    private void setCurrentTargetColor(int rgb) {
        switch (this.paletteTarget) {
            case 0: {
                HudConfig.INSTANCE.hudBackgroundColor = rgb;
                break;
            }
            case 1: {
                HudConfig.INSTANCE.progressBarColor = rgb;
                break;
            }
            case 2: {
                HudConfig.INSTANCE.subtitlesColor = rgb;
                break;
            }
            case 3: {
                HudConfig.INSTANCE.subtitlesBgColor = rgb;
                break;
            }
            case 4: {
                HudConfig.INSTANCE.subtitlesActiveColor = rgb;
            }
        }
    }

    private void refreshBackgroundList() {
        this.availablePngBackgrounds = CustomBackgroundManager.INSTANCE.getAvailableBackgrounds();
    }

    private void recalculateHudDimensions() {
        float scale = class_3532.method_15363((float)HudConfig.INSTANCE.hudScale, (float)0.2f, (float)4.0f);
        this.hudWidth = (int)((float)HudConfig.INSTANCE.getHudBaseWidth() * scale);
        this.hudHeight = (int)((float)HudConfig.INSTANCE.getHudBaseHeight() * scale);
    }

    private void registerHelp(int x, int y, int w, int h, String title, String desc, String rec) {
        this.helpEntries.add(new HelpEntry(x, y, w, h, title, desc, rec));
    }

    private void buildTabWidgets() {
        this.method_37067();
        this.helpEntries.clear();
        this.registerHelp(this.panelX + 8, this.panelY + 4, 12, 14, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c", "\u0417\u0430\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 (ESC).", "\u0412\u0441\u0435 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u044e\u0442\u0441\u044f \u0441\u0440\u0430\u0437\u0443.");
        this.registerHelp(this.panelX + 20, this.panelY + 4, 12, 14, "\u041f\u043e\u0434\u0441\u043a\u0430\u0437\u043a\u0438", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0438\u043b\u0438 \u0441\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043e\u043a\u043d\u043e \u043f\u043e\u0434\u0441\u043a\u0430\u0437\u043e\u043a \u0441\u043f\u0440\u0430\u0432\u0430.", "\u041f\u043e\u043b\u0435\u0437\u043d\u043e \u043f\u0440\u0438 \u043f\u0435\u0440\u0432\u043e\u0439 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0435.");
        this.registerHelp(this.panelX + 32, this.panelY + 4, 12, 14, "\u0421\u0431\u0440\u043e\u0441 \u0432\u043a\u043b\u0430\u0434\u043a\u0438", "\u0421\u0431\u0440\u0430\u0441\u044b\u0432\u0430\u0435\u0442 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0442\u0435\u043a\u0443\u0449\u0435\u0439 \u0432\u043a\u043b\u0430\u0434\u043a\u0438.", "\u0411\u044b\u0441\u0442\u0440\u044b\u0439 \u0432\u043e\u0437\u0432\u0440\u0430\u0442 \u043a \u0431\u0430\u0437\u043e\u0432\u043e\u043c\u0443 \u0432\u0438\u0434\u0443.");
        this.registerHelp(this.panelX + 48, this.panelY + 4, 18, 14, "\u041e\u0431 \u0430\u0432\u0442\u043e\u0440\u0435 (\u041d\u0438\u044f)", "\u041a\u0430\u0440\u0442\u043e\u0447\u043a\u0430 \u0430\u0432\u0442\u043e\u0440\u0430 \u043c\u043e\u0434\u0430 \u2014 \u041d\u0438\u0438 (Nia_Teppelin_0).", "\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0434\u043b\u044f \u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0430 3D-\u043c\u043e\u0434\u0435\u043b\u044c\u043a\u0438. \ud83c\udf38");
        int masterW = 44;
        int masterH = 15;
        int masterX = this.panelX + this.panelWidth - masterW - 8;
        int masterY = this.panelY + 5;
        ModernButtonWidget masterBtn = new ModernButtonWidget(masterX, masterY, masterW, masterH, (class_2561)class_2561.method_43470((String)(HudConfig.INSTANCE.enabled ? "\u00a7a\u25cf \u0412\u041a\u041b" : "\u00a7c\u25cb \u0412\u042b\u041a\u041b")), b -> {
            HudConfig.INSTANCE.enabled = !HudConfig.INSTANCE.enabled;
            b.method_25355((class_2561)class_2561.method_43470((String)(HudConfig.INSTANCE.enabled ? "\u00a7a\u25cf \u0412\u041a\u041b" : "\u00a7c\u25cb \u0412\u042b\u041a\u041b")));
            b.setCustomBgColor(HudConfig.INSTANCE.enabled ? -585408992 : -578093056);
            HudConfig.save();
            this.triggerFeedback(HudConfig.INSTANCE.enabled ? "\u00a7a\u25cf \u041c\u043e\u0434 \u0432\u043a\u043b\u044e\u0447\u0435\u043d" : "\u00a7c\u25cb \u041c\u043e\u0434 \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d", HudConfig.INSTANCE.enabled ? 58879 : 0xFF5F56);
        });
        masterBtn.setCustomBgColor(HudConfig.INSTANCE.enabled ? -585408992 : -578093056);
        this.method_37063(masterBtn);
        this.registerHelp(masterX, masterY, masterW, masterH, "\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043c\u043e\u0434\u0430", "\u041f\u043e\u043b\u043d\u043e\u0435 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u0438\u043b\u0438 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043c\u043e\u0434\u0430.", "\u0412\u041a\u041b \u0434\u043b\u044f \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f \u043c\u0443\u0437\u044b\u043a\u0438 \u0432 \u0438\u0433\u0440\u0435.");
        int helpBtnW = 16;
        int helpBtnX = masterX - helpBtnW - 4;
        ModernButtonWidget helpBtn = new ModernButtonWidget(helpBtnX, masterY, helpBtnW, masterH, (class_2561)class_2561.method_43470((String)(HudConfig.INSTANCE.showHelpInspector ? "\u00a7b\u2139" : "\u00a77\u2139")), b -> {
            HudConfig.INSTANCE.showHelpInspector = !HudConfig.INSTANCE.showHelpInspector;
            b.method_25355((class_2561)class_2561.method_43470((String)(HudConfig.INSTANCE.showHelpInspector ? "\u00a7b\u2139" : "\u00a77\u2139")));
            b.setCustomBgColor(HudConfig.INSTANCE.showHelpInspector ? 1426094847 : 0x3322222E);
            HudConfig.save();
            this.triggerFeedback(HudConfig.INSTANCE.showHelpInspector ? "\u00a7b\u2139 \u041e\u043a\u043d\u043e \u0441\u043f\u0440\u0430\u0432\u043a\u0438: \u0412\u041a\u041b" : "\u00a77\u2139 \u041e\u043a\u043d\u043e \u0441\u043f\u0440\u0430\u0432\u043a\u0438: \u0412\u042b\u041a\u041b", 58879);
        });
        helpBtn.setCustomBgColor(HudConfig.INSTANCE.showHelpInspector ? 1426094847 : 0x3322222E);
        this.method_37063(helpBtn);
        this.registerHelp(helpBtnX, masterY, helpBtnW, masterH, "\u041e\u043a\u043d\u043e \u043f\u043e\u0434\u0441\u043a\u0430\u0437\u043e\u043a", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0438\u043b\u0438 \u0441\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043f\u0430\u043d\u0435\u043b\u044c \u043f\u043e\u0434\u0441\u043a\u0430\u0437\u043e\u043a \u0441\u043f\u0440\u0430\u0432\u0430.", "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0432\u0438\u0434\u0435\u0442\u044c \u0438\u043d\u0444\u043e \u043e \u043a\u043d\u043e\u043f\u043a\u0430\u0445.");
        int keyBtnW = 16;
        int keyBtnX = helpBtnX - keyBtnW - 4;
        ModernButtonWidget keyBtn = new ModernButtonWidget(keyBtnX, masterY, keyBtnW, masterH, (class_2561)class_2561.method_43470((String)"\u00a7e\u2328"), b -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507((class_437)new KeybindSetupScreen(this));
            }
        });
        keyBtn.setCustomBgColor(0x3322222E);
        this.method_37063(keyBtn);
        this.registerHelp(keyBtnX, masterY, keyBtnW, masterH, "\u0413\u043e\u0440\u044f\u0447\u0438\u0435 \u043a\u043b\u0430\u0432\u0438\u0448\u0438", "\u042d\u043a\u0440\u0430\u043d \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043a\u043b\u0430\u0432\u0438\u0448 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u044f \u043c\u0443\u0437\u044b\u043a\u043e\u0439.", "\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0434\u043b\u044f \u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f \u043a\u043d\u043e\u043f\u043e\u043a.");
        int diagBtnW = 16;
        int diagBtnX = keyBtnX - diagBtnW - 4;
        ModernButtonWidget diagBtn = new ModernButtonWidget(diagBtnX, masterY, diagBtnW, masterH, (class_2561)class_2561.method_43470((String)"\u00a7b\ud83e\ude7a"), b -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507((class_437)new SystemDiagnosticsScreen(this, new KeybindSetupScreen(this)));
            }
        });
        diagBtn.setCustomBgColor(0x3322222E);
        this.method_37063(diagBtn);
        this.registerHelp(diagBtnX, masterY, diagBtnW, masterH, "\u0414\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0430", "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0441\u0432\u044f\u0437\u0438 \u0441\u043e \u0441\u043b\u0443\u0436\u0431\u043e\u0439 Windows \u0438 \u043f\u043b\u0435\u0435\u0440\u043e\u043c.", "\u041d\u0430\u0436\u043c\u0438\u0442\u0435, \u0435\u0441\u043b\u0438 \u0442\u0440\u0435\u043a \u043d\u0435 \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0451\u0442\u0441\u044f.");
        int twitchBtnW = 16;
        int twitchBtnX = diagBtnX - twitchBtnW - 4;
        ModernButtonWidget twitchBtn = new ModernButtonWidget(twitchBtnX, masterY, twitchBtnW, masterH, (class_2561)class_2561.method_43470(""), b -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507((class_437)new TwitchSettingsScreen(this));
            }
        });
        twitchBtn.setIconTexture(TWITCH_ICON, 10);
        twitchBtn.setCustomBgColor(HudConfig.INSTANCE.twitchEnabled ? 0x559146FF : 0x3322222E);
        this.method_37063(twitchBtn);
        this.registerHelp(twitchBtnX, masterY, twitchBtnW, masterH, "Twitch \u0418\u043d\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044f", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0441\u0442\u0440\u0438\u043c\u0430, \u043f\u043b\u0430\u0448\u0435\u043a \u0441\u0430\u0431\u043e\u0432 \u0438 \u043d\u0430\u0433\u0440\u0430\u0434.", "\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0434\u043b\u044f \u043e\u0442\u043a\u0440\u044b\u0442\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a Twitch.");
        this.registerHelp(this.panelX + 48, this.panelY + 4, 18, 14, "\u0418\u043d\u0434\u0438\u043a\u0430\u0442\u043e\u0440 \u043c\u0443\u0437\u044b\u043a\u0438", "\u041f\u0443\u043b\u044c\u0441\u0438\u0440\u0443\u0435\u0442 \u0432 \u0440\u0438\u0442\u043c \u0431\u0430\u0441\u043e\u0432 \u0438\u0433\u0440\u0430\u044e\u0449\u0435\u0433\u043e \u0442\u0440\u0435\u043a\u0430.", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0430\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u044c \u0430\u0443\u0434\u0438\u043e\u043f\u043e\u0442\u043e\u043a\u0430.");
        int eqHelpX = this.panelX + 48 + 18 + this.field_22793.method_1727("Music Subtitles") + 5;
        int eqHelpW = Math.max(16, twitchBtnX - 5 - eqHelpX);
        this.registerHelp(eqHelpX, this.panelY + 4, eqHelpW, 14, "\u042d\u043a\u0432\u0430\u043b\u0430\u0439\u0437\u0435\u0440", "\u0410\u043d\u0438\u043c\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u043f\u043e\u043b\u043e\u0441\u044b \u0432 \u0442\u0430\u043a\u0442 \u043c\u0443\u0437\u044b\u043a\u0435.", "\u0414\u0432\u0438\u0433\u0430\u044e\u0442\u0441\u044f \u0432 \u0440\u0438\u0442\u043c\u0435 \u0442\u0435\u043a\u0443\u0449\u0435\u0433\u043e \u0442\u0440\u0435\u043a\u0430.");
        int tabY = this.panelY + 24;
        int tabH = 19;
        int tabW = (this.panelWidth - 16 - 12) / 5;
        ModernButtonWidget tab0 = new ModernButtonWidget(this.panelX + 8, tabY, tabW, tabH, (class_2561)class_2561.method_43470((String)"\u0412\u0438\u0434\u0436\u0435\u0442"), b -> {
            if (this.currentTab != 0) {
                this.currentTab = 0;
                this.tabSwitchStartTime = System.currentTimeMillis();
                this.buildTabWidgets();
                this.triggerFeedback("\u0412\u043a\u043b\u0430\u0434\u043a\u0430: \u00a7b\u0412\u0438\u0434\u0436\u0435\u0442 HUD", 58879);
            }
        });
        tab0.setPrimary(this.currentTab == 0);
        this.method_37063(tab0);
        this.registerHelp(tab0.method_46426(), tab0.method_46427(), tab0.method_25368(), tab0.method_25364(), "\u0412\u043a\u043b\u0430\u0434\u043a\u0430 \u00ab\u0412\u0438\u0434\u0436\u0435\u0442\u00bb", "\u0412\u043d\u0435\u0448\u043d\u0438\u0439 \u0432\u0438\u0434 \u0438 \u0440\u0430\u0437\u043c\u0435\u0440 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u0442\u0440\u0435\u043a\u0430.", "\u041e\u0441\u043d\u043e\u0432\u043d\u044b\u0435 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u043f\u043b\u0435\u0435\u0440\u0430.");
        ModernButtonWidget tab1 = new ModernButtonWidget(this.panelX + 8 + tabW + 3, tabY, tabW, tabH, (class_2561)class_2561.method_43470((String)"\u0422\u0435\u043a\u0441\u0442"), b -> {
            if (this.currentTab != 1) {
                this.currentTab = 1;
                this.tabSwitchStartTime = System.currentTimeMillis();
                this.buildTabWidgets();
                this.triggerFeedback("\u0412\u043a\u043b\u0430\u0434\u043a\u0430: \u00a7b\u0421\u0443\u0431\u0442\u0438\u0442\u0440\u044b", 58879);
            }
        });
        tab1.setPrimary(this.currentTab == 1);
        this.method_37063(tab1);
        this.registerHelp(tab1.method_46426(), tab1.method_46427(), tab1.method_25368(), tab1.method_25364(), "\u0412\u043a\u043b\u0430\u0434\u043a\u0430 \u00ab\u0421\u0443\u0431\u0442\u0438\u0442\u0440\u044b\u00bb", "\u041e\u0442\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u0435 \u0442\u0435\u043a\u0441\u0442\u0430 \u043f\u0435\u0441\u0435\u043d \u0438 \u0440\u0435\u0447\u0438.", "\u0412\u044b\u0431\u043e\u0440 2D/3D \u0440\u0435\u0436\u0438\u043c\u0430 \u0438 \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0439.");
        ModernButtonWidget tab2 = new ModernButtonWidget(this.panelX + 8 + (tabW + 3) * 2, tabY, tabW, tabH, (class_2561)class_2561.method_43470((String)"\u0426\u0432\u0435\u0442"), b -> {
            if (this.currentTab != 2) {
                this.currentTab = 2;
                this.tabSwitchStartTime = System.currentTimeMillis();
                if (this.paletteColorWheel != null) {
                    this.paletteColorWheel.setColorFromRgb(this.getCurrentTargetColor());
                }
                this.buildTabWidgets();
                this.triggerFeedback("\u0412\u043a\u043b\u0430\u0434\u043a\u0430: \u00a7b\u0426\u0432\u0435\u0442\u0430", 58879);
            }
        });
        tab2.setPrimary(this.currentTab == 2);
        this.method_37063(tab2);
        this.registerHelp(tab2.method_46426(), tab2.method_46427(), tab2.method_25368(), tab2.method_25364(), "\u0412\u043a\u043b\u0430\u0434\u043a\u0430 \u00ab\u0426\u0432\u0435\u0442\u0430\u00bb", "\u0412\u044b\u0431\u043e\u0440 \u0446\u0432\u0435\u0442\u043e\u0432 \u0444\u043e\u043d\u0430, \u0442\u0435\u043a\u0441\u0442\u0430 \u0438 \u043f\u043e\u043b\u043e\u0441\u044b.", "\u041a\u0440\u0443\u0433 \u0434\u043b\u044f \u0442\u043e\u0447\u043d\u043e\u0433\u043e \u043f\u043e\u0434\u0431\u043e\u0440\u0430 \u043e\u0442\u0442\u0435\u043d\u043a\u043e\u0432.");
        ModernButtonWidget tab3 = new ModernButtonWidget(this.panelX + 8 + (tabW + 3) * 3, tabY, tabW, tabH, (class_2561)class_2561.method_43470((String)"\u0418\u043d\u0444\u043e"), b -> {
            if (this.currentTab != 3) {
                this.currentTab = 3;
                this.tabSwitchStartTime = System.currentTimeMillis();
                this.buildTabWidgets();
                this.triggerFeedback("\u0412\u043a\u043b\u0430\u0434\u043a\u0430: \u00a7b\u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043a\u0430 \u0438 \u0441\u0435\u0441\u0441\u0438\u044f", 58879);
            }
        });
        tab3.setPrimary(this.currentTab == 3);
        this.method_37063(tab3);
        this.registerHelp(tab3.method_46426(), tab3.method_46427(), tab3.method_25368(), tab3.method_25364(), "\u0412\u043a\u043b\u0430\u0434\u043a\u0430 \u00ab\u0418\u043d\u0444\u043e\u00bb", "\u041c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u0430\u044f \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043a\u0430 \u0441\u0435\u0441\u0441\u0438\u0438 \u0438 3D-\u0441\u043a\u0438\u043d.", "\u0412\u0440\u0435\u043c\u044f, \u0442\u0440\u0435\u043a\u0438 \u0438 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u0437\u0432\u0443\u043a\u043e\u043c.");
        ModernButtonWidget tab4 = new ModernButtonWidget(this.panelX + 8 + (tabW + 3) * 4, tabY, tabW, tabH, (class_2561)class_2561.method_43470((String)"\u2b50"), b -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507((class_437)new FavoritesScreen(this));
            }
        });
        tab4.setCustomBgColor(-869059766);
        this.method_37063(tab4);
        this.registerHelp(tab4.method_46426(), tab4.method_46427(), tab4.method_25368(), tab4.method_25364(), "\u0418\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435", "\u0421\u043f\u0438\u0441\u043e\u043a \u0432\u0430\u0448\u0438\u0445 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0445 \u0442\u0440\u0435\u043a\u043e\u0432.", "\u041f\u0440\u043e\u0441\u043c\u043e\u0442\u0440 \u0438 \u0441\u0441\u044b\u043b\u043a\u0438 \u043d\u0430 \u043f\u0435\u0441\u043d\u0438.");
        int contentX = this.panelX + 10;
        int contentY = this.panelY + 48;
        int colW = (this.panelWidth - 24) / 2;
        if (this.currentTab == 0) {
            boolean isLarge = "LARGE".equalsIgnoreCase(HudConfig.INSTANCE.hudSize);
            ModernButtonWidget btnSize = new ModernButtonWidget(contentX, contentY, colW, 19, (class_2561)class_2561.method_43470((String)("\u0420\u0430\u0437\u043c\u0435\u0440: " + (isLarge ? "\u00a7b\u0411\u043e\u043b\u044c\u0448\u043e\u0439" : "\u00a77\u041a\u043e\u043c\u043f\u0430\u043a\u0442"))), b -> {
                HudConfig.INSTANCE.hudSize = "LARGE".equalsIgnoreCase(HudConfig.INSTANCE.hudSize) ? "COMPACT" : "LARGE";
                this.recalculateHudDimensions();
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnSize);
            this.registerHelp(btnSize.method_46426(), btnSize.method_46427(), btnSize.method_25368(), btnSize.method_25364(), "\u0420\u0430\u0437\u043c\u0435\u0440 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438", "\u041f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043c\u0435\u0436\u0434\u0443 \u0431\u043e\u043b\u044c\u0448\u0438\u043c \u0438 \u043a\u043e\u043c\u043f\u0430\u043a\u0442\u043d\u044b\u043c \u0432\u0438\u0434\u043e\u043c.", "\u0411\u043e\u043b\u044c\u0448\u043e\u0439 \u0441 \u0432\u0438\u043d\u0438\u043b\u043e\u043c \u0438\u043b\u0438 \u0430\u043a\u043a\u0443\u0440\u0430\u0442\u043d\u044b\u0439 \u041a\u043e\u043c\u043f\u0430\u043a\u0442.");
            boolean isPopup = "POPUP".equalsIgnoreCase(HudConfig.INSTANCE.hudDisplayType);
            ModernButtonWidget btnPopup = new ModernButtonWidget(contentX + colW + 4, contentY, colW, 19, (class_2561)class_2561.method_43470((String)("\u041f\u043e\u043a\u0430\u0437: " + (isPopup ? "\u00a7b\u0412\u0441\u043f\u043b\u044b\u0432." : "\u00a7a\u0412\u0441\u0435\u0433\u0434\u0430"))), b -> {
                HudConfig.INSTANCE.hudDisplayType = "POPUP".equalsIgnoreCase(HudConfig.INSTANCE.hudDisplayType) ? "ALWAYS" : "POPUP";
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnPopup);
            this.registerHelp(btnPopup.method_46426(), btnPopup.method_46427(), btnPopup.method_25368(), btnPopup.method_25364(), "\u041f\u043e\u043a\u0430\u0437 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438", "\u0412\u0441\u043f\u043b\u044b\u0432\u0430\u0435\u0442 \u043f\u0440\u0438 \u0441\u043c\u0435\u043d\u0435 \u0442\u0440\u0435\u043a\u0430 \u0438\u043b\u0438 \u0432\u0438\u0434\u043d\u0430 \u0432\u0441\u0435\u0433\u0434\u0430.", "\u0412\u0441\u043f\u043b\u044b\u0432\u0430\u044e\u0449\u0438\u0439 \u043d\u0435 \u0437\u0430\u0433\u0440\u043e\u043c\u043e\u0436\u0434\u0430\u0435\u0442 \u044d\u043a\u0440\u0430\u043d.");
            ModernButtonWidget btnEq = new ModernButtonWidget(contentX, contentY + 22, colW, 19, (class_2561)class_2561.method_43470((String)("\u042d\u043a\u0432\u0430\u043b\u0430\u0439\u0437\u0435\u0440: " + (HudConfig.INSTANCE.showEqualizer ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.showEqualizer = !HudConfig.INSTANCE.showEqualizer;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnEq);
            this.registerHelp(btnEq.method_46426(), btnEq.method_46427(), btnEq.method_25368(), btnEq.method_25364(), "\u042d\u043a\u0432\u0430\u043b\u0430\u0439\u0437\u0435\u0440", "\u0421\u0442\u043e\u043b\u0431\u0438\u043a\u0438 \u043d\u0430 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0435, \u0441\u043a\u0430\u0447\u0443\u0449\u0438\u0435 \u043f\u043e\u0434 \u043c\u0443\u0437\u044b\u043a\u0443.", "\u0412\u041a\u041b \u0434\u043b\u044f \u0436\u0438\u0432\u043e\u0433\u043e \u0432\u0438\u0434\u0430 \u043f\u043b\u0435\u0435\u0440\u0430.");
            ModernButtonWidget btnBeat = new ModernButtonWidget(contentX + colW + 4, contentY + 22, colW, 19, (class_2561)class_2561.method_43470((String)("\u0411\u0438\u0442-\u043f\u0443\u043b\u044c\u0441: " + (HudConfig.INSTANCE.beatBounce ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.beatBounce = !HudConfig.INSTANCE.beatBounce;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnBeat);
            this.registerHelp(btnBeat.method_46426(), btnBeat.method_46427(), btnBeat.method_25368(), btnBeat.method_25364(), "\u0411\u0438\u0442-\u043f\u0443\u043b\u044c\u0441", "\u041c\u044f\u0433\u043a\u0430\u044f \u043f\u0443\u043b\u044c\u0441\u0430\u0446\u0438\u044f \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u0432 \u0442\u0430\u043a\u0442 \u0431\u0430\u0441\u0430\u043c.", "\u0421\u043e\u0437\u0434\u0430\u0451\u0442 \u044d\u0444\u0444\u0435\u043a\u0442 \u0436\u0438\u0432\u043e\u0439 \u043c\u0443\u0437\u044b\u043a\u0438.");
            int bgBtnW = colW - 24;
            int folderBtnW = 20;
            String currentBgName = HudConfig.INSTANCE.customBackgroundFile.isEmpty() ? "\u0421\u043f\u043b\u043e\u0448\u043d\u043e\u0439" : HudConfig.INSTANCE.customBackgroundFile;
            ModernButtonWidget btnBg = new ModernButtonWidget(contentX, contentY + 44, bgBtnW, 19, (class_2561)class_2561.method_43470((String)("\u0424\u043e\u043d: " + currentBgName)), b -> {
                this.cyclePngBackground();
                String name = HudConfig.INSTANCE.customBackgroundFile.isEmpty() ? "\u0421\u043f\u043b\u043e\u0448\u043d\u043e\u0439" : HudConfig.INSTANCE.customBackgroundFile;
                b.method_25355((class_2561)class_2561.method_43470((String)("\u0424\u043e\u043d: " + name)));
                HudConfig.save();
                this.triggerFeedback("\u0424\u043e\u043d HUD: \u00a7e" + name, 58879);
            });
            this.method_37063(btnBg);
            this.registerHelp(btnBg.method_46426(), btnBg.method_46427(), btnBg.method_25368(), btnBg.method_25364(), "\u041a\u0430\u0440\u0442\u0438\u043d\u043a\u0430 \u0444\u043e\u043d\u0430 (.PNG / .JPG)", "\u0412\u044b\u0431\u043e\u0440 \u043a\u0430\u0440\u0442\u0438\u043d\u043a\u0438 \u0438\u0437 \u043f\u0430\u043f\u043a\u0438 backgrounds \u0438\u043b\u0438 \u0441\u043f\u043b\u043e\u0448\u043d\u043e\u0439 \u0446\u0432\u0435\u0442.", "\u041f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044e\u0442\u0441\u044f \u0444\u043e\u0440\u043c\u0430\u0442\u044b .PNG, .JPG, .JPEG \u0438 .BMP.");
            ModernButtonWidget btnFolder = new ModernButtonWidget(contentX + bgBtnW + 4, contentY + 44, folderBtnW, 19, (class_2561)class_2561.method_43470((String)"\ud83d\udcc1"), b -> {
                CustomBackgroundManager.INSTANCE.openBackgroundsFolder();
                this.refreshBackgroundList();
                this.triggerFeedback("\u00a7a\ud83d\udcc1 \u041f\u0430\u043f\u043a\u0430 \u0444\u043e\u043d\u043e\u0432 \u043e\u0442\u043a\u0440\u044b\u0442\u0430", 58879);
            });
            btnFolder.setCustomBgColor(0x3322222E);
            this.method_37063(btnFolder);
            this.registerHelp(btnFolder.method_46426(), btnFolder.method_46427(), btnFolder.method_25368(), btnFolder.method_25364(), "\u041f\u0430\u043f\u043a\u0430 \u0444\u043e\u043d\u043e\u0432", "\u041e\u0442\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043f\u0430\u043f\u043a\u0443 \u0441 \u0444\u043e\u043d\u0430\u043c\u0438 \u0432 \u041f\u0440\u043e\u0432\u043e\u0434\u043d\u0438\u043a\u0435.", "\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0439\u0442\u0435 \u043a\u0430\u0440\u0442\u0438\u043d\u043a\u0438 \u0432 \u0444\u043e\u0440\u043c\u0430\u0442\u0430\u0445 .PNG, .JPG, .JPEG \u0438\u043b\u0438 .BMP.");
            ModernButtonWidget btnAuto = new ModernButtonWidget(contentX + colW + 4, contentY + 44, colW, 19, (class_2561)class_2561.method_43470((String)("\u041e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u0435: " + (HudConfig.INSTANCE.autoAdaptLayout ? "\u00a7a\u0412\u041a\u041b" : "\u00a77\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.autoAdaptLayout = !HudConfig.INSTANCE.autoAdaptLayout;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnAuto);
            this.registerHelp(btnAuto.method_46426(), btnAuto.method_46427(), btnAuto.method_25368(), btnAuto.method_25364(), "\u041e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u0435 \u043c\u0430\u043a\u0435\u0442\u0430", "\u041c\u0435\u043d\u044f\u0435\u0442 \u043e\u0431\u043b\u043e\u0436\u043a\u0443 \u0438 \u0442\u0435\u043a\u0441\u0442 \u043c\u0435\u0441\u0442\u0430\u043c\u0438 \u0443 \u043b\u0435\u0432\u043e\u0433\u043e \u043a\u0440\u0430\u044f.", "\u041e\u0431\u043b\u043e\u0436\u043a\u0430 \u0432\u0441\u0435\u0433\u0434\u0430 \u0431\u043b\u0438\u0436\u0435 \u043a \u043a\u0440\u0430\u044e \u044d\u043a\u0440\u0430\u043d\u0430.");
            ModernButtonWidget btnBar = new ModernButtonWidget(contentX, contentY + 66, colW, 19, (class_2561)class_2561.method_43470((String)("\u041f\u043e\u043b\u043e\u0441\u0430: " + (HudConfig.INSTANCE.showProgressBar ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.showProgressBar = !HudConfig.INSTANCE.showProgressBar;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnBar);
            this.registerHelp(btnBar.method_46426(), btnBar.method_46427(), btnBar.method_25368(), btnBar.method_25364(), "\u041f\u043e\u043b\u043e\u0441\u0430 \u0432\u0440\u0435\u043c\u0435\u043d\u0438", "\u041b\u0438\u043d\u0438\u044f \u043f\u0440\u043e\u0433\u0440\u0435\u0441\u0441\u0430 \u043f\u0435\u0441\u043d\u0438 \u0432\u043d\u0438\u0437\u0443 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438.", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442, \u0441\u043a\u043e\u043b\u044c\u043a\u043e \u0442\u0440\u0435\u043a\u0430 \u043f\u0440\u043e\u0448\u043b\u043e.");
            ModernButtonWidget btnReset = new ModernButtonWidget(contentX + colW + 4, contentY + 66, colW, 19, (class_2561)class_2561.method_43470((String)"\u0421\u0431\u0440\u043e\u0441 \u0432\u0438\u0434\u0430"), b -> {
                HudConfig.INSTANCE.resetToDefault();
                this.recalculateHudDimensions();
                this.hudX = HudConfig.INSTANCE.getAbsoluteX(this.field_22789, this.hudWidth);
                this.hudY = HudConfig.INSTANCE.getAbsoluteY(this.field_22790, this.hudHeight);
                this.initColorWheels();
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnReset);
            this.registerHelp(btnReset.method_46426(), btnReset.method_46427(), btnReset.method_25368(), btnReset.method_25364(), "\u0421\u0431\u0440\u043e\u0441 \u0432\u0438\u0434\u0430", "\u0412\u043e\u0437\u0432\u0440\u0430\u0442 \u0440\u0430\u0437\u043c\u0435\u0440\u0430, \u043c\u0430\u0441\u0448\u0442\u0430\u0431\u0430 \u0438 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e.", "\u041f\u043e\u043c\u043e\u0436\u0435\u0442, \u0435\u0441\u043b\u0438 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0430 \u043f\u043e\u0442\u0435\u0440\u044f\u043b\u0430\u0441\u044c.");
            int sliderW = this.panelWidth - 20;
            ModernSliderWidget sAlpha = new ModernSliderWidget(contentX, contentY + 89, sliderW, 16, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c: ", HudConfig.INSTANCE.hudBackgroundAlpha, val -> String.format("%d%%", (int)(val * 100.0)), val -> {
                HudConfig.INSTANCE.hudBackgroundAlpha = val.floatValue();
                HudConfig.save();
            });
            this.method_37063(sAlpha);
            this.registerHelp(sAlpha.method_46426(), sAlpha.method_46427(), sAlpha.method_25368(), sAlpha.method_25364(), "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c", "\u041f\u043b\u043e\u0442\u043d\u043e\u0441\u0442\u044c \u0444\u043e\u043d\u0430 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u043e\u0442 0 \u0434\u043e 100%.", "75% - 85% \u0434\u0430\u044e\u0442 \u043f\u0440\u0438\u044f\u0442\u043d\u043e\u0435 \u043c\u0430\u0442\u043e\u0432\u043e\u0435 \u0441\u0442\u0435\u043a\u043b\u043e.");
            ModernSliderWidget sRad = new ModernSliderWidget(contentX, contentY + 109, sliderW, 16, "\u0421\u043a\u0440\u0443\u0433\u043b\u0435\u043d\u0438\u0435: ", (double)HudConfig.INSTANCE.cornerRadius / 20.0, val -> String.format("%d px", (int)Math.round(val * 20.0)), val -> {
                HudConfig.INSTANCE.cornerRadius = (int)Math.round(val * 20.0);
                HudConfig.save();
            });
            this.method_37063(sRad);
            this.registerHelp(sRad.method_46426(), sRad.method_46427(), sRad.method_25368(), sRad.method_25364(), "\u0421\u043a\u0440\u0443\u0433\u043b\u0435\u043d\u0438\u0435 \u0443\u0433\u043b\u043e\u0432", "\u041f\u043b\u0430\u0432\u043d\u043e\u0441\u0442\u044c \u0443\u0433\u043b\u043e\u0432 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u043e\u0442 0 \u0434\u043e 20 \u043f\u0438\u043a\u0441\u0435\u043b\u0435\u0439.", "10 - 14 px \u0432\u044b\u0433\u043b\u044f\u0434\u0438\u0442 \u043d\u0430\u0438\u0431\u043e\u043b\u0435\u0435 \u0430\u043a\u043a\u0443\u0440\u0430\u0442\u043d\u043e.");
            double initialScaleNorm = ((double)HudConfig.INSTANCE.hudScale - 0.2) / 3.8;
            ModernSliderWidget sScale = new ModernSliderWidget(contentX, contentY + 129, sliderW, 16, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431: ", initialScaleNorm, val -> String.format("%.2fx", 0.2 + val * 3.8), val -> {
                float newScale = (float)(0.2 + val * 3.8);
                HudConfig.INSTANCE.hudScale = (float)Math.round(newScale * 20.0f) / 20.0f;
                this.recalculateHudDimensions();
                HudConfig.save();
            });
            this.method_37063(sScale);
            this.registerHelp(sScale.method_46426(), sScale.method_46427(), sScale.method_25368(), sScale.method_25364(), "\u041c\u0430\u0441\u0448\u0442\u0430\u0431", "\u0420\u0430\u0437\u043c\u0435\u0440 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u043d\u0430 \u044d\u043a\u0440\u0430\u043d\u0435 (\u043e\u0442 0.2x \u0434\u043e 4.0x).", "1.0x - 1.1x \u043e\u043f\u0442\u0438\u043c\u0430\u043b\u044c\u043d\u043e \u0434\u043b\u044f \u0438\u0433\u0440\u044b.");
        } else if (this.currentTab == 1) {
            ModernButtonWidget btnMode = new ModernButtonWidget(contentX, contentY, colW, 19, (class_2561)class_2561.method_43470((String)("\u0420\u0435\u0436\u0438\u043c: " + this.getSubtitlesModeName())), b -> {
                this.cycleSubtitlesMode();
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnMode);
            this.registerHelp(btnMode.method_46426(), btnMode.method_46427(), btnMode.method_25368(), btnMode.method_25364(), "\u0420\u0435\u0436\u0438\u043c \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432", "3D \u0432 \u0432\u043e\u0437\u0434\u0443\u0445\u0435, \u043d\u0430 \u0431\u043b\u043e\u043a\u0430\u0445 \u0438\u043b\u0438 2D \u043d\u0430 \u044d\u043a\u0440\u0430\u043d\u0435.", "2D \u044d\u043a\u0440\u0430\u043d \u0434\u043b\u044f \u043a\u0438\u043d\u043e-\u0432\u0438\u0434\u0430, 3D \u0434\u043b\u044f \u043f\u043e\u0433\u0440\u0443\u0436\u0435\u043d\u0438\u044f.");
            ModernButtonWidget btnAnim = new ModernButtonWidget(contentX + colW + 4, contentY, colW, 19, (class_2561)class_2561.method_43470((String)("\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f: \u00a7b" + this.getAnimationName())), b -> {
                this.cycleAnimationMode();
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnAnim);
            this.registerHelp(btnAnim.method_46426(), btnAnim.method_46427(), btnAnim.method_25368(), btnAnim.method_25364(), "\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f \u0441\u043b\u043e\u0432", "\u042d\u0444\u0444\u0435\u043a\u0442 \u043f\u043e\u044f\u0432\u043b\u0435\u043d\u0438\u044f: \u041a\u0430\u0440\u0430\u043e\u043a\u0435, \u0412\u043e\u043b\u043d\u0430, \u041f\u0440\u0443\u0436\u0438\u043d\u0430 \u0438 \u0434\u0440.", "\u041a\u0430\u0440\u0430\u043e\u043a\u0435 \u0438 \u041f\u0440\u0443\u0436\u0438\u043d\u0430 \u0447\u0438\u0442\u0430\u044e\u0442\u0441\u044f \u043b\u0443\u0447\u0448\u0435 \u0432\u0441\u0435\u0433\u043e.");
            ModernButtonWidget btnOccl = new ModernButtonWidget(contentX, contentY + 22, colW, 19, (class_2561)class_2561.method_43470((String)("\u0417\u0430 \u043c\u043e\u0431\u0430\u043c\u0438: " + (HudConfig.INSTANCE.subtitlesSeeThrough ? "\u00a7e\u0421\u043a\u0432\u043e\u0437\u044c" : "\u00a7a\u0421\u043a\u0440\u044b\u0432\u0430\u0442\u044c"))), b -> {
                HudConfig.INSTANCE.subtitlesSeeThrough = !HudConfig.INSTANCE.subtitlesSeeThrough;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnOccl);
            this.registerHelp(btnOccl.method_46426(), btnOccl.method_46427(), btnOccl.method_25368(), btnOccl.method_25364(), "\u041f\u0435\u0440\u0435\u043a\u0440\u044b\u0442\u0438\u0435 \u043c\u043e\u0431\u0430\u043c\u0438", "\u041f\u0440\u044f\u0442\u0430\u0442\u044c 3D-\u0441\u0443\u0431\u0442\u0438\u0442\u0440\u044b \u0437\u0430 \u043c\u043e\u0431\u0430\u043c\u0438 \u0438 \u0438\u0433\u0440\u043e\u043a\u0430\u043c\u0438.", "\u0421\u043a\u0440\u044b\u0432\u0430\u0442\u044c \u0434\u0435\u043b\u0430\u0435\u0442 3D-\u0442\u0435\u043a\u0441\u0442 \u0435\u0441\u0442\u0435\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u043c.");
            ModernButtonWidget btnBgText = new ModernButtonWidget(contentX + colW + 4, contentY + 22, colW, 19, (class_2561)class_2561.method_43470((String)("\u0424\u043e\u043d \u0442\u0435\u043a\u0441\u0442\u0430: " + (HudConfig.INSTANCE.subtitlesBgEnabled ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.subtitlesBgEnabled = !HudConfig.INSTANCE.subtitlesBgEnabled;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnBgText);
            this.registerHelp(btnBgText.method_46426(), btnBgText.method_46427(), btnBgText.method_25368(), btnBgText.method_25364(), "\u041f\u043e\u0434\u043b\u043e\u0436\u043a\u0430 \u0442\u0435\u043a\u0441\u0442\u0430", "\u0422\u0451\u043c\u043d\u044b\u0439 \u0444\u043e\u043d \u0437\u0430 \u0441\u043b\u043e\u0432\u0430\u043c\u0438 \u0434\u043b\u044f \u043b\u0443\u0447\u0448\u0435\u0439 \u0447\u0438\u0442\u0430\u0435\u043c\u043e\u0441\u0442\u0438.", "\u0411\u0443\u043a\u0432\u044b \u043d\u0435 \u0442\u0435\u0440\u044f\u044e\u0442\u0441\u044f \u043d\u0430 \u0441\u0432\u0435\u0442\u043b\u043e\u043c \u0444\u043e\u043d\u0435.");
            ModernButtonWidget btnShadow = new ModernButtonWidget(contentX, contentY + 44, colW, 19, (class_2561)class_2561.method_43470((String)("\u0422\u0435\u043d\u044c \u0442\u0435\u043a\u0441\u0442\u0430: " + (HudConfig.INSTANCE.subtitlesTextShadow ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.subtitlesTextShadow = !HudConfig.INSTANCE.subtitlesTextShadow;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnShadow);
            this.registerHelp(btnShadow.method_46426(), btnShadow.method_46427(), btnShadow.method_25368(), btnShadow.method_25364(), "\u0422\u0435\u043d\u044c \u0431\u0443\u043a\u0432", "\u041a\u043e\u043d\u0442\u0443\u0440\u043d\u0430\u044f \u0442\u0435\u043d\u044c \u043f\u043e\u0434 \u0442\u0435\u043a\u0441\u0442\u043e\u043c.", "\u0414\u0435\u043b\u0430\u0435\u0442 \u0442\u0435\u043a\u0441\u0442 \u0447\u0451\u0442\u043a\u0438\u043c \u0438 \u0447\u0438\u0442\u0430\u0435\u043c\u044b\u043c.");
            ModernButtonWidget btnF1 = new ModernButtonWidget(contentX + colW + 4, contentY + 44, colW, 19, (class_2561)class_2561.method_43470((String)("\u0412 F1: " + (HudConfig.INSTANCE.subtitlesVisibleInF1 ? "\u00a7a\u0412\u041a\u041b" : "\u00a77\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.subtitlesVisibleInF1 = !HudConfig.INSTANCE.subtitlesVisibleInF1;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(btnF1);
            this.registerHelp(btnF1.method_46426(), btnF1.method_46427(), btnF1.method_25368(), btnF1.method_25364(), "\u041f\u043e\u043a\u0430\u0437 \u043f\u0440\u0438 F1", "\u041e\u0441\u0442\u0430\u0432\u043b\u044f\u0435\u0442 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u044b \u043f\u0440\u0438 \u0441\u043a\u0440\u044b\u0442\u043e\u043c \u0438\u043d\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0435.", "\u0423\u0434\u043e\u0431\u043d\u043e \u0434\u043b\u044f \u043a\u0440\u0430\u0441\u0438\u0432\u044b\u0445 \u0441\u043a\u0440\u0438\u043d\u0448\u043e\u0442\u043e\u0432 \u0438 \u0432\u0438\u0434\u0435\u043e.");
            int fullW = this.panelWidth - 20;
            boolean is3DMode = "WORLD_3D".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode);
            if (is3DMode) {
                ModernButtonWidget btnSprint = new ModernButtonWidget(contentX, contentY + 66, colW, 19, (class_2561)class_2561.method_43470((String)("\u041f\u0440\u0438 \u0431\u0435\u0433\u0435: " + (HudConfig.INSTANCE.sprintWordsEnabled ? "\u00a7a1-2 \u0441\u043b." : "\u00a77\u0421\u0442\u0440\u043e\u043a\u0430"))), b -> {
                    HudConfig.INSTANCE.sprintWordsEnabled = !HudConfig.INSTANCE.sprintWordsEnabled;
                    HudConfig.save();
                    this.buildTabWidgets();
                });
                this.method_37063(btnSprint);
                this.registerHelp(btnSprint.method_46426(), btnSprint.method_46427(), btnSprint.method_25368(), btnSprint.method_25364(), "\u0421\u043b\u043e\u0432\u0430 \u043f\u0440\u0438 \u0431\u0435\u0433\u0435", "\u041f\u043e\u043a\u0430\u0437 \u0441\u043b\u043e\u0432 \u043a\u043e\u0440\u043e\u0442\u043a\u0438\u043c\u0438 \u043f\u043e\u0440\u0446\u0438\u044f\u043c\u0438 \u0432\u043e \u0432\u0440\u0435\u043c\u044f \u0441\u043f\u0440\u0438\u043d\u0442\u0430.", "\u041e\u0447\u0435\u043d\u044c \u044d\u0444\u0444\u0435\u043a\u0442\u043d\u043e \u0441\u043c\u043e\u0442\u0440\u0438\u0442\u0441\u044f \u043d\u0430 \u0431\u0435\u0433\u0443.");
                int halfColW = (colW - 4) / 2;
                ModernButtonWidget btnSprintSize = new ModernButtonWidget(contentX + colW + 4, contentY + 66, halfColW, 19, (class_2561)class_2561.method_43470((String)("\u041f\u043e\u0440\u0446: \u00a7b" + HudConfig.INSTANCE.sprintWordsChunkSize)), b -> {
                    HudConfig.INSTANCE.sprintWordsChunkSize = HudConfig.INSTANCE.sprintWordsChunkSize == 1 ? 2 : 1;
                    HudConfig.save();
                    this.buildTabWidgets();
                });
                this.method_37063(btnSprintSize);
                this.registerHelp(btnSprintSize.method_46426(), btnSprintSize.method_46427(), btnSprintSize.method_25368(), btnSprintSize.method_25364(), "\u0421\u043b\u043e\u0432 \u0437\u0430 \u0440\u0430\u0437", "\u0421\u043a\u043e\u043b\u044c\u043a\u043e \u0441\u043b\u043e\u0432 \u043f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u043d\u0430 \u0431\u0435\u0433\u0443: 1 \u0438\u043b\u0438 2.", "2 \u0441\u043b\u043e\u0432\u0430 \u0447\u0438\u0442\u0430\u044e\u0442\u0441\u044f \u043a\u043e\u043c\u0444\u043e\u0440\u0442\u043d\u0435\u0435 \u0432\u0441\u0435\u0433\u043e.");
                ModernButtonWidget btnTrail = new ModernButtonWidget(contentX + colW + 4 + halfColW + 4, contentY + 66, halfColW, 19, (class_2561)class_2561.method_43470((String)("\u0428\u043b\u0435\u0439\u0444: \u00a7e" + HudConfig.INSTANCE.sprintWordsTrailLength + " \u0441\u043b.")), b -> {
                    int cur = HudConfig.INSTANCE.sprintWordsTrailLength;
                    HudConfig.INSTANCE.sprintWordsTrailLength = cur >= 8 || cur < 1 ? 1 : cur + 1;
                    HudConfig.save();
                    this.buildTabWidgets();
                });
                this.method_37063(btnTrail);
                this.registerHelp(btnTrail.method_46426(), btnTrail.method_46427(), btnTrail.method_25368(), btnTrail.method_25364(), "\u0428\u043b\u0435\u0439\u0444 \u0441\u043b\u043e\u0432", "\u0421\u043a\u043e\u043b\u044c\u043a\u043e \u0441\u043b\u043e\u0432 \u043f\u0430\u0440\u0438\u0442 \u0432 \u043c\u0438\u0440\u0435 \u043f\u043e\u0437\u0430\u0434\u0438 \u0438\u0433\u0440\u043e\u043a\u0430 (1-8).", "4-5 \u0441\u043b\u043e\u0432 \u0441\u043e\u0437\u0434\u0430\u044e\u0442 \u043a\u0440\u0430\u0441\u0438\u0432\u044b\u0439 \u0441\u043b\u0435\u0434.");
                double subScaleNorm = ((double)HudConfig.INSTANCE.subtitlesScale - 0.5) / 2.5;
                ModernSliderWidget sSubScale = new ModernSliderWidget(contentX, contentY + 89, colW, 16, "\u0422\u0435\u043a\u0441\u0442: ", Math.max(0.0, Math.min(1.0, subScaleNorm)), val -> String.format("%.1fx", 0.5 + val * 2.5), val -> {
                    HudConfig.INSTANCE.subtitlesScale = (float)(0.5 + val * 2.5);
                    HudConfig.save();
                });
                this.method_37063(sSubScale);
                this.registerHelp(sSubScale.method_46426(), sSubScale.method_46427(), sSubScale.method_25368(), sSubScale.method_25364(), "\u0420\u0430\u0437\u043c\u0435\u0440 \u0442\u0435\u043a\u0441\u0442\u0430", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0448\u0440\u0438\u0444\u0442\u0430 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432 \u043e\u0442 0.5x \u0434\u043e 3.0x.", "1.0x - 1.2x \u0434\u043b\u044f \u043b\u0451\u0433\u043a\u043e\u0433\u043e \u0447\u0442\u0435\u043d\u0438\u044f.");
                double subDistNorm = ((double)HudConfig.INSTANCE.subtitlesDistance - 4.0) / 8.0;
                ModernSliderWidget sDist = new ModernSliderWidget(contentX + colW + 4, contentY + 89, colW, 16, "\u0414\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u044c: ", Math.max(0.0, Math.min(1.0, subDistNorm)), val -> String.format("%.1f \u0431\u043b.", 4.0 + val * 8.0), val -> {
                    HudConfig.INSTANCE.subtitlesDistance = (float)(4.0 + val * 8.0);
                    HudConfig.save();
                });
                this.method_37063(sDist);
                this.registerHelp(sDist.method_46426(), sDist.method_46427(), sDist.method_25368(), sDist.method_25364(), "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f 3D", "\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u043e\u0442 \u0433\u043b\u0430\u0437 \u0438\u0433\u0440\u043e\u043a\u0430 \u0434\u043e \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432.", "4.5 - 5.5 \u0431\u043b\u043e\u043a\u043e\u0432 \u043d\u0435 \u043c\u0435\u0448\u0430\u044e\u0442 \u043e\u0431\u0437\u043e\u0440\u0443.");
                double sprintDistNorm = ((double)HudConfig.INSTANCE.sprintWordsDistance - 1.5) / 10.5;
                ModernSliderWidget sSprintDist = new ModernSliderWidget(contentX, contentY + 109, colW, 16, "\u0414\u0438\u0441\u0442. \u0431\u0435\u0433\u0430: ", Math.max(0.0, Math.min(1.0, sprintDistNorm)), val -> String.format("%.1f \u0431\u043b.", 1.5 + val * 10.5), val -> {
                    HudConfig.INSTANCE.sprintWordsDistance = (float)(1.5 + val * 10.5);
                    HudConfig.save();
                });
                this.method_37063(sSprintDist);
                this.registerHelp(sSprintDist.method_46426(), sSprintDist.method_46427(), sSprintDist.method_25368(), sSprintDist.method_25364(), "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u043f\u0440\u0438 \u0431\u0435\u0433\u0435", "\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u0434\u043e \u043f\u043e\u0440\u0446\u0438\u0439 \u0441\u043b\u043e\u0432 \u0432\u043e \u0432\u0440\u0435\u043c\u044f \u0441\u043f\u0440\u0438\u043d\u0442\u0430.", "3.0 - 4.0 \u0431\u043b\u043e\u043a\u043e\u0432 \u043f\u0440\u044f\u043c\u043e \u043f\u0435\u0440\u0435\u0434 \u0433\u043b\u0430\u0437\u0430\u043c\u0438.");
                double sprintHeightNorm = ((double)HudConfig.INSTANCE.sprintWordsHeight + 1.0) / 2.0;
                ModernSliderWidget sSprintHeight = new ModernSliderWidget(contentX + colW + 4, contentY + 109, colW, 16, "\u0412\u044b\u0441\u043e\u0442\u0430 \u0431\u0435\u0433\u0430: ", Math.max(0.0, Math.min(1.0, sprintHeightNorm)), val -> String.format("%+.1f \u0431\u043b.", -1.0 + val * 2.0), val -> {
                    HudConfig.INSTANCE.sprintWordsHeight = (float)(-1.0 + val * 2.0);
                    HudConfig.save();
                });
                this.method_37063(sSprintHeight);
                this.registerHelp(sSprintHeight.method_46426(), sSprintHeight.method_46427(), sSprintHeight.method_25368(), sSprintHeight.method_25364(), "\u0412\u044b\u0441\u043e\u0442\u0430 \u043f\u0440\u0438 \u0431\u0435\u0433\u0435", "\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u0441\u043b\u043e\u0432 \u0432\u044b\u0448\u0435 \u0438\u043b\u0438 \u043d\u0438\u0436\u0435 \u0443\u0440\u043e\u0432\u043d\u044f \u0433\u043b\u0430\u0437.", "0.0 \u0431\u043b\u043e\u043a\u043e\u0432 \u0434\u0435\u0440\u0436\u0438\u0442 \u0441\u043b\u043e\u0432\u0430 \u043f\u043e \u0446\u0435\u043d\u0442\u0440\u0443.");
            } else {
                ModernButtonWidget btnReset2D = new ModernButtonWidget(contentX, contentY + 66, fullW, 19, (class_2561)class_2561.method_43470((String)"\u0421\u0431\u0440\u043e\u0441 \u043f\u043e\u0437\u0438\u0446\u0438\u0438 2D \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432"), b -> {
                    HudConfig.INSTANCE.sub2DPositionX = 0.5;
                    HudConfig.INSTANCE.sub2DPositionY = 0.82;
                    HudConfig.save();
                });
                this.method_37063(btnReset2D);
                this.registerHelp(btnReset2D.method_46426(), btnReset2D.method_46427(), btnReset2D.method_25368(), btnReset2D.method_25364(), "\u041f\u043e \u0446\u0435\u043d\u0442\u0440\u0443", "\u0412\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442 2D-\u0441\u0443\u0431\u0442\u0438\u0442\u0440\u044b \u0432 \u0446\u0435\u043d\u0442\u0440 \u044d\u043a\u0440\u0430\u043d\u0430.", "\u041a\u043b\u0430\u0441\u0441\u0438\u0447\u0435\u0441\u043a\u043e\u0435 \u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043a\u0430\u043a \u0432 \u043a\u0438\u043d\u043e.");
                double subScaleNorm = ((double)HudConfig.INSTANCE.subtitlesScale - 0.5) / 2.5;
                ModernSliderWidget sSubScale = new ModernSliderWidget(contentX, contentY + 89, fullW, 16, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0442\u0435\u043a\u0441\u0442\u0430: ", Math.max(0.0, Math.min(1.0, subScaleNorm)), val -> String.format("%.1fx", 0.5 + val * 2.5), val -> {
                    HudConfig.INSTANCE.subtitlesScale = (float)(0.5 + val * 2.5);
                    HudConfig.save();
                });
                this.method_37063(sSubScale);
                this.registerHelp(sSubScale.method_46426(), sSubScale.method_46427(), sSubScale.method_25368(), sSubScale.method_25364(), "\u0420\u0430\u0437\u043c\u0435\u0440 \u0442\u0435\u043a\u0441\u0442\u0430", "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 2D-\u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432 \u043d\u0430 \u044d\u043a\u0440\u0430\u043d\u0435.", "1.0x - 1.2x \u043a\u043e\u043c\u0444\u043e\u0440\u0442\u043d\u043e \u0434\u043b\u044f \u0433\u043b\u0430\u0437.");
                double subDistNorm = ((double)HudConfig.INSTANCE.subtitlesDistance - 4.0) / 8.0;
                ModernSliderWidget sDist = new ModernSliderWidget(contentX, contentY + 109, fullW, 16, "\u0414\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u044c 3D: ", Math.max(0.0, Math.min(1.0, subDistNorm)), val -> String.format("%.1f \u0431\u043b.", 4.0 + val * 8.0), val -> {
                    HudConfig.INSTANCE.subtitlesDistance = (float)(4.0 + val * 8.0);
                    HudConfig.save();
                });
                this.method_37063(sDist);
                this.registerHelp(sDist.method_46426(), sDist.method_46427(), sDist.method_25368(), sDist.method_25364(), "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f 3D", "\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u043e\u0442 \u0433\u043b\u0430\u0437 \u0438\u0433\u0440\u043e\u043a\u0430 \u0434\u043e \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432.", "4.5 - 5.5 \u0431\u043b\u043e\u043a\u043e\u0432 \u043d\u0435 \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u044e\u0442 \u043e\u0431\u0437\u043e\u0440.");
            }
            double initialOffsetNorm = ((double)HudConfig.INSTANCE.subtitlesOffsetMs + 4000.0) / 8000.0;
            int syncSliderW = fullW - 104;
            ModernSliderWidget sSync = new ModernSliderWidget(contentX, contentY + 129, syncSliderW, 16, "\u0421\u0438\u043d\u0445\u0440: ", Math.max(0.0, Math.min(1.0, initialOffsetNorm)), val -> String.format("%+.1f \u0441", -4.0 + val * 8.0), val -> {
                HudConfig.INSTANCE.subtitlesOffsetMs = (int)Math.round((-4.0 + val * 8.0) * 1000.0);
                HudConfig.save();
            });
            this.method_37063(sSync);
            this.registerHelp(sSync.method_46426(), sSync.method_46427(), sSync.method_25368(), sSync.method_25364(), "\u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u044f", "\u0421\u0434\u0432\u0438\u0433 \u0432\u0440\u0435\u043c\u0435\u043d\u0438 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432 \u043e\u0442 -4 \u0434\u043e +4 \u0441\u0435\u043a\u0443\u043d\u0434.", "\u0414\u043b\u044f Bluetooth-\u043d\u0430\u0443\u0448\u043d\u0438\u043a\u043e\u0432 \u043f\u043e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 +0.5 \u0441\u0435\u043a.");
            ModernButtonWidget bM = new ModernButtonWidget(contentX + syncSliderW + 4, contentY + 129, 30, 16, (class_2561)class_2561.method_43470((String)"-0.5"), b -> {
                HudConfig.INSTANCE.subtitlesOffsetMs -= 500;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(bM);
            this.registerHelp(bM.method_46426(), bM.method_46427(), bM.method_25368(), bM.method_25364(), "\u0420\u0430\u043d\u044c\u0448\u0435 \u043d\u0430 0.5\u0441", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0441\u043b\u043e\u0432\u0430 \u0447\u0443\u0442\u044c \u0440\u0430\u043d\u044c\u0448\u0435 \u0437\u0432\u0443\u043a\u0430.", "\u0415\u0441\u043b\u0438 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u044b \u043e\u0442\u0441\u0442\u0430\u044e\u0442 \u043e\u0442 \u043c\u0443\u0437\u044b\u043a\u0438.");
            ModernButtonWidget bZ = new ModernButtonWidget(contentX + syncSliderW + 36, contentY + 129, 28, 16, (class_2561)class_2561.method_43470((String)"0\u0441"), b -> {
                HudConfig.INSTANCE.subtitlesOffsetMs = 0;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(bZ);
            this.registerHelp(bZ.method_46426(), bZ.method_46427(), bZ.method_25368(), bZ.method_25364(), "\u0421\u0431\u0440\u043e\u0441 \u0441\u0434\u0432\u0438\u0433\u0430", "\u0412\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442 \u0441\u0434\u0432\u0438\u0433 \u0432\u0440\u0435\u043c\u0435\u043d\u0438 \u043d\u0430 0 \u0441\u0435\u043a\u0443\u043d\u0434.", "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442 \u0434\u043b\u044f \u043a\u043e\u043b\u043e\u043d\u043e\u043a \u0438 \u043f\u0440\u043e\u0432\u043e\u0434\u043d\u044b\u0445 \u043d\u0430\u0443\u0448\u043d\u0438\u043a\u043e\u0432.");
            ModernButtonWidget bP = new ModernButtonWidget(contentX + syncSliderW + 66, contentY + 129, 34, 16, (class_2561)class_2561.method_43470((String)"+0.5"), b -> {
                HudConfig.INSTANCE.subtitlesOffsetMs += 500;
                HudConfig.save();
                this.buildTabWidgets();
            });
            this.method_37063(bP);
            this.registerHelp(bP.method_46426(), bP.method_46427(), bP.method_25368(), bP.method_25364(), "\u041f\u043e\u0437\u0436\u0435 \u043d\u0430 0.5\u0441", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0441\u043b\u043e\u0432\u0430 \u0447\u0443\u0442\u044c \u043f\u043e\u0437\u0436\u0435 \u0437\u0432\u0443\u043a\u0430.", "\u0423\u0434\u043e\u0431\u043d\u043e \u0434\u043b\u044f \u0431\u0435\u0441\u043f\u0440\u043e\u0432\u043e\u0434\u043d\u044b\u0445 \u043d\u0430\u0443\u0448\u043d\u0438\u043a\u043e\u0432.");
        } else if (this.currentTab == 2) {
            int pillW = (this.panelWidth - 20 - 16) / 5;
            String[] targetNames = new String[]{"\u0424\u043e\u043d HUD", "\u041f\u043e\u043b\u043e\u0441\u0430", "\u0422\u0435\u043a\u0441\u0442", "\u0424\u043e\u043d \u0442\u0435\u043a\u0441\u0442\u0430", "\u041a\u0430\u0440\u0430\u043e\u043a\u0435"};
            for (int i = 0; i < 5; ++i) {
                int tIdx = i;
                ModernButtonWidget btn = new ModernButtonWidget(contentX + i * (pillW + 4), contentY, pillW, 18, (class_2561)class_2561.method_43470((String)((this.paletteTarget == tIdx ? "\u00a7b\u25cf " : "") + targetNames[i])), b -> {
                    this.paletteTarget = tIdx;
                    if (this.paletteColorWheel != null) {
                        this.paletteColorWheel.setColorFromRgb(this.getCurrentTargetColor());
                    }
                    this.buildTabWidgets();
                });
                btn.setPrimary(this.paletteTarget == tIdx);
                this.method_37063(btn);
                String pTitle = "\u0426\u0432\u0435\u0442: " + targetNames[i];
                String pDesc = switch (tIdx) {
                    case 0 -> "\u0426\u0432\u0435\u0442 \u0444\u043e\u043d\u0430 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u043f\u043b\u0435\u0435\u0440\u0430.";
                    case 1 -> "\u0426\u0432\u0435\u0442 \u043f\u043e\u043b\u043e\u0441\u044b \u0442\u0440\u0435\u043a\u0430.";
                    case 2 -> "\u0426\u0432\u0435\u0442 \u0442\u0435\u043a\u0441\u0442\u0430 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432.";
                    case 3 -> "\u0426\u0432\u0435\u0442 \u043f\u043e\u0434\u043b\u043e\u0436\u043a\u0438 \u0437\u0430 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u0430\u043c\u0438.";
                    default -> "\u0426\u0432\u0435\u0442 \u043f\u043e\u044e\u0449\u0435\u0433\u043e\u0441\u044f \u0441\u043b\u043e\u0432\u0430.";
                };
                String pRec = switch (tIdx) {
                    case 0 -> "\u0422\u0451\u043c\u043d\u043e-\u0433\u0440\u0430\u0444\u0438\u0442\u043e\u0432\u044b\u0439 (#16161A).";
                    case 1 -> "\u0421\u0438\u043d\u0438\u0439 (#007AFF) \u0438\u043b\u0438 \u0431\u0438\u0440\u044e\u0437\u043e\u0432\u044b\u0439 (#00E5FF).";
                    case 2 -> "\u0427\u0438\u0441\u0442\u044b\u0439 \u0431\u0435\u043b\u044b\u0439 (#FFFFFF).";
                    case 3 -> "\u0422\u0451\u043c\u043d\u044b\u0439 \u043f\u043e\u043b\u0443\u043f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u044b\u0439 (#11111E).";
                    default -> "\u0417\u043e\u043b\u043e\u0442\u0438\u0441\u0442\u044b\u0439 (#FFCC00) \u0438\u043b\u0438 \u0430\u043a\u0432\u0430\u043c\u0430\u0440\u0438\u043d (#00FFCC).";
                };
                this.registerHelp(btn.method_46426(), btn.method_46427(), btn.method_25368(), btn.method_25364(), pTitle, pDesc, pRec);
            }
            this.registerHelp(contentX + 6, contentY + 34, 82, 82, "\u0426\u0432\u0435\u0442\u043e\u0432\u043e\u0439 \u043a\u0440\u0443\u0433", "\u041a\u043b\u0438\u043a\u043d\u0438\u0442\u0435 \u0432 \u043a\u0440\u0443\u0433 \u0434\u043b\u044f \u0432\u044b\u0431\u043e\u0440\u0430 \u043d\u0443\u0436\u043d\u043e\u0433\u043e \u0446\u0432\u0435\u0442\u0430.", "\u0426\u0432\u0435\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u0442\u0441\u044f \u0441\u0440\u0430\u0437\u0443.");
            int resetW = this.panelWidth - 20 - 96;
            ModernButtonWidget btnResetCol = new ModernButtonWidget(contentX + 96, contentY + 88, resetW, 19, (class_2561)class_2561.method_43470((String)"\ud83d\udd04 \u0421\u0431\u0440\u043e\u0441\u0438\u0442\u044c \u0446\u0432\u0435\u0442"), b -> {
                switch (this.paletteTarget) {
                    case 0: {
                        HudConfig.INSTANCE.hudBackgroundColor = 1710638;
                        break;
                    }
                    case 1: {
                        HudConfig.INSTANCE.progressBarColor = -13312;
                        break;
                    }
                    case 2: {
                        HudConfig.INSTANCE.subtitlesColor = -1;
                        break;
                    }
                    case 3: {
                        HudConfig.INSTANCE.subtitlesBgColor = 0x11111E;
                        break;
                    }
                    case 4: {
                        HudConfig.INSTANCE.subtitlesActiveColor = -10496;
                    }
                }
                this.initColorWheels();
                HudConfig.save();
            });
            this.method_37063(btnResetCol);
            this.registerHelp(btnResetCol.method_46426(), btnResetCol.method_46427(), btnResetCol.method_25368(), btnResetCol.method_25364(), "\u0421\u0431\u0440\u043e\u0441 \u0446\u0432\u0435\u0442\u0430", "\u0412\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442 \u0446\u0432\u0435\u0442 \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0430 \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e.", "\u0411\u044b\u0441\u0442\u0440\u044b\u0439 \u0432\u043e\u0437\u0432\u0440\u0430\u0442 \u043a \u0431\u0430\u0437\u043e\u0432\u043e\u0439 \u043f\u0430\u043b\u0438\u0442\u0440\u0435.");
        } else if (this.currentTab == 3) {
            int leftCardW = 100;
            int rightCardX = contentX + leftCardW + 6;
            int rightCardW = this.panelWidth - 20 - leftCardW - 6;
            int btnY = contentY + 84;
            ModernButtonWidget btnDucking = new ModernButtonWidget(rightCardX + 6, btnY, rightCardW - 12, 19, (class_2561)class_2561.method_43470((String)("\u041f\u0440\u0438\u0433\u043b\u0443\u0448\u0435\u043d\u0438\u0435: " + (HudConfig.INSTANCE.smartDuckingEnabled ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b"))), b -> {
                HudConfig.INSTANCE.smartDuckingEnabled = !HudConfig.INSTANCE.smartDuckingEnabled;
                HudConfig.save();
                b.method_25355((class_2561)class_2561.method_43470((String)("\u041f\u0440\u0438\u0433\u043b\u0443\u0448\u0435\u043d\u0438\u0435: " + (HudConfig.INSTANCE.smartDuckingEnabled ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b"))));
                this.triggerFeedback(HudConfig.INSTANCE.smartDuckingEnabled ? "\u00a7a\u25cf \u041f\u0440\u0438\u0433\u043b\u0443\u0448\u0435\u043d\u0438\u0435 \u043c\u0443\u0437\u044b\u043a\u0438: \u0412\u041a\u041b" : "\u00a7c\u25cb \u041f\u0440\u0438\u0433\u043b\u0443\u0448\u0435\u043d\u0438\u0435 \u043c\u0443\u0437\u044b\u043a\u0438: \u0412\u042b\u041a\u041b", 58879);
            });
            this.method_37063(btnDucking);
            this.registerHelp(btnDucking.method_46426(), btnDucking.method_46427(), btnDucking.method_25368(), btnDucking.method_25364(), "\u0423\u043c\u043d\u043e\u0435 \u043f\u0440\u0438\u0433\u043b\u0443\u0448\u0435\u043d\u0438\u0435", "\u041f\u0440\u0438\u0433\u043b\u0443\u0448\u0430\u0435\u0442 \u043c\u0443\u0437\u044b\u043a\u0443 \u0432\u043e \u0432\u0440\u0435\u043c\u044f \u0440\u0430\u0437\u0433\u043e\u0432\u043e\u0440\u0430 \u0432 Simple Voice Chat.", "\u041f\u043e\u043c\u043e\u0433\u0430\u0435\u0442 \u0447\u0435\u0442\u043a\u043e \u0441\u043b\u044b\u0448\u0430\u0442\u044c \u0433\u043e\u043b\u043e\u0441 \u0442\u0438\u043c\u043c\u0435\u0439\u0442\u043e\u0432.");
            ModernButtonWidget btnShare = new ModernButtonWidget(rightCardX + 6, btnY += 26, rightCardW - 12, 19, (class_2561)class_2561.method_43470((String)"\u00a7b\ud83d\udcac \u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u0432 \u0447\u0430\u0442"), b -> {
                SessionStatsManager.INSTANCE.shareStatsToChat();
                this.triggerFeedback("\u00a7a\u2714 \u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043a\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0430 \u0432 \u0447\u0430\u0442!", 65416);
            });
            btnShare.setCustomBgColor(855669503);
            this.method_37063(btnShare);
            this.registerHelp(btnShare.method_46426(), btnShare.method_46427(), btnShare.method_25368(), btnShare.method_25364(), "\u041f\u043e\u0434\u0435\u043b\u0438\u0442\u044c\u0441\u044f \u0432 \u0447\u0430\u0442", "\u041e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u043c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u0443\u044e \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043a\u0443 \u0441\u0435\u0441\u0441\u0438\u0438 \u0432 \u0438\u0433\u0440\u043e\u0432\u043e\u0439 \u0447\u0430\u0442.", "\u041f\u043e\u043a\u0430\u0436\u0438\u0442\u0435 \u0434\u0440\u0443\u0437\u044c\u044f\u043c \u0441\u043a\u043e\u043b\u044c\u043a\u043e \u0442\u0440\u0435\u043a\u043e\u0432 \u0432\u044b \u043f\u0440\u043e\u0441\u043b\u0443\u0448\u0430\u043b\u0438.");
        }
    }

    private String getAnimationName() {
        String a = HudConfig.INSTANCE.subtitlesAnimation;
        if (a == null) {
            return "\u041a\u0430\u0440\u0430\u043e\u043a\u0435";
        }
        return switch (a.toUpperCase()) {
            case "WAVE_FLOAT" -> "\u0412\u043e\u043b\u043d\u0430";
            case "ELASTIC_POP" -> "\u041f\u0440\u0443\u0436\u0438\u043d\u0430";
            case "PULSE_GLOW" -> "\u041f\u0443\u043b\u044c\u0441";
            case "SLIDE_FADE" -> "\u0421\u043b\u0430\u0439\u0434";
            case "CLASSIC" -> "\u041a\u043b\u0430\u0441\u0441\u0438\u043a\u0430";
            default -> "\u041a\u0430\u0440\u0430\u043e\u043a\u0435";
        };
    }

    private void cycleAnimationMode() {
        String a = HudConfig.INSTANCE.subtitlesAnimation;
        if (a == null) {
            a = "KARAOKE_BOUNCE";
        }
        HudConfig.INSTANCE.subtitlesAnimation = switch (a.toUpperCase()) {
            case "KARAOKE_BOUNCE" -> "WAVE_FLOAT";
            case "WAVE_FLOAT" -> "ELASTIC_POP";
            case "ELASTIC_POP" -> "PULSE_GLOW";
            case "PULSE_GLOW" -> "SLIDE_FADE";
            case "SLIDE_FADE" -> "CLASSIC";
            default -> "KARAOKE_BOUNCE";
        };
        HudConfig.save();
    }

    private String getSubtitlesModeName() {
        if (!HudConfig.INSTANCE.subtitlesEnabled) {
            return "\u00a7c\u0412\u042b\u041a\u041b";
        }
        return switch (HudConfig.INSTANCE.subtitlesMode) {
            case "WORLD_3D" -> "3D \u0432 \u043c\u0438\u0440\u0435";
            case "WORLD_BLOCK" -> "\u041d\u0430 \u0431\u043b\u043e\u043a\u0435";
            case "HUD_BOTTOM" -> "2D \u044d\u043a\u0440\u0430\u043d";
            case "SCREEN_RANDOM" -> "2D \u0440\u0430\u0437\u0431\u0440\u043e\u0441";
            default -> "3D \u0432 \u043c\u0438\u0440\u0435";
        };
    }

    private void cycleSubtitlesMode() {
        if (!HudConfig.INSTANCE.subtitlesEnabled) {
            HudConfig.INSTANCE.subtitlesEnabled = true;
            HudConfig.INSTANCE.subtitlesMode = "WORLD_3D";
        } else {
            switch (HudConfig.INSTANCE.subtitlesMode) {
                case "WORLD_3D": {
                    HudConfig.INSTANCE.subtitlesMode = "WORLD_BLOCK";
                    break;
                }
                case "WORLD_BLOCK": {
                    HudConfig.INSTANCE.subtitlesMode = "HUD_BOTTOM";
                    break;
                }
                case "HUD_BOTTOM": {
                    HudConfig.INSTANCE.subtitlesMode = "SCREEN_RANDOM";
                    break;
                }
                case "SCREEN_RANDOM": {
                    HudConfig.INSTANCE.subtitlesEnabled = false;
                    HudConfig.INSTANCE.subtitlesMode = "WORLD_3D";
                    break;
                }
                default: {
                    HudConfig.INSTANCE.subtitlesMode = "WORLD_3D";
                }
            }
        }
    }

    private void cyclePngBackground() {
        this.refreshBackgroundList();
        if (this.availablePngBackgrounds.isEmpty()) {
            HudConfig.INSTANCE.customBackgroundFile = "";
            return;
        }
        int curIdx = -1;
        for (int i = 0; i < this.availablePngBackgrounds.size(); ++i) {
            if (!this.availablePngBackgrounds.get(i).equalsIgnoreCase(HudConfig.INSTANCE.customBackgroundFile)) continue;
            curIdx = i;
            break;
        }
        HudConfig.INSTANCE.customBackgroundFile = curIdx == -1 ? this.availablePngBackgrounds.get(0) : (curIdx + 1 < this.availablePngBackgrounds.size() ? this.availablePngBackgrounds.get(curIdx + 1) : "");
        CustomBackgroundManager.INSTANCE.reload();
    }

    private List<String> wrapText(String text, int maxWidth) {
        ArrayList<String> result = new ArrayList<String>();
        if (text == null || text.isBlank()) {
            return result;
        }
        String[] words = text.split(" ");
        StringBuilder current = new StringBuilder();
        for (String word : words) {
            if (current.isEmpty()) {
                current.append(word);
                continue;
            }
            if (this.field_22793.method_1727(String.valueOf(current) + " " + word) <= maxWidth) {
                current.append(" ").append(word);
                continue;
            }
            result.add(current.toString());
            current = new StringBuilder(word);
        }
        if (!current.isEmpty()) {
            result.add(current.toString());
        }
        return result;
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        int mouseState;
        long handle;
        class_310 mc = class_310.method_1551();
        if (this.dragging) {
            handle = mc.method_22683().method_4490();
            mouseState = GLFW.glfwGetMouseButton((long)handle, (int)0);
            if (mouseState != 1) {
                this.dragging = false;
                HudConfig.INSTANCE.setFromAbsolute(this.hudX, this.hudY, this.field_22789, this.field_22790, this.hudWidth, this.hudHeight);
                HudConfig.save();
            } else {
                this.hudX = mouseX - this.dragOffsetX;
                this.hudY = mouseY - this.dragOffsetY;
                this.hudX = Math.max(0, Math.min(this.hudX, this.field_22789 - this.hudWidth));
                this.hudY = Math.max(0, Math.min(this.hudY, this.field_22790 - this.hudHeight));
                int snapThreshold = 15;
                if (this.hudX < snapThreshold) {
                    this.hudX = 0;
                }
                if (this.field_22789 - (this.hudX + this.hudWidth) < snapThreshold) {
                    this.hudX = this.field_22789 - this.hudWidth;
                }
                if (this.hudY < snapThreshold) {
                    this.hudY = 0;
                }
                if (this.field_22790 - (this.hudY + this.hudHeight) < snapThreshold) {
                    this.hudY = this.field_22790 - this.hudHeight;
                }
            }
        }
        if (this.dragging2DSub) {
            handle = mc.method_22683().method_4490();
            mouseState = GLFW.glfwGetMouseButton((long)handle, (int)0);
            if (mouseState != 1) {
                this.dragging2DSub = false;
                HudConfig.save();
            } else {
                int newCenterX = mouseX - this.dragSubOffsetX;
                int newCenterY = mouseY - this.dragSubOffsetY;
                if (Math.abs(newCenterX - this.field_22789 / 2) < 16) {
                    newCenterX = this.field_22789 / 2;
                }
                HudConfig.INSTANCE.sub2DPositionX = class_3532.method_15350((double)((double)newCenterX / (double)this.field_22789), (double)0.05, (double)0.95);
                HudConfig.INSTANCE.sub2DPositionY = class_3532.method_15350((double)((double)newCenterY / (double)this.field_22790), (double)0.05, (double)0.95);
            }
        }
        if (this.dragging2DSub) {
            this.renderLiveSubtitlePreview(context, mouseX, mouseY);
            return;
        }
        MusicHudRenderer.renderRoundedRect(context, this.panelX, this.panelY, this.panelWidth, this.panelHeight, 10, -267119072);
        MusicHudRenderer.renderRoundedRect(context, this.panelX, this.panelY, this.panelWidth, this.panelHeight, 10, 0x2EFFFFFF);
        context.method_25294(this.panelX + 12, this.panelY, this.panelX + this.panelWidth - 12, this.panelY + 1, 0x66FFFFFF);
        context.method_25294(this.panelX + 8, this.panelY + 22, this.panelX + this.panelWidth - 8, this.panelY + 23, 0x22FFFFFF);
        int waveY = this.panelY + this.panelHeight - 7;
        int waveStartX = this.panelX + 14;
        int waveWidth = this.panelWidth - 28;
        int waveBars = 36;
        float waveBarW = (float)waveWidth / (float)waveBars;
        int maxWaveH = 13;
        context.method_25294(this.panelX + 10, waveY - maxWaveH - 3, this.panelX + this.panelWidth - 10, waveY - maxWaveH - 2, 0x14FFFFFF);
        long nowMs = System.currentTimeMillis();
        for (int i = 0; i < waveBars; ++i) {
            float heightRatio;
            boolean playing;
            float freq = (float)i / (float)waveBars;
            float phase = (float)((double)nowMs * 0.004 + (double)freq * 6.28);
            float sineWave = (float)(Math.sin(phase) * 0.5 + 0.5);
            float secondary = (float)(Math.cos((double)nowMs * 0.0025 - (double)freq * 4.0) * 0.5 + 0.5);
            float combined = sineWave * 0.6f + secondary * 0.4f;
            TrackState ts = NowPlayingClient.INSTANCE != null ? NowPlayingClient.INSTANCE.getState() : null;
            boolean bl = playing = ts != null && ts.isActive() && !"stopped".equalsIgnoreCase(ts.status()) && !"paused".equalsIgnoreCase(ts.status());
            if (playing) {
                float bc = (float)((double)(ts.getInterpolatedPositionMs() % 500L) / 500.0);
                float be = (float)Math.pow(Math.max(0.0, 1.0 - (double)bc * 1.8), 2.2);
                heightRatio = Math.max(0.12f, combined * 0.55f + be * 0.45f);
            } else {
                heightRatio = Math.max(0.06f, combined * 0.22f);
            }
            int bH = Math.max(1, (int)(heightRatio * (float)maxWaveH));
            int bx = waveStartX + (int)((float)i * waveBarW);
            int by = waveY - bH;
            int col = HudEditScreen.lerpColor(1073800703, 1088438523, freq);
            MusicHudRenderer.renderRoundedRect(context, bx, by, Math.max(1, (int)waveBarW - 1), bH, 1, col);
        }
        int dotY = this.panelY + 11;
        int redX = this.panelX + 14;
        int yellowX = this.panelX + 26;
        int greenX = this.panelX + 38;
        boolean hoverRed = mouseX >= redX - 5 && mouseX <= redX + 5 && mouseY >= dotY - 5 && mouseY <= dotY + 5;
        boolean hoverYellow = mouseX >= yellowX - 5 && mouseX <= yellowX + 5 && mouseY >= dotY - 5 && mouseY <= dotY + 5;
        boolean hoverGreen = mouseX >= greenX - 5 && mouseX <= greenX + 5 && mouseY >= dotY - 5 && mouseY <= dotY + 5;
        MusicHudRenderer.renderRoundedRect(context, redX - 4, dotY - 4, 8, 8, 4, -41130);
        MusicHudRenderer.renderRoundedRect(context, yellowX - 4, dotY - 4, 8, 8, 4, -17106);
        MusicHudRenderer.renderRoundedRect(context, greenX - 4, dotY - 4, 8, 8, 4, -14169793);
        if (hoverRed) {
            context.method_51433(this.field_22793, "\u00a78\u00d7", redX - 2, dotY - 4, -1442840576, false);
        }
        if (hoverYellow) {
            context.method_51433(this.field_22793, "\u00a78-", yellowX - 2, dotY - 4, -1442840576, false);
        }
        if (hoverGreen) {
            context.method_51433(this.field_22793, "\u00a78+", greenX - 2, dotY - 4, -1442840576, false);
        }
        TrackState trackState = NowPlayingClient.INSTANCE != null ? NowPlayingClient.INSTANCE.getState() : null;
        boolean isPlaying = trackState != null && trackState.isActive() && !"stopped".equalsIgnoreCase(trackState.status()) && !"paused".equalsIgnoreCase(trackState.status());
        float beatCycle = isPlaying && trackState != null ? (float)((double)(trackState.getInterpolatedPositionMs() % 500L) / 500.0) : (float)((double)(nowMs % 600L) / 600.0);
        float beatEnergy = isPlaying ? (float)Math.pow(Math.max(0.0, 1.0 - (double)beatCycle * 1.8), 2.2) : (float)Math.sin((double)nowMs * 0.005) * 0.25f + 0.25f;
        float iconBounce = isPlaying ? -beatEnergy * 3.5f : (float)Math.sin((double)nowMs * 0.004) * 1.2f;
        int iconX = this.panelX + 48;
        int iconY = (int)((float)(this.panelY + 4) + iconBounce);
        int iconW = 14;
        int iconH = 14;
        MusicHudRenderer.renderRoundedRect(context, iconX, iconY, iconW, iconH, 4, 1140909567);
        MusicHudRenderer.renderRoundedRect(context, iconX, iconY, iconW, iconH, 4, 0x55FFFFFF);
        context.method_51433(this.field_22793, "\u266c", iconX + 4, iconY + 3, isPlaying ? -16718337 : -1, true);
        int titleX = iconX + 18;
        context.method_51433(this.field_22793, "Music Subtitles", titleX, this.panelY + 7, -285212673, false);
        int titleW = this.field_22793.method_1727("Music Subtitles");
        int masterX = this.panelX + this.panelWidth - 44 - 8;
        int helpBtnX = masterX - 16 - 4;
        int keyBtnX = helpBtnX - 16 - 4;
        int diagBtnX = keyBtnX - 16 - 4;
        int twitchBtnX = diagBtnX - 16 - 4;
        int eqRightLimit = twitchBtnX - 5;
        int eqX = titleX + titleW + 5;
        int eqBaseY = this.panelY + 17;
        int eqMaxH = 10;
        int barW = 2;
        int barGap = 2;
        int availableW = eqRightLimit - eqX;
        if (availableW > 6) {
            int barCount = availableW / (barW + barGap);
            int[] eqColors = new int[]{
                0xFF00E5FF, 0xFF00B0FF, 0xFF2979FF, 0xFF651FFF, 0xFF9146FF,
                0xFFB57BFF, 0xFFE040FB, 0xFFFF4081, 0xFFFF9100, 0xFFFFEA00
            };
            for (int b = 0; b < barCount; ++b) {
                int bx = eqX + b * (barW + barGap);
                if (bx + barW > eqRightLimit) break;
                float barPhase = (float)((double)b * 0.35 + (double)nowMs / 1000.0 * (isPlaying ? 8.0 : 3.0));
                float wave = (float)(Math.sin(barPhase) * 0.5 + 0.5);
                float curve = 0.55f + 0.45f * (float)Math.sin((double)b / (double)barCount * Math.PI);
                float energy = isPlaying ? (beatEnergy * 0.5f + wave * 0.5f) * curve : (wave * 0.4f + 0.15f) * curve;
                int barH = Math.max(2, (int)(energy * (float)eqMaxH));
                int by = eqBaseY - barH;
                int col = eqColors[b % eqColors.length];
                MusicHudRenderer.renderRoundedRect(context, bx, by, barW, barH, 1, col);
            }
        }
        int tabY = this.panelY + 24;
        int tabH = 19;
        int tabW = (this.panelWidth - 16 - 12) / 5;
        float targetTabX = this.panelX + 8 + (tabW + 3) * this.currentTab;
        float targetTabW = tabW;
        if (this.tabIndicatorX < 0.0f) {
            this.tabIndicatorX = targetTabX;
            this.tabIndicatorW = targetTabW;
        } else {
            float dt = this.lastFrameTime > 0L ? Math.min(0.1f, (float)(nowMs - this.lastFrameTime) / 1000.0f) : 0.016f;
            this.tabIndicatorX += (targetTabX - this.tabIndicatorX) * Math.min(1.0f, dt * 18.0f);
            this.tabIndicatorW += (targetTabW - this.tabIndicatorW) * Math.min(1.0f, dt * 18.0f);
        }
        this.lastFrameTime = nowMs;
        MusicHudRenderer.renderRoundedRect(context, this.panelX + 8, tabY, this.panelWidth - 16, tabH, 5, 0x33000000);
        MusicHudRenderer.renderRoundedRect(context, this.panelX + 8, tabY, this.panelWidth - 16, tabH, 5, 0x22FFFFFF);
        MusicHudRenderer.renderRoundedRect(context, (int)this.tabIndicatorX, tabY, (int)this.tabIndicatorW, tabH, 4, 855696895);
        MusicHudRenderer.renderRoundedRect(context, (int)this.tabIndicatorX - 1, tabY - 1, (int)this.tabIndicatorW + 2, tabH + 2, 5, 436266495);
        MusicHudRenderer.renderRoundedRect(context, (int)this.tabIndicatorX + 4, tabY + tabH - 2, (int)this.tabIndicatorW - 8, 2, 1, -16718337);
        if (this.currentTab == 2 && this.paletteColorWheel != null) {
            this.paletteColorWheel.render(context, mouseX, mouseY);
            int curColor = this.getCurrentTargetColor();
            int contentX = this.panelX + 10;
            int contentY = this.panelY + 48;
            int swatchX = contentX + 96;
            int swatchY = contentY + 36;
            int swatchW = this.panelWidth - 20 - 96;
            context.method_51433(this.field_22793, "\u00a77\u0422\u0435\u043a\u0443\u0449\u0438\u0439 \u043e\u0442\u0442\u0435\u043d\u043e\u043a:", swatchX, swatchY, -1, false);
            MusicHudRenderer.renderRoundedRect(context, swatchX - 1, swatchY + 11, swatchW + 2, 18, 4, 0x66FFFFFF);
            MusicHudRenderer.renderRoundedRect(context, swatchX, swatchY + 12, swatchW, 16, 3, 0xFF000000 | curColor);
            context.method_51433(this.field_22793, String.format("\u00a7fHEX: \u00a7e#%06X", curColor & 0xFFFFFF), swatchX, swatchY + 33, -1, false);
            int r = curColor >> 16 & 0xFF;
            int g = curColor >> 8 & 0xFF;
            int b = curColor & 0xFF;
            context.method_51433(this.field_22793, String.format("\u00a78R: %d  G: %d  B: %d", r, g, b), swatchX, swatchY + 43, -5592406, false);
        }
        if (this.currentTab == 3) {
            boolean musicPlaying;
            int contentX = this.panelX + 10;
            int contentY = this.panelY + 48;
            int cardH = this.panelHeight - 56;
            int leftCardW = 100;
            int leftCardX = contentX;
            int leftCardY = contentY;
            MusicHudRenderer.renderRoundedRect(context, leftCardX, leftCardY, leftCardW, cardH, 8, 1074926110);
            MusicHudRenderer.renderRoundedRect(context, leftCardX, leftCardY, leftCardW, cardH, 8, 855696895);
            String playerName = "\u0418\u0433\u0440\u043e\u043a";
            if (mc != null) {
                if (mc.field_1724 != null) {
                    playerName = mc.field_1724.method_5477().getString();
                } else if (mc.method_53462() != null && mc.method_53462().name() != null && !mc.method_53462().name().isEmpty()) {
                    playerName = mc.method_53462().name();
                } else if (mc.method_1548() != null && mc.method_1548().method_1676() != null && !mc.method_1548().method_1676().isEmpty()) {
                    playerName = mc.method_1548().method_1676();
                }
            }
            context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)("\u00a7b\u2726 " + playerName + " \u2726")), leftCardX + leftCardW / 2, leftCardY + 8, -1);
            this.ensurePlayerModel();
            class_2960 skin = null;
            if (mc != null) {
                if (mc.field_1724 != null) {
                    try {
                        class_8685 st = mc.field_1724.method_52814();
                        if (st != null && st.comp_1626() != null) {
                            skin = st.comp_1626().comp_3627();
                        }
                    }
                    catch (Throwable st) {

                    }
                }
                if (skin == null) {
                    class_8685 st;
                    if (this.skinTexturesSupplier == null && mc.method_53462() != null) {
                        this.skinTexturesSupplier = mc.method_1582().method_73544(mc.method_53462(), false);
                    }
                    if (this.skinTexturesSupplier != null && this.skinTexturesSupplier.get() != null && (st = this.skinTexturesSupplier.get()) != null && st.comp_1626() != null) {
                        skin = st.comp_1626().comp_3627();
                    }
                }
                if (skin == null && mc.method_53462() != null) {
                    try {
                        class_8685 st = class_1068.method_52854((GameProfile)mc.method_53462());
                        if (st != null && st.comp_1626() != null) {
                            skin = st.comp_1626().comp_3627();
                        }
                    }
                    catch (Throwable st) {

                    }
                }
            }
            if (skin == null) {
                skin = class_1068.method_4649();
            }
            if (this.playerModel != null && skin != null) {
                int vpX1 = leftCardX + 5;
                int vpY1 = leftCardY + 22;
                int vpX2 = leftCardX + leftCardW - 5;
                int vpY2 = leftCardY + cardH - 24;
                int vpH = vpY2 - vpY1;
                float scale = 0.95f * (float)vpH / 2.125f;
                float centerX = (float)(vpX1 + vpX2) / 2.0f;
                float headCenterY = (float)vpY1 + (float)vpH * 0.22f;
                float headYaw = -((float)mouseX - centerX) / 55.0f;
                float headPitch = ((float)mouseY - headCenterY) / 55.0f;
                headYaw = class_3532.method_15363((float)headYaw, (float)-0.65f, (float)0.65f);
                headPitch = class_3532.method_15363((float)headPitch, (float)-0.45f, (float)0.4f);
                this.playerModel.field_3398.method_41923();
                this.playerModel.field_3394.method_41923();
                this.playerModel.field_3391.method_41923();
                this.playerModel.field_3483.method_41923();
                this.playerModel.field_27433.method_41923();
                this.playerModel.field_3484.method_41923();
                this.playerModel.field_3401.method_41923();
                this.playerModel.field_3486.method_41923();
                this.playerModel.field_3397.method_41923();
                this.playerModel.field_3482.method_41923();
                this.playerModel.field_3392.method_41923();
                this.playerModel.field_3479.method_41923();
                this.playerModel.field_3398.field_3675 = headYaw;
                this.playerModel.field_3398.field_3654 = headPitch;
                this.playerModel.field_27433.field_3654 = -0.05f;
                this.playerModel.field_3401.field_3654 = -0.05f;
                int shadowW = 52;
                int shadowH = 8;
                MusicHudRenderer.renderRoundedRect(context, (int)centerX - shadowW / 2, vpY2 - 2, shadowW, shadowH, 4, 0x33000000);
                try {
                    context.method_70854(this.playerModel, skin, scale, 0.0f, 0.0f, -1.0625f, vpX1, vpY1, vpX2, vpY2);
                }
                catch (Throwable throwable) {

                }
            }
            TrackState state = NowPlayingClient.INSTANCE != null ? NowPlayingClient.INSTANCE.getState() : null;
            boolean bl = musicPlaying = state != null && state.isActive() && "playing".equalsIgnoreCase(state.status());
            String statusBadge = musicPlaying ? "\u00a7a\u25cf \u0421\u043b\u0443\u0448\u0430\u0435\u0442 \u043c\u0443\u0437\u044b\u043a\u0443" : (state != null && state.isActive() ? "\u00a76\u23f8 \u041d\u0430 \u043f\u0430\u0443\u0437\u0435" : "\u00a77\u25cb \u0411\u0435\u0437 \u043c\u0443\u0437\u044b\u043a\u0438");
            context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)statusBadge), leftCardX + leftCardW / 2, leftCardY + cardH - 14, -1);
            int rightCardX = leftCardX + leftCardW + 6;
            int rightCardW = this.panelWidth - 20 - leftCardW - 6;
            int rightCardY = contentY;
            MusicHudRenderer.renderRoundedRect(context, rightCardX, rightCardY, rightCardW, cardH, 8, 1074926110);
            MusicHudRenderer.renderRoundedRect(context, rightCardX, rightCardY, rightCardW, cardH, 8, 0x22FFFFFF);
            int infoY = rightCardY + 8;
            context.method_51433(this.field_22793, "\u00a7e\u2726 \u041c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u0430\u044f \u0441\u0435\u0441\u0441\u0438\u044f", rightCardX + 8, infoY, -1, false);
            context.method_25294(rightCardX + 8, infoY += 13, rightCardX + rightCardW - 8, infoY + 1, 0x22FFFFFF);
            String timeStr = SessionStatsManager.INSTANCE.getFormattedListeningTime();
            context.method_51433(this.field_22793, "\u00a77\u0412\u0440\u0435\u043c\u044f: \u00a7a" + timeStr, rightCardX + 8, infoY += 6, -1, false);
            int tracksCount = SessionStatsManager.INSTANCE.getTotalTracksPlayed();
            context.method_51433(this.field_22793, "\u00a77\u0422\u0440\u0435\u043a\u043e\u0432: \u00a7b" + tracksCount, rightCardX + 8, infoY += 11, -1, false);
            infoY += 11;
            Object topArtist = SessionStatsManager.INSTANCE.getTopArtist();
            if (this.field_22793.method_1727("\u00a77\u0410\u0440\u0442\u0438\u0441\u0442: \u00a7d" + (String)topArtist) > rightCardW - 16) {
                topArtist = this.field_22793.method_27523((String)topArtist, rightCardW - 60) + "...";
            }
            context.method_51433(this.field_22793, "\u00a77\u0410\u0440\u0442\u0438\u0441\u0442: \u00a7d" + (String)topArtist, rightCardX + 8, infoY, -1, false);
            infoY += 11;
            Object topTrack = SessionStatsManager.INSTANCE.getTopTrack();
            if (this.field_22793.method_1727("\u00a77\u0422\u0440\u0435\u043a: \u00a7f" + (String)topTrack) > rightCardW - 16) {
                topTrack = this.field_22793.method_27523((String)topTrack, rightCardW - 55) + "...";
            }
            context.method_51433(this.field_22793, "\u00a77\u0422\u0440\u0435\u043a: \u00a7f" + (String)topTrack, rightCardX + 8, infoY, -1, false);
            context.method_25294(rightCardX + 8, infoY += 13, rightCardX + rightCardW - 8, infoY + 1, 0x22FFFFFF);
        }
        super.method_25394(context, mouseX, mouseY, delta);
        if (HudConfig.INSTANCE.showHelpInspector) {
            this.renderHelpInspectorWindow(context, mouseX, mouseY);
        }
        this.renderLiveHudPreview(context, mouseX, mouseY);
        this.renderLiveSubtitlePreview(context, mouseX, mouseY);
        if (this.dragging) {
            int snapThreshold = 15;
            if (this.hudX < snapThreshold) {
                context.method_25294(0, 0, 2, this.field_22790, -13312);
            }
            if (this.field_22789 - (this.hudX + this.hudWidth) < snapThreshold) {
                context.method_25294(this.field_22789 - 2, 0, this.field_22789, this.field_22790, -13312);
            }
            if (this.hudY < snapThreshold) {
                context.method_25294(0, 0, this.field_22789, 2, -13312);
            }
            if (this.field_22790 - (this.hudY + this.hudHeight) < snapThreshold) {
                context.method_25294(0, this.field_22790 - 2, this.field_22789, this.field_22790, -13312);
            }
        }
        if (CustomBackgroundManager.INSTANCE.isAlertActive()) {
            this.renderInvalidBackgroundAlertModal(context, mouseX, mouseY);
        }
        this.renderFeedbackToast(context);
    }

    private void renderHelpInspectorWindow(class_332 context, int mouseX, int mouseY) {
        MusicHudRenderer.renderRoundedRect(context, this.helpX, this.helpY, this.helpWidth, this.helpHeight, 10, -267119072);
        MusicHudRenderer.renderRoundedRect(context, this.helpX, this.helpY, this.helpWidth, this.helpHeight, 10, 0x2EFFFFFF);
        context.method_25294(this.helpX + 12, this.helpY, this.helpX + this.helpWidth - 12, this.helpY + 1, 0x55FFFFFF);
        context.method_25294(this.helpX + 8, this.helpY + 22, this.helpX + this.helpWidth - 8, this.helpY + 23, 0x22FFFFFF);
        context.method_51433(this.field_22793, "\u00a7b\u2139 \u00a7f\u041f\u043e\u0434\u0441\u043a\u0430\u0437\u043a\u0430", this.helpX + 10, this.helpY + 7, -1, false);
        boolean hoverClose = mouseX >= this.helpX + this.helpWidth - 18 && mouseX <= this.helpX + this.helpWidth - 6 && mouseY >= this.helpY + 4 && mouseY <= this.helpY + 18;
        context.method_51433(this.field_22793, hoverClose ? "\u00a7c\u00d7" : "\u00a77\u00d7", this.helpX + this.helpWidth - 16, this.helpY + 6, -1, false);
        HelpEntry hovered = null;
        for (HelpEntry entry : this.helpEntries) {
            if (mouseX < entry.x || mouseX > entry.x + entry.w || mouseY < entry.y || mouseY > entry.y + entry.h) continue;
            hovered = entry;
            break;
        }
        int textX = this.helpX + 12;
        int textMaxW = this.helpWidth - 24;
        int curY = this.helpY + 28;
        if (hovered != null) {
            MusicHudRenderer.renderRoundedRect(context, textX, curY, textMaxW, 16, 4, 1140882175);
            context.method_51433(this.field_22793, "\u00a7b\u2726 " + hovered.title, textX + 6, curY + 4, -1, false);
            context.method_51433(this.field_22793, "\u00a7e\ud83d\udca1 \u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435:", textX, curY += 22, -1, false);
            curY += 12;
            for (String line : this.wrapText(hovered.description, textMaxW)) {
                context.method_51433(this.field_22793, "\u00a7f" + line, textX, curY, -1, false);
                curY += 10;
            }
            context.method_51433(this.field_22793, "\u00a7a\u26a1 \u0421\u043e\u0432\u0435\u0442:", textX, curY += 8, -1, false);
            curY += 12;
            for (String line : this.wrapText(hovered.recommendation, textMaxW)) {
                context.method_51433(this.field_22793, "\u00a77" + line, textX, curY, -1, false);
                curY += 10;
            }
        } else {
            switch (this.currentTab) {
                case 0: {
                    MusicHudRenderer.renderRoundedRect(context, textX, curY, textMaxW, 16, 4, 1140882175);
                    context.method_51433(this.field_22793, "\u00a7b\u2726 \u0412\u0438\u0434\u0436\u0435\u0442", textX + 6, curY + 4, -1, false);
                    context.method_51433(this.field_22793, "\u00a7e\ud83d\udca1 \u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435:", textX, curY += 22, -1, false);
                    curY += 11;
                    String d0 = "\u041a\u0430\u0440\u0442\u043e\u0447\u043a\u0430 \u0441 \u0442\u0440\u0435\u043a\u043e\u043c, \u043e\u0431\u043b\u043e\u0436\u043a\u043e\u0439 \u0438 \u044d\u043a\u0432\u0430\u043b\u0430\u0439\u0437\u0435\u0440\u043e\u043c.";
                    for (String l : this.wrapText(d0, textMaxW)) {
                        context.method_51433(this.field_22793, "\u00a7f" + l, textX, curY, -1, false);
                        curY += 10;
                    }
                    context.method_51433(this.field_22793, "\u00a7a\u26a1 \u0421\u043e\u0432\u0435\u0442:", textX, curY += 8, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0420\u0430\u0437\u043c\u0435\u0440: \u00a7f\u0411\u043e\u043b\u044c\u0448\u043e\u0439 \u00a77\u0438\u043b\u0438 \u00a7f\u041a\u043e\u043c\u043f\u0430\u043a\u0442", textX, curY += 11, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u041f\u043e\u043a\u0430\u0437: \u00a7f\u0412\u0441\u043f\u043b\u044b\u0432\u0430\u044e\u0449\u0438\u0439 \u00a77(\u043d\u0435 \u043c\u0435\u0448\u0430\u0435\u0442)", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u042d\u043a\u0432\u0430\u043b\u0430\u0439\u0437\u0435\u0440 \u0438 \u0411\u0438\u0442-\u043f\u0443\u043b\u044c\u0441: \u00a7a\u0412\u041a\u041b", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0421\u043a\u0440\u0443\u0433\u043b\u0435\u043d\u0438\u0435: \u00a7f12 px\u00a77, \u0424\u043e\u043d: \u00a7f80%", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u041f\u043e\u0437\u0438\u0446\u0438\u044f: \u043f\u0440\u0430\u0432\u044b\u0439 \u0432\u0435\u0440\u0445\u043d\u0438\u0439 \u0443\u0433\u043e\u043b", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a78\u041d\u0430\u0432\u0435\u0434\u0438\u0442\u0435 \u043a\u0443\u0440\u0441\u043e\u0440 \u043d\u0430 \u043a\u043d\u043e\u043f\u043a\u0443", textX, curY += 14, -5592406, false);
                    context.method_51433(this.field_22793, "\u00a78\u0434\u043b\u044f \u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0430 \u043e\u043f\u0438\u0441\u0430\u043d\u0438\u044f.", textX, curY += 9, -5592406, false);
                    break;
                }
                case 1: {
                    MusicHudRenderer.renderRoundedRect(context, textX, curY, textMaxW, 16, 4, 1140882175);
                    context.method_51433(this.field_22793, "\u00a7b\u2726 \u0421\u0443\u0431\u0442\u0438\u0442\u0440\u044b", textX + 6, curY + 4, -1, false);
                    context.method_51433(this.field_22793, "\u00a7e\ud83d\udca1 \u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435:", textX, curY += 22, -1, false);
                    curY += 11;
                    String d1 = "\u0421\u043b\u043e\u0432\u0430 \u043f\u0435\u0441\u0435\u043d \u0438 \u0440\u0435\u0447\u044c \u0438\u0437 \u0432\u0438\u0434\u0435\u043e \u0432 \u0440\u0435\u0430\u043b\u044c\u043d\u043e\u043c \u0432\u0440\u0435\u043c\u0435\u043d\u0438.";
                    for (String l : this.wrapText(d1, textMaxW)) {
                        context.method_51433(this.field_22793, "\u00a7f" + l, textX, curY, -1, false);
                        curY += 10;
                    }
                    context.method_51433(this.field_22793, "\u00a7a\u26a1 \u0421\u043e\u0432\u0435\u0442:", textX, curY += 8, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0420\u0435\u0436\u0438\u043c: \u00a7f2D \u044d\u043a\u0440\u0430\u043d \u00a77\u0438\u043b\u0438 \u00a7f3D \u0432 \u043c\u0438\u0440\u0435", textX, curY += 11, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f: \u00a7f\u041a\u0430\u0440\u0430\u043e\u043a\u0435 \u00a77\u0438\u043b\u0438 \u00a7f\u041f\u0440\u0443\u0436\u0438\u043d\u0430", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0417\u0430 \u043c\u043e\u0431\u0430\u043c\u0438: \u00a7f\u0421\u043a\u0440\u044b\u0432\u0430\u0442\u044c", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u041f\u043e\u0434\u043b\u043e\u0436\u043a\u0430 \u0438 \u0422\u0435\u043d\u044c: \u00a7a\u0412\u041a\u041b", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u041f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435: \u043f\u043e \u0446\u0435\u043d\u0442\u0440\u0443 \u043d\u0430\u0434 \u0445\u043e\u0442\u0431\u0430\u0440\u043e\u043c", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a78\u0417\u0430\u0436\u043c\u0438\u0442\u0435 \u0442\u0435\u043a\u0441\u0442 \u041b\u041a\u041c \u0434\u043b\u044f \u043f\u0435\u0440\u0435\u043c\u0435\u0449\u0435\u043d\u0438\u044f.", textX, curY += 14, -5592406, false);
                    context.method_51433(this.field_22793, "\u00a78\u0418\u043d\u0442\u0435\u0440\u0444\u0435\u0439\u0441 \u0441\u043a\u0440\u043e\u0435\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438.", textX, curY += 9, -5592406, false);
                    break;
                }
                case 3: {
                    MusicHudRenderer.renderRoundedRect(context, textX, curY, textMaxW, 16, 4, 1140882175);
                    context.method_51433(this.field_22793, "\u00a7b\u2726 \u0418\u043d\u0444\u043e \u0438 \u0441\u0435\u0441\u0441\u0438\u044f", textX + 6, curY + 4, -1, false);
                    context.method_51433(this.field_22793, "\u00a7e\ud83d\udca1 \u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435:", textX, curY += 22, -1, false);
                    curY += 11;
                    String d3 = "\u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043a\u0430 \u043f\u0440\u043e\u0441\u043b\u0443\u0448\u0438\u0432\u0430\u043d\u0438\u044f \u0437\u0430 \u0442\u0435\u043a\u0443\u0449\u0443\u044e \u0438\u0433\u0440\u043e\u0432\u0443\u044e \u0441\u0435\u0441\u0441\u0438\u044e.";
                    for (String l : this.wrapText(d3, textMaxW)) {
                        context.method_51433(this.field_22793, "\u00a7f" + l, textX, curY, -1, false);
                        curY += 10;
                    }
                    context.method_51433(this.field_22793, "\u00a7a\u26a1 \u0412\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u0438:", textX, curY += 8, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0416\u0438\u0432\u0430\u044f 3D-\u043c\u043e\u0434\u0435\u043b\u044c \u0432\u0430\u0448\u0435\u0433\u043e \u0441\u043a\u0438\u043d\u0430", textX, curY += 11, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0413\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0435 \u043f\u0440\u0438\u0433\u043b\u0443\u0448\u0435\u043d\u0438\u0435 \u043c\u0443\u0437\u044b\u043a\u0438", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u041e\u0442\u043f\u0440\u0430\u0432\u043a\u0430 \u043e\u0442\u0447\u0435\u0442\u0430 \u0432 \u0447\u0430\u0442 \u0434\u0440\u0443\u0437\u044c\u044f\u043c", textX, curY += 10, -1, false);
                    break;
                }
                default: {
                    MusicHudRenderer.renderRoundedRect(context, textX, curY, textMaxW, 16, 4, 1140882175);
                    context.method_51433(this.field_22793, "\u00a7b\u2726 \u0426\u0432\u0435\u0442\u0430", textX + 6, curY + 4, -1, false);
                    context.method_51433(this.field_22793, "\u00a7e\ud83d\udca1 \u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435:", textX, curY += 22, -1, false);
                    curY += 11;
                    String d2 = "\u0412\u044b\u0431\u043e\u0440 \u0446\u0432\u0435\u0442\u043e\u0432 \u0444\u043e\u043d\u0430, \u0442\u0435\u043a\u0441\u0442\u0430 \u0438 \u043f\u043e\u043b\u043e\u0441\u044b \u0442\u0440\u0435\u043a\u0430.";
                    for (String l : this.wrapText(d2, textMaxW)) {
                        context.method_51433(this.field_22793, "\u00a7f" + l, textX, curY, -1, false);
                        curY += 10;
                    }
                    context.method_51433(this.field_22793, "\u00a7a\u26a1 \u0421\u043e\u0432\u0435\u0442:", textX, curY += 8, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0424\u043e\u043d: \u00a7f#16161A \u00a77(\u0422\u0451\u043c\u043d\u044b\u0439)", textX, curY += 11, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u041f\u043e\u043b\u043e\u0441\u0430: \u00a7b#007AFF \u00a77(\u0421\u0438\u043d\u0438\u0439)", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u0422\u0435\u043a\u0441\u0442: \u00a7f#FFFFFF \u00a77(\u0411\u0435\u043b\u044b\u0439)", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a77\u2022 \u041a\u0430\u0440\u0430\u043e\u043a\u0435: \u00a7e#FFCC00 \u00a77\u0438\u043b\u0438 \u00a7b#00E5FF", textX, curY += 10, -1, false);
                    context.method_51433(this.field_22793, "\u00a78\u041a\u043b\u0438\u043a\u043d\u0438\u0442\u0435 \u043f\u043e \u043a\u0440\u0443\u0433\u0443 \u0434\u043b\u044f \u0432\u044b\u0431\u043e\u0440\u0430 \u043e\u0442\u0442\u0435\u043d\u043a\u0430.", textX, curY += 14, -5592406, false);
                }
            }
        }
    }

    private void renderLiveHudPreview(class_332 context, int mouseX, int mouseY) {
        int coverY;
        boolean isHovered;
        boolean bl = isHovered = mouseX >= this.hudX && mouseX <= this.hudX + this.hudWidth && mouseY >= this.hudY && mouseY <= this.hudY + this.hudHeight;
        int borderColor = this.dragging ? -13312 : (isHovered ? -301931009 : 0x44FFFFFF);
        float scale = class_3532.method_15363((float)HudConfig.INSTANCE.hudScale, (float)0.2f, (float)4.0f);
        int r = class_3532.method_15340((int)HudConfig.INSTANCE.cornerRadius, (int)0, (int)20);
        int baseW = HudConfig.INSTANCE.getHudBaseWidth();
        int baseH = HudConfig.INSTANCE.getHudBaseHeight();
        boolean isLarge = "LARGE".equalsIgnoreCase(HudConfig.INSTANCE.hudSize);
        MusicHudRenderer.renderRoundedRect(context, this.hudX - 2, this.hudY - 2, this.hudWidth + 4, this.hudHeight + 4, r + 2, borderColor);
        context.method_51448().pushMatrix();
        context.method_51448().translate((float)this.hudX, (float)this.hudY);
        context.method_51448().scale(scale, scale);
        class_2960 customBg = CustomBackgroundManager.INSTANCE.getBackgroundTexture();
        if (customBg != null) {
            context.method_25290(class_10799.field_56883, customBg, 0, 0, 0.0f, 0.0f, baseW, baseH, baseW, baseH);
            int shineColor = 0x55FFFFFF;
            int shadowColor = 0x66000000;
            MusicHudRenderer.renderRoundedBorder(context, 0, 0, baseW, baseH, r, shineColor, shadowColor);
        } else {
            int bgAlpha = (int)(HudConfig.INSTANCE.hudBackgroundAlpha * 255.0f);
            int color = bgAlpha << 24 | HudConfig.INSTANCE.hudBackgroundColor & 0xFFFFFF;
            MusicHudRenderer.renderRoundedRect(context, 0, 0, baseW, baseH, r, color);
        }
        boolean mirror = HudConfig.INSTANCE.autoAdaptLayout && this.hudX < this.field_22789 / 2;
        int coverMargin = Math.max(8, r - 1);
        int coverSize = isLarge ? 52 : 40;
        int coverX = mirror ? baseW - coverSize - coverMargin : coverMargin;
        int n = coverY = isLarge ? 10 : 8;
        if (isLarge) {
            int discCenterX = mirror ? coverX - 10 : coverX + coverSize + 10;
            int discCenterY = coverY + coverSize / 2;
            MusicHudRenderer.renderRoundedRect(context, discCenterX - 18, discCenterY - 18, 36, 36, 18, -586084075);
            MusicHudRenderer.renderRoundedRect(context, discCenterX - 6, discCenterY - 6, 12, 12, 6, -285265067);
            MusicHudRenderer.renderRoundedRect(context, discCenterX - 2, discCenterY - 2, 4, 4, 2, -15658731);
        }
        MusicHudRenderer.renderRoundedRect(context, coverX, coverY, coverSize, coverSize, 6, -14539472);
        context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"\u266a"), coverX + coverSize / 2, coverY + coverSize / 2 - 4, -13312);
        long nowTime = System.currentTimeMillis();
        for (int pIdx = 0; pIdx < 3; ++pIdx) {
            float pCycle = 2400.0f + (float)pIdx * 500.0f;
            float pNorm = (float)((nowTime + (long)pIdx * 800L) % (long)pCycle) / pCycle;
            int pAlpha = (int)(Math.sin((double)pNorm * Math.PI) * 180.0);
            if (pAlpha <= 10) continue;
            float px = (float)coverX + (float)coverSize * 0.5f + (float)Math.sin((double)pIdx * 2.2 + (double)nowTime * 0.0015) * ((float)coverSize * 0.6f);
            float py = (float)coverY + (float)coverSize * 0.5f - pNorm * 22.0f;
            String pSym = pIdx == 0 ? "\u266a" : (pIdx == 1 ? "\u2726" : "\u266b");
            int pColor = pIdx == 1 ? -10496 : -16718337;
            context.method_51433(this.field_22793, pSym, (int)px, (int)py, pAlpha << 24 | pColor & 0xFFFFFF, false);
        }
        int textX = mirror ? coverMargin : coverX + coverSize + 10;
        String badgeText = "\u041c\u0443\u0437\u044b\u043a\u0430";
        int badgeColor = -1442809089;
        int badgeW = this.field_22793.method_1727(badgeText) + 8;
        MusicHudRenderer.renderRoundedRect(context, textX, coverY, badgeW, 9, 4, badgeColor);
        context.method_51433(this.field_22793, badgeText, textX + 4, coverY + 1, -1, false);
        int titleY = coverY + 11;
        context.method_51433(this.field_22793, "\u041f\u0440\u0435\u0434\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440 \u0442\u0440\u0435\u043a\u0430", textX, titleY, -1, true);
        context.method_51433(this.field_22793, "\u0418\u0441\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c", textX, titleY + 11, -6709067, false);
        if (HudConfig.INSTANCE.showEqualizer) {
            int eqX = textX;
            int eqY = titleY + 22;
            long time = System.currentTimeMillis();
            for (int b = 0; b < 10; ++b) {
                float wave = (float)Math.sin((double)time * 0.008 + (double)b * 0.7);
                int barH = 2 + (int)((wave + 1.0f) * 3.0f);
                int barColor = b < 3 ? -43657 : (b < 7 ? -13312 : -16745729);
                context.method_25294(eqX + b * 4, eqY + (8 - barH), eqX + b * 4 + 2, eqY + 8, barColor);
            }
        }
        if (HudConfig.INSTANCE.showProgressBar) {
            int barHeight = class_3532.method_15340((int)HudConfig.INSTANCE.progressBarHeight, (int)2, (int)6);
            int barPad = Math.max(r + 2, 8);
            int barW = baseW - barPad * 2;
            int barY = baseH - barHeight - (isLarge ? 5 : 3);
            int barColor = 0xFF000000 | HudConfig.INSTANCE.progressBarColor & 0xFFFFFF;
            MusicHudRenderer.renderRoundedRect(context, barPad, barY, barW, barHeight, barHeight / 2, 0x77333344);
            int filledW = (int)((float)barW * 0.45f);
            MusicHudRenderer.renderRoundedRect(context, barPad, barY, filledW, barHeight, barHeight / 2, barColor);
            long cycle = 2600L;
            float shimmerCycle = (float)(System.currentTimeMillis() % cycle) / (float)cycle;
            if (shimmerCycle < 0.65f) {
                float st = shimmerCycle / 0.65f;
                float waveCenterX = (float)barPad + (float)filledW * st;
                float waveHalfW = 10.0f;
                int wx1 = (int)Math.max((float)barPad, waveCenterX - waveHalfW);
                int wx2 = (int)Math.min((float)(barPad + filledW), waveCenterX + waveHalfW);
                if (wx2 > wx1) {
                    context.method_25294(wx1, barY, wx2, barY + barHeight, 0x66FFFFFF);
                }
            }
        }
        context.method_51448().popMatrix();
    }

    private void renderLiveSubtitlePreview(class_332 context, int mouseX, int mouseY) {
        boolean isHovered;
        String previewText = "\u041f\u0440\u0435\u0434\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432 \u043f\u0435\u0441\u043d\u0438 \u266a";
        int textW = this.field_22793.method_1727(previewText);
        Objects.requireNonNull(this.field_22793);
        int textH = 9;
        float subScale = class_3532.method_15363((float)HudConfig.INSTANCE.subtitlesScale, (float)0.5f, (float)3.0f);
        int subCenterX = (int)((double)this.field_22789 * HudConfig.INSTANCE.sub2DPositionX);
        int subCenterY = (int)((double)this.field_22790 * HudConfig.INSTANCE.sub2DPositionY);
        int padX = 10;
        int padY = 6;
        int boxW = (int)((float)(textW + padX * 2) * subScale);
        int boxH = (int)((float)(textH + padY * 2) * subScale);
        int boxX = subCenterX - boxW / 2;
        int boxY = subCenterY - boxH / 2;
        this.subPreviewW = boxW;
        this.subPreviewH = boxH;
        boolean bl = isHovered = mouseX >= boxX && mouseX <= boxX + boxW && mouseY >= boxY && mouseY <= boxY + boxH;
        int borderColor = this.dragging2DSub ? -22016 : (isHovered ? -1442809089 : 1140882175);
        MusicHudRenderer.renderRoundedRect(context, boxX - 2, boxY - 2, boxW + 4, boxH + 4, 6, borderColor);
        if (this.dragging2DSub) {
            boolean isCentered = Math.abs(subCenterX - this.field_22789 / 2) < 2;
            String coordText = isCentered ? String.format("\u00a7a\u2726 \u041f\u043e \u0446\u0435\u043d\u0442\u0440\u0443 \u00a77(X: %d%%, Y: %d%%)", (int)(HudConfig.INSTANCE.sub2DPositionX * 100.0), (int)(HudConfig.INSTANCE.sub2DPositionY * 100.0)) : String.format("\u00a7e\u2726 X: %d%%, Y: %d%%", (int)(HudConfig.INSTANCE.sub2DPositionX * 100.0), (int)(HudConfig.INSTANCE.sub2DPositionY * 100.0));
            context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)coordText), subCenterX, Math.max(16, boxY - 14), -1);
            int hintY = boxY + boxH + 18 > this.field_22790 ? boxY - 26 : boxY + boxH + 6;
            context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"\u00a77\u041e\u0442\u043f\u0443\u0441\u0442\u0438\u0442\u0435 \u041b\u041a\u041c \u0434\u043b\u044f \u0444\u0438\u043a\u0441\u0430\u0446\u0438\u0438 \u043f\u043e\u0437\u0438\u0446\u0438\u0438"), subCenterX, hintY, -855638017);
        } else if (isHovered) {
            String coordText = String.format("\u00a7e\u2726 X: %d%%, Y: %d%% \u00a77(\u041f\u043e\u0442\u044f\u043d\u0438\u0442\u0435 \u041b\u041a\u041c)", (int)(HudConfig.INSTANCE.sub2DPositionX * 100.0), (int)(HudConfig.INSTANCE.sub2DPositionY * 100.0));
            context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)coordText), subCenterX, Math.max(16, boxY - 14), -1);
        }
        context.method_51448().pushMatrix();
        long subNow = System.currentTimeMillis();
        float breathY = (float)Math.sin((double)subNow / 520.0) * 1.8f;
        float driftX = (float)Math.cos((double)subNow / 840.0) * 1.0f;
        context.method_51448().translate((float)subCenterX + driftX, (float)subCenterY + breathY);
        context.method_51448().scale(subScale, subScale);
        int startX = -textW / 2;
        int startY = -textH / 2;
        if (HudConfig.INSTANCE.subtitlesBgEnabled) {
            int bgAlpha = (int)(HudConfig.INSTANCE.subtitlesBgAlpha * 255.0f);
            int bgColor = bgAlpha << 24 | HudConfig.INSTANCE.subtitlesBgColor & 0xFFFFFF;
            int r = class_3532.method_15340((int)HudConfig.INSTANCE.subtitlesBgRadius, (int)0, (int)15);
            MusicHudRenderer.renderRoundedRect(context, startX - padX, startY - padY, textW + padX * 2, textH + padY * 2, r, bgColor);
        }
        int textColor = 0xFF000000 | HudConfig.INSTANCE.subtitlesColor & 0xFFFFFF;
        context.method_51433(this.field_22793, previewText, startX, startY, textColor, HudConfig.INSTANCE.subtitlesTextShadow);
        context.method_51448().popMatrix();
    }

    private void triggerNiaEasterEgg(int originX, int originY) {
        String msg;
        ++this.niaEasterEggClicks;
        this.lastNiaClickTime = System.currentTimeMillis();
        Random r = new Random();
        int count = this.niaEasterEggClicks % 10 == 0 ? 80 : 36;
        for (int i = 0; i < count; ++i) {
            float angle = (float)((double)r.nextFloat() * Math.PI * 2.0);
            float speed = 1.8f + r.nextFloat() * (this.niaEasterEggClicks % 10 == 0 ? 6.5f : 4.2f);
            float vx = (float)Math.cos(angle) * speed;
            float vy = (float)Math.sin(angle) * speed - 1.6f;
            String sym = switch (r.nextInt(6)) {
                case 0 -> "\u2764";
                case 1 -> "\u2726";
                case 2 -> "\ud83c\udf38";
                case 3 -> "\u2605";
                case 4 -> "\u266a";
                default -> "\u266b";
            };
            int col = switch (r.nextInt(6)) {
                case 0 -> -49023;
                case 1 -> -10496;
                case 2 -> -16718337;
                case 3 -> -2080517;
                case 4 -> -32597;
                default -> -16711809;
            };
            int life = 35 + r.nextInt(35);
            this.easterEggParticles.add(new EasterEggParticle(originX, originY, vx, vy, col, sym, life));
        }
        try {
            if (this.field_22787 != null && this.field_22787.method_1483() != null) {
                float pitch = 1.0f + (float)(this.niaEasterEggClicks % 8) * 0.12f;
                this.field_22787.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)((class_3414)class_3417.field_14793.comp_349()), (float)pitch, (float)0.9f));
                this.field_22787.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)class_3417.field_26980, (float)1.3f, (float)0.8f));
                if (this.niaEasterEggClicks % 10 == 0) {
                    this.field_22787.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)class_3417.field_14917, (float)1.1f, (float)1.0f));
                    this.field_22787.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)class_3417.field_14709, (float)1.25f, (float)0.85f));
                }
            }
        }
        catch (Exception pitch) {

        }
        if (this.niaEasterEggClicks % 10 == 0) {
            msg = "\u00a76\u2728 \u041c\u0410\u041a\u0421\u0418\u041c\u0410\u041b\u042c\u041d\u0410\u042f \u0421\u0418\u041b\u0410 \u0412\u0414\u041e\u0425\u041d\u041e\u0412\u0415\u041d\u0418\u042f \u041d\u0418\u0418! \ud83c\udf38\ud83d\udc51\u2764";
        } else {
            msg = switch (this.niaEasterEggClicks % 5) {
                case 1 -> "\u00a7d\u2764 \u0410\u0432\u0442\u043e\u0440 \u043c\u043e\u0434\u0430: \u041d\u0438\u044f (Nia_Teppelin_0) \u2726";
                case 2 -> "\u00a7b\u2726 \u00ab\u041c\u0443\u0437\u044b\u043a\u0430 \u0434\u043e\u043b\u0436\u043d\u0430 \u0437\u0432\u0443\u0447\u0430\u0442\u044c \u043a\u0440\u0430\u0441\u0438\u0432\u043e\u00bb \u2014 \u041d\u0438\u044f \u266b";
                case 3 -> "\u00a7e\ud83c\udf38 \u0421\u0435\u043a\u0440\u0435\u0442\u043d\u044b\u0439 \u0440\u0435\u0436\u0438\u043c \u041d\u0438\u0438 \u0430\u043a\u0442\u0438\u0432\u0438\u0440\u043e\u0432\u0430\u043d! \u2728";
                case 4 -> "\u00a7d\ud83d\udc51 \u0421\u043f\u0430\u0441\u0438\u0431\u043e \u0437\u0430 \u0442\u043e, \u0447\u0442\u043e \u0442\u044b \u0434\u0435\u043b\u0430\u0435\u0448\u044c, \u041d\u0438\u044f! \u2764";
                default -> "\u00a7a\u2726 \u0417\u0430\u0440\u044f\u0434 \u0432\u0434\u043e\u0445\u043d\u043e\u0432\u0435\u043d\u0438\u044f \u041d\u0438\u0438: \u00a7e" + this.niaEasterEggClicks * 100 + "% \u00a7d\u2764";
            };
        }
        this.triggerFeedback(msg, this.niaEasterEggClicks % 10 == 0 ? -10496 : 16728193);
    }

    public boolean method_25402(class_11909 click, boolean bl) {
        int mx = (int)click.comp_4798();
        int my = (int)click.comp_4799();
        if (CustomBackgroundManager.INSTANCE.isAlertActive()) {
            this.handleAlertModalClick(mx, my);
            return true;
        }
        int dotY = this.panelY + 11;
        int redX = this.panelX + 14;
        int yellowX = this.panelX + 26;
        int greenX = this.panelX + 38;
        if (mx >= redX - 6 && mx <= redX + 6 && my >= dotY - 6 && my <= dotY + 6) {
            this.method_25419();
            return true;
        }
        if (mx >= yellowX - 6 && mx <= yellowX + 6 && my >= dotY - 6 && my <= dotY + 6) {
            HudConfig.INSTANCE.showHelpInspector = !HudConfig.INSTANCE.showHelpInspector;
            HudConfig.save();
            this.triggerFeedback(HudConfig.INSTANCE.showHelpInspector ? "\u00a7b\u2139 \u041e\u043a\u043d\u043e \u0441\u043f\u0440\u0430\u0432\u043a\u0438: \u0412\u041a\u041b" : "\u00a77\u2139 \u041e\u043a\u043d\u043e \u0441\u043f\u0440\u0430\u0432\u043a\u0438: \u0412\u042b\u041a\u041b", 58879);
            return true;
        }
        if (mx >= greenX - 6 && mx <= greenX + 6 && my >= dotY - 6 && my <= dotY + 6) {
            HudConfig.INSTANCE.resetToDefault();
            this.recalculateHudDimensions();
            this.buildTabWidgets();
            HudConfig.save();
            this.triggerFeedback("\u00a7a\u26a1 \u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0441\u0431\u0440\u043e\u0448\u0435\u043d\u044b \u043a \u044d\u0442\u0430\u043b\u043e\u043d\u0443", 58879);
            return true;
        }
        int iconX = this.panelX + 48;
        int iconY = this.panelY + 4;
        if (mx >= iconX - 3 && mx <= iconX + 17 && my >= iconY - 3 && my <= iconY + 17) {
            this.triggerNiaEasterEgg(iconX + 7, iconY + 7);
            if (this.field_22787 != null) {
                this.field_22787.method_1507((class_437)new NiaAuthorScreen(this));
            }
            return true;
        }
        if (HudConfig.INSTANCE.showHelpInspector && mx >= this.helpX + this.helpWidth - 20 && mx <= this.helpX + this.helpWidth - 4 && my >= this.helpY + 4 && my <= this.helpY + 20) {
            HudConfig.INSTANCE.showHelpInspector = false;
            HudConfig.save();
            return true;
        }
        if (this.currentTab == 2 && this.paletteColorWheel != null && this.paletteColorWheel.mouseClicked(mx, my)) {
            return true;
        }
        if (mx >= this.hudX && mx <= this.hudX + this.hudWidth && my >= this.hudY && my <= this.hudY + this.hudHeight) {
            this.dragging = true;
            this.dragOffsetX = mx - this.hudX;
            this.dragOffsetY = my - this.hudY;
            return true;
        }
        int subCenterX = (int)((double)this.field_22789 * HudConfig.INSTANCE.sub2DPositionX);
        int subCenterY = (int)((double)this.field_22790 * HudConfig.INSTANCE.sub2DPositionY);
        int boxX = subCenterX - this.subPreviewW / 2;
        int boxY = subCenterY - this.subPreviewH / 2;
        if (mx >= boxX && mx <= boxX + this.subPreviewW && my >= boxY && my <= boxY + this.subPreviewH) {
            this.dragging2DSub = true;
            this.dragSubOffsetX = mx - subCenterX;
            this.dragSubOffsetY = my - subCenterY;
            return true;
        }
        return super.method_25402(click, bl);
    }

    public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
        int mx = (int)click.comp_4798();
        int my = (int)click.comp_4799();
        if (this.currentTab == 2 && this.paletteColorWheel != null && this.paletteColorWheel.mouseDragged(mx, my)) {
            return true;
        }
        if (this.dragging) {
            this.hudX = mx - this.dragOffsetX;
            this.hudY = my - this.dragOffsetY;
            this.hudX = Math.max(0, Math.min(this.hudX, this.field_22789 - this.hudWidth));
            this.hudY = Math.max(0, Math.min(this.hudY, this.field_22790 - this.hudHeight));
            int snapThreshold = 15;
            if (this.hudX < snapThreshold) {
                this.hudX = 0;
            }
            if (this.field_22789 - (this.hudX + this.hudWidth) < snapThreshold) {
                this.hudX = this.field_22789 - this.hudWidth;
            }
            if (this.hudY < snapThreshold) {
                this.hudY = 0;
            }
            if (this.field_22790 - (this.hudY + this.hudHeight) < snapThreshold) {
                this.hudY = this.field_22790 - this.hudHeight;
            }
            return true;
        }
        if (this.dragging2DSub) {
            int newCenterX = mx - this.dragSubOffsetX;
            int newCenterY = my - this.dragSubOffsetY;
            if (Math.abs(newCenterX - this.field_22789 / 2) < 16) {
                newCenterX = this.field_22789 / 2;
            }
            HudConfig.INSTANCE.sub2DPositionX = class_3532.method_15350((double)((double)newCenterX / (double)this.field_22789), (double)0.05, (double)0.95);
            HudConfig.INSTANCE.sub2DPositionY = class_3532.method_15350((double)((double)newCenterY / (double)this.field_22790), (double)0.05, (double)0.95);
            return true;
        }
        return super.method_25403(click, deltaX, deltaY);
    }

    public boolean method_25406(class_11909 click) {
        if (this.currentTab == 2 && this.paletteColorWheel != null) {
            this.paletteColorWheel.mouseReleased();
        }
        if (this.dragging) {
            this.dragging = false;
            HudConfig.INSTANCE.setFromAbsolute(this.hudX, this.hudY, this.field_22789, this.field_22790, this.hudWidth, this.hudHeight);
            HudConfig.save();
            return true;
        }
        if (this.dragging2DSub) {
            this.dragging2DSub = false;
            HudConfig.save();
            return true;
        }
        return super.method_25406(click);
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25419() {
        HudConfig.INSTANCE.setFromAbsolute(this.hudX, this.hudY, this.field_22789, this.field_22790, this.hudWidth, this.hudHeight);
        HudConfig.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        } else {
            super.method_25419();
        }
    }

    private void triggerFeedback(String message, int color) {
        this.feedbackToast = message;
        this.feedbackToastTime = System.currentTimeMillis();
        this.feedbackColor = color;
    }

    private void renderFeedbackToast(class_332 context) {
        float alpha;
        if (this.feedbackToast == null) {
            return;
        }
        long elapsed = System.currentTimeMillis() - this.feedbackToastTime;
        if (elapsed > 1800L) {
            this.feedbackToast = null;
            return;
        }
        int animYOffset = 0;
        if (elapsed < 200L) {
            float progress;
            alpha = progress = (float)elapsed / 200.0f;
            animYOffset = (int)((1.0f - progress) * 6.0f);
        } else {
            alpha = elapsed > 1400L ? 1.0f - (float)(elapsed - 1400L) / 400.0f : 1.0f;
        }
        alpha = class_3532.method_15363((float)alpha, (float)0.0f, (float)1.0f);
        int a255 = (int)(alpha * 255.0f);
        if (a255 <= 0) {
            return;
        }
        int toastW = this.field_22793.method_1727(this.feedbackToast) + 26;
        int toastH = 18;
        int toastX = this.panelX + (this.panelWidth - toastW) / 2;
        int toastY = this.panelY + this.panelHeight - toastH - 8 + animYOffset;
        int bgCol = (int)(alpha * 240.0f) << 24 | 0x12141E;
        int borderCol = (int)(alpha * 220.0f) << 24 | this.feedbackColor & 0xFFFFFF;
        MusicHudRenderer.renderRoundedRect(context, toastX, toastY, toastW, toastH, 7, bgCol);
        MusicHudRenderer.renderRoundedRect(context, toastX, toastY, toastW, toastH, 7, borderCol);
        context.method_25294(toastX + 6, toastY + 1, toastX + toastW - 6, toastY + 2, (int)(alpha * 90.0f) << 24 | 0xFFFFFF);
        int dotCol = (int)(alpha * 255.0f) << 24 | this.feedbackColor & 0xFFFFFF;
        MusicHudRenderer.renderRoundedRect(context, toastX + 7, toastY + 6, 6, 6, 3, dotCol);
        context.method_51433(this.field_22793, this.feedbackToast, toastX + 18, toastY + 5, -1, true);
    }

    private void renderInvalidBackgroundAlertModal(class_332 context, int mouseX, int mouseY) {
        if (!CustomBackgroundManager.INSTANCE.isAlertActive()) {
            return;
        }
        if (!this.alertSoundPlayed) {
            this.alertSoundPlayed = true;
            try {
                if (this.field_22787 != null && this.field_22787.method_1483() != null) {
                    this.field_22787.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)((class_3414)class_3417.field_14624.comp_349()), (float)0.6f, (float)0.9f));
                }
            }
            catch (Exception exception) {

            }
        }
        context.method_25294(0, 0, this.field_22789, this.field_22790, -2013265920);
        int modalW = Math.min(420, this.field_22789 - 24);
        int modalH = 185;
        int modalX = (this.field_22789 - modalW) / 2;
        int modalY = (this.field_22790 - modalH) / 2;
        MusicHudRenderer.renderRoundedRect(context, modalX, modalY, modalW, modalH, 12, -267119074);
        MusicHudRenderer.renderRoundedBorder(context, modalX, modalY, modalW, modalH, 12, -56781, -1996536764);
        context.method_25294(modalX + 16, modalY + 1, modalX + modalW - 16, modalY + 2, -1996488705);
        context.method_51433(this.field_22793, "\u00a7c\u00a7l[!] \u041e\u0448\u0438\u0431\u043a\u0430 \u0447\u0442\u0435\u043d\u0438\u044f \u0444\u0430\u0439\u043b\u0430", modalX + 16, modalY + 14, -1, true);
        context.method_51433(this.field_22793, "\u00a7f\u0412 \u043f\u0430\u043f\u043a\u0435 \u00a7eyandexmusichud/backgrounds \u00a7f\u043d\u0430\u0439\u0434\u0435\u043d \u043f\u043e\u0432\u0440\u0435\u0436\u0434\u0451\u043d\u043d\u044b\u0439 \u0444\u0430\u0439\u043b", modalX + 16, modalY + 28, -1118482, false);
        CustomBackgroundManager.InvalidFileEntry inv = CustomBackgroundManager.INSTANCE.getFirstInvalidFile();
        String fName = inv != null ? inv.fileName() : "\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u044b\u0439 \u0444\u0430\u0439\u043b";
        String reason = inv != null ? inv.reason() : "\u0424\u043e\u0440\u043c\u0430\u0442 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f!";
        int cardW = modalW - 32;
        int cardH = 48;
        int cardY = modalY + 44;
        MusicHudRenderer.renderRoundedRect(context, modalX + 16, cardY, cardW, cardH, 6, 1157571123);
        MusicHudRenderer.renderRoundedBorder(context, modalX + 16, cardY, cardW, cardH, 6, -1996545485, 0x44FF4444);
        context.method_51433(this.field_22793, "\u00a7e\u2022 \u0424\u0430\u0439\u043b: \u00a7f" + fName, modalX + 22, cardY + 6, -1, false);
        List<String> wrapped = this.wrapText(reason, cardW - 16);
        for (int i = 0; i < Math.min(2, wrapped.size()); ++i) {
            context.method_51433(this.field_22793, "\u00a7c" + wrapped.get(i), modalX + 22, cardY + 19 + i * 11, -1, false);
        }
        context.method_51433(this.field_22793, "\u00a7a\u2714 \u041f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044e\u0442\u0441\u044f \u0444\u043e\u0440\u043c\u0430\u0442\u044b: .PNG, .JPG, .JPEG, .BMP", modalX + 16, modalY + 101, -11141291, false);
        boolean canConvert = inv != null && inv.canAutoConvert();
        int btnCount = canConvert ? 3 : 2;
        int gap = 6;
        int btnW = (cardW - gap * (btnCount - 1)) / btnCount;
        int btnY = modalY + 122;
        int btnH = 22;
        int curBtnX = modalX + 16;
        boolean hoverF = mouseX >= curBtnX && mouseX <= curBtnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH;
        MusicHudRenderer.renderRoundedRect(context, curBtnX, btnY, btnW, btnH, 5, hoverF ? -869059766 : -1440603597);
        context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"\u041f\u0430\u043f\u043a\u0430 \u0444\u043e\u043d\u043e\u0432"), curBtnX + btnW / 2, btnY + 7, -1);
        curBtnX += btnW + gap;
        if (canConvert) {
            boolean hoverC = mouseX >= curBtnX && mouseX <= curBtnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH;
            MusicHudRenderer.renderRoundedRect(context, curBtnX, btnY, btnW, btnH, 5, hoverC ? -869368526 : -1441047008);
            context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"\u0412 \u0444\u043e\u0440\u043c\u0430\u0442 .PNG"), curBtnX + btnW / 2, btnY + 7, -1);
            curBtnX += btnW + gap;
        }
        boolean hoverR = mouseX >= curBtnX && mouseX <= curBtnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH;
        MusicHudRenderer.renderRoundedRect(context, curBtnX, btnY, btnW, btnH, 5, hoverR ? -871012928 : -1441970271);
        context.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"\u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c"), curBtnX + btnW / 2, btnY + 7, -1);
        int closeX = modalX + modalW - 24;
        int closeY = modalY + 10;
        boolean hoverClose = mouseX >= closeX - 4 && mouseX <= closeX + 18 && mouseY >= closeY - 2 && mouseY <= closeY + 16;
        context.method_51433(this.field_22793, hoverClose ? "\u00a7c\u00a7l[X]" : "\u00a77[X]", closeX, closeY, -1, false);
    }

    private boolean handleAlertModalClick(int mx, int my) {
        if (!CustomBackgroundManager.INSTANCE.isAlertActive()) {
            return false;
        }
        int modalW = Math.min(420, this.field_22789 - 24);
        int modalH = 185;
        int modalX = (this.field_22789 - modalW) / 2;
        int modalY = (this.field_22790 - modalH) / 2;
        if (mx < modalX || mx > modalX + modalW || my < modalY || my > modalY + modalH) {
            CustomBackgroundManager.INSTANCE.dismissAlert();
            this.triggerFeedback("\u00a77\u041f\u0440\u0435\u0434\u0443\u043f\u0440\u0435\u0436\u0434\u0435\u043d\u0438\u0435 \u0441\u043a\u0440\u044b\u0442\u043e", 0xAAAAAA);
            return true;
        }
        int closeX = modalX + modalW - 24;
        int closeY = modalY + 10;
        if (mx >= closeX - 4 && mx <= closeX + 18 && my >= closeY - 2 && my <= closeY + 16) {
            CustomBackgroundManager.INSTANCE.dismissAlert();
            this.triggerFeedback("\u00a77\u041f\u0440\u0435\u0434\u0443\u043f\u0440\u0435\u0436\u0434\u0435\u043d\u0438\u0435 \u0441\u043a\u0440\u044b\u0442\u043e", 0xAAAAAA);
            return true;
        }
        CustomBackgroundManager.InvalidFileEntry inv = CustomBackgroundManager.INSTANCE.getFirstInvalidFile();
        boolean canConvert = inv != null && inv.canAutoConvert();
        int cardW = modalW - 32;
        int btnCount = canConvert ? 3 : 2;
        int gap = 6;
        int btnW = (cardW - gap * (btnCount - 1)) / btnCount;
        int btnY = modalY + 122;
        int btnH = 22;
        int curBtnX = modalX + 16;
        if (mx >= curBtnX && mx <= curBtnX + btnW && my >= btnY && my <= btnY + btnH) {
            CustomBackgroundManager.INSTANCE.openBackgroundsFolder();
            this.triggerFeedback("\u00a7a\ud83d\udcc1 \u041e\u0442\u043a\u0440\u044b\u0442\u0430 \u043f\u0430\u043f\u043a\u0430 backgrounds", 58879);
            return true;
        }
        curBtnX += btnW + gap;
        if (canConvert) {
            if (mx >= curBtnX && mx <= curBtnX + btnW && my >= btnY && my <= btnY + btnH) {
                if (inv != null) {
                    boolean ok = CustomBackgroundManager.INSTANCE.autoConvertFile(inv.fileName());
                    if (ok) {
                        this.refreshBackgroundList();
                        this.buildTabWidgets();
                        this.triggerFeedback("\u00a7a\u2714 \u0424\u0430\u0439\u043b \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043a\u043e\u043d\u0432\u0435\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d \u0432 PNG!", 58879);
                    } else {
                        this.triggerFeedback("\u00a7c\u041e\u0448\u0438\u0431\u043a\u0430 \u043a\u043e\u043d\u0432\u0435\u0440\u0442\u0430\u0446\u0438\u0438 \u0444\u0430\u0439\u043b\u0430", 0xFF5F56);
                    }
                }
                return true;
            }
            curBtnX += btnW + gap;
        }
        if (mx >= curBtnX && mx <= curBtnX + btnW && my >= btnY && my <= btnY + btnH) {
            CustomBackgroundManager.INSTANCE.scanBackgrounds();
            this.refreshBackgroundList();
            this.buildTabWidgets();
            if (CustomBackgroundManager.INSTANCE.hasInvalidFiles()) {
                this.triggerFeedback("\u00a7c\u26a0 \u041e\u0448\u0438\u0431\u043a\u0438 \u0432\u0441\u0451 \u0435\u0449\u0451 \u043d\u0435 \u0443\u0441\u0442\u0440\u0430\u043d\u0435\u043d\u044b!", 0xFF5F56);
            } else {
                this.triggerFeedback("\u00a7a\u2714 \u0412\u0441\u0435 \u0444\u0430\u0439\u043b\u044b \u043f\u0440\u043e\u0432\u0435\u0440\u0435\u043d\u044b: \u043e\u0448\u0438\u0431\u043e\u043a \u043d\u0435\u0442!", 58879);
            }
            return true;
        }
        return mx >= modalX && mx <= modalX + modalW && my >= modalY && my <= modalY + modalH;
    }

    private static int lerpColor(int c1, int c2, float t) {
        if (t <= 0.0f) {
            return c1;
        }
        if (t >= 1.0f) {
            return c2;
        }
        int a1 = c1 >> 24 & 0xFF;
        int r1 = c1 >> 16 & 0xFF;
        int g1 = c1 >> 8 & 0xFF;
        int b1 = c1 & 0xFF;
        int a2 = c2 >> 24 & 0xFF;
        int r2 = c2 >> 16 & 0xFF;
        int g2 = c2 >> 8 & 0xFF;
        int b2 = c2 & 0xFF;
        int a = (int)((float)a1 + (float)(a2 - a1) * t);
        int r = (int)((float)r1 + (float)(r2 - r1) * t);
        int g = (int)((float)g1 + (float)(g2 - g1) * t);
        int b = (int)((float)b1 + (float)(b2 - b1) * t);
        return a << 24 | r << 16 | g << 8 | b;
    }

    private static float easeOutCubic(float t) {
        float f = t - 1.0f;
        return f * f * f + 1.0f;
    }

    public record HelpEntry(int x, int y, int w, int h, String title, String description, String recommendation) {
    }

    private static class EasterEggParticle {
        float x;
        float y;
        float vx;
        float vy;
        int color;
        String symbol;
        int age = 0;
        int maxLife;

        EasterEggParticle(float x, float y, float vx, float vy, int color, String symbol, int maxLife) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.color = color;
            this.symbol = symbol;
            this.maxLife = maxLife;
        }

        boolean update() {
            this.x += this.vx;
            this.y += this.vy;
            this.vy += 0.08f;
            this.vx *= 0.96f;
            return ++this.age < this.maxLife;
        }
    }
}

