package com.example.yandexmusichud.lyrics;

import com.example.yandexmusichud.lyrics.LyricLine;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudioCascadeAligner {
    private static final Pattern RU_VOWELS = Pattern.compile("[\u0430\u0435\u0451\u0438\u043e\u0443\u044b\u044d\u044e\u044f\u0410\u0415\u0401\u0418\u041e\u0423\u042b\u042d\u042e\u042f]");
    private static final Pattern EN_VOWELS = Pattern.compile("[aeiouyAEIOUY]");
    private static final Pattern SECTION_HEADER = Pattern.compile("^\\[.*?\\]$");

    public static List<LyricLine> align(String plainLyrics, byte[] wavBytes, long totalDurationMs) {
        if (plainLyrics == null || plainLyrics.isBlank()) {
            return Collections.emptyList();
        }
        long durationMs = totalDurationMs > 30000L ? totalDurationMs : 180000L;
        List<Stanza> stanzas = StudioCascadeAligner.parseStanzas(plainLyrics);
        if (stanzas.isEmpty()) {
            return Collections.emptyList();
        }
        List<VocalRegion> vocalRegions = null;
        if (wavBytes != null && wavBytes.length > 44) {
            try {
                float[] samples = StudioCascadeAligner.extractPcmSamples(wavBytes);
                if (samples.length >= 16000) {
                    float[] filtered = StudioCascadeAligner.applyVocalBandpassFilter(samples, 16000);
                    vocalRegions = StudioCascadeAligner.detectVocalRegions(filtered, 16000, durationMs);
                }
            }
            catch (Exception exception) {

            }
        }
        if (vocalRegions == null || vocalRegions.isEmpty()) {
            vocalRegions = StudioCascadeAligner.generateAcousticStructure(stanzas.size(), durationMs);
        }
        return StudioCascadeAligner.alignStanzasToVocalRegions(stanzas, vocalRegions, durationMs);
    }

    public static List<Stanza> parseStanzas(String text) {
        ArrayList<Stanza> result = new ArrayList<Stanza>();
        String[] rawLines = text.split("\\r?\\n");
        Stanza current = new Stanza("");
        for (String raw : rawLines) {
            String trimmed = raw.trim();
            if (trimmed.isEmpty()) {
                if (current.lines.isEmpty()) continue;
                result.add(current);
                current = new Stanza("");
                continue;
            }
            if (SECTION_HEADER.matcher(trimmed).matches()) {
                if (!current.lines.isEmpty()) {
                    result.add(current);
                }
                current = new Stanza(trimmed);
                continue;
            }
            current.lines.add(trimmed);
        }
        if (!current.lines.isEmpty()) {
            result.add(current);
        }
        return result;
    }

    public static float[] applyVocalBandpassFilter(float[] input, int sampleRate) {
        double alpha;
        if (input == null || input.length == 0) {
            return input;
        }
        double f0 = 1200.0 / (double)sampleRate;
        double Q = 0.9;
        double omega = Math.PI * 2 * f0;
        double b0 = alpha = Math.sin(omega) / (2.0 * Q);
        double b1 = 0.0;
        double b2 = -alpha;
        double a0 = 1.0 + alpha;
        double a1 = -2.0 * Math.cos(omega);
        double a2 = 1.0 - alpha;
        float[] output = new float[input.length];
        double x1 = 0.0;
        double x2 = 0.0;
        double y1 = 0.0;
        double y2 = 0.0;
        for (int i = 0; i < input.length; ++i) {
            double x0 = input[i];
            double y0 = b0 / a0 * x0 + b1 / a0 * x1 + b2 / a0 * x2 - a1 / a0 * y1 - a2 / a0 * y2;
            output[i] = (float)y0;
            x2 = x1;
            x1 = x0;
            y2 = y1;
            y1 = y0;
        }
        return output;
    }

    public static List<VocalRegion> detectVocalRegions(float[] samples, int sampleRate, long durationMs) {
        int f;
        ArrayList<VocalRegion> regions = new ArrayList<VocalRegion>();
        int frameSize = (int)((double)sampleRate * 0.02);
        int totalFrames = samples.length / frameSize;
        if (totalFrames <= 0) {
            return regions;
        }
        double[] frameEnergy = new double[totalFrames];
        double maxE = 1.0E-5;
        for (f = 0; f < totalFrames; ++f) {
            double rms;
            int offset = f * frameSize;
            double sumSq = 0.0;
            for (int i = 0; i < frameSize; ++i) {
                double s = samples[offset + i];
                sumSq += s * s;
            }
            frameEnergy[f] = rms = Math.sqrt(sumSq / (double)frameSize);
            if (!(rms > maxE)) continue;
            maxE = rms;
        }
        f = 0;
        while (f < totalFrames) {
            int n = f++;
            frameEnergy[n] = frameEnergy[n] / maxE;
        }
        double threshold = 0.16;
        boolean inVoice = false;
        long regionStart = 0L;
        for (int f2 = 0; f2 < totalFrames; ++f2) {
            boolean isVoiced;
            long timeMs = (long)f2 * 20L;
            boolean bl = isVoiced = frameEnergy[f2] > threshold;
            if (isVoiced && !inVoice) {
                inVoice = true;
                regionStart = timeMs;
                continue;
            }
            if (isVoiced || !inVoice) continue;
            int lookahead = Math.min(totalFrames, f2 + 15);
            boolean resumes = false;
            for (int k = f2 + 1; k < lookahead; ++k) {
                if (!(frameEnergy[k] > threshold)) continue;
                resumes = true;
                break;
            }
            if (resumes) continue;
            inVoice = false;
            long regionEnd = timeMs;
            if (regionEnd - regionStart < 2500L) continue;
            regions.add(new VocalRegion(regionStart, regionEnd));
        }
        if (inVoice) {
            regions.add(new VocalRegion(regionStart, Math.min(durationMs, (long)totalFrames * 20L)));
        }
        return regions;
    }

    public static List<VocalRegion> generateAcousticStructure(int stanzaCount, long durationMs) {
        ArrayList<VocalRegion> regions = new ArrayList<VocalRegion>();
        stanzaCount = Math.max(1, stanzaCount);
        long introMs = Math.max(10000L, (long)((double)durationMs * 0.08));
        long outroMs = Math.max(6000L, (long)((double)durationMs * 0.05));
        long singingDuration = durationMs - introMs - outroMs;
        if (stanzaCount == 1) {
            regions.add(new VocalRegion(introMs, durationMs - outroMs));
            return regions;
        }
        long soloDurationMs = durationMs > 120000L ? 12000L : 6000L;
        long netSinging = Math.max(20000L, singingDuration - soloDurationMs);
        long blockDuration = netSinging / (long)stanzaCount;
        int halfPoint = stanzaCount / 2;
        long curPos = introMs;
        for (int s = 0; s < stanzaCount; ++s) {
            if (s == halfPoint) {
                curPos += soloDurationMs;
            }
            long end = Math.min(durationMs - outroMs, curPos + blockDuration);
            regions.add(new VocalRegion(curPos, end));
            curPos = end + 1500L;
        }
        return regions;
    }

    public static List<LyricLine> alignStanzasToVocalRegions(List<Stanza> stanzas, List<VocalRegion> regions, long durationMs) {
        ArrayList<LyricLine> result = new ArrayList<LyricLine>();
        int stanzaCount = stanzas.size();
        int regionCount = regions.size();
        for (int s = 0; s < stanzaCount; ++s) {
            Stanza stanza = stanzas.get(s);
            if (stanza.lines.isEmpty()) continue;
            int regIdx = Math.min(regionCount - 1, (int)((double)s / (double)stanzaCount * (double)regionCount));
            VocalRegion region = regions.get(regIdx);
            long regStart = region.startMs;
            long regEnd = region.endMs;
            long regionDur = Math.max(3000L, regEnd - regStart);
            int lineCount = stanza.lines.size();
            long timePerLine = regionDur / (long)lineCount;
            for (int l = 0; l < lineCount; ++l) {
                String lineText = stanza.lines.get(l).trim();
                if (lineText.isEmpty()) continue;
                long lineStart = regStart + (long)l * timePerLine;
                long maxLineDur = Math.min(6500L, Math.max(2500L, (long)lineText.length() * 160L));
                long lineEnd = Math.min(regEnd, Math.min(lineStart + maxLineDur, lineStart + timePerLine - 300L));
                if (lineEnd <= lineStart) {
                    lineEnd = lineStart + 2200L;
                }
                List<LyricLine.Word> words = StudioCascadeAligner.segmentWordsBySyllables(lineText, lineStart, lineEnd);
                result.add(new LyricLine(lineStart, lineEnd, lineText, words));
            }
        }
        return result;
    }

    public static List<LyricLine.Word> segmentWordsBySyllables(String lineText, long lineStartMs, long lineEndMs) {
        ArrayList<LyricLine.Word> words = new ArrayList<LyricLine.Word>();
        if (lineText == null || lineText.isBlank()) {
            return words;
        }
        String[] tokens = lineText.trim().split("\\s+");
        if (tokens.length == 0) {
            return words;
        }
        long totalDur = Math.max(500L, lineEndMs - lineStartMs);
        if (tokens.length >= 6) {
            long maxRealisticDur = (long)tokens.length * 240L + 300L;
            totalDur = Math.min(totalDur, Math.max(800L, maxRealisticDur));
        }
        int[] weights = new int[tokens.length];
        int totalWeight = 0;
        for (int i = 0; i < tokens.length; ++i) {
            int syllables = StudioCascadeAligner.countSyllables(tokens[i]);
            weights[i] = syllables * 2 + Math.min(6, tokens[i].length());
            totalWeight += weights[i];
        }
        int charOffset = 0;
        long curStart = lineStartMs;
        for (int i = 0; i < tokens.length; ++i) {
            int charEnd;
            String token = tokens[i];
            int charStart = lineText.indexOf(token, charOffset);
            if (charStart < 0) {
                charStart = charOffset;
            }
            charOffset = charEnd = charStart + token.length();
            double ratio = totalWeight > 0 ? (double)weights[i] / (double)totalWeight : 1.0 / (double)tokens.length;
            long wordDur = Math.max(80L, (long)((double)totalDur * ratio));
            long wordEnd = i == tokens.length - 1 ? curStart + wordDur : Math.min(lineEndMs, curStart + (long)((double)wordDur * 0.92));
            words.add(new LyricLine.Word(curStart, wordEnd, token, charStart, charEnd));
            curStart += wordDur;
        }
        return words;
    }

    public static int countSyllables(String word) {
        if (word == null || word.isEmpty()) {
            return 1;
        }
        int count = 0;
        Matcher mRu = RU_VOWELS.matcher(word);
        while (mRu.find()) {
            ++count;
        }
        Matcher mEn = EN_VOWELS.matcher(word);
        while (mEn.find()) {
            ++count;
        }
        return Math.max(1, count);
    }

    public static float[] extractPcmSamples(byte[] wavBytes) {
        if (wavBytes == null || wavBytes.length <= 44) {
            return new float[0];
        }
        int headerSize = 44;
        int pcmLen = wavBytes.length - headerSize;
        int sampleCount = pcmLen / 2;
        float[] samples = new float[sampleCount];
        for (int i = 0; i < sampleCount; ++i) {
            int byteIdx = headerSize + i * 2;
            short raw = (short)(wavBytes[byteIdx] & 0xFF | (wavBytes[byteIdx + 1] & 0xFF) << 8);
            samples[i] = (float)raw / 32768.0f;
        }
        return samples;
    }

    public static AcousticEnergyProfile analyzeAcousticEnergy(byte[] wavBytes) {
        if (wavBytes == null || wavBytes.length <= 44) {
            return new AcousticEnergyProfile(0.0, 0.0, 0.0, 0.0, false, false);
        }
        float[] samples = StudioCascadeAligner.extractPcmSamples(wavBytes);
        if (samples.length < 1600) {
            return new AcousticEnergyProfile(0.0, 0.0, 0.0, 0.0, false, false);
        }
        double sumSqTotal = 0.0;
        for (float s : samples) {
            sumSqTotal += (double)s * (double)s;
        }
        double rmsTotal = Math.sqrt(sumSqTotal / (double)samples.length);
        float[] filtered = StudioCascadeAligner.applyVocalBandpassFilter(samples, 16000);
        double sumSqVocal = 0.0;
        for (float f : filtered) {
            sumSqVocal += (double)f * (double)f;
        }
        double rmsVocal = Math.sqrt(sumSqVocal / (double)filtered.length);
        double vocalRatio = rmsVocal / Math.max(1.0E-4, rmsTotal);
        int frameSize = 320;
        int totalFrames = filtered.length / frameSize;
        int voicedFrames = 0;
        for (int f = 0; f < totalFrames; ++f) {
            int offset = f * frameSize;
            double frameSum = 0.0;
            for (int i = 0; i < frameSize; ++i) {
                double val = filtered[offset + i];
                frameSum += val * val;
            }
            double frameRms = Math.sqrt(frameSum / (double)frameSize);
            if (!(frameRms > 0.012)) continue;
            ++voicedFrames;
        }
        double voicedFraction = totalFrames > 0 ? (double)voicedFrames / (double)totalFrames : 0.0;
        boolean isPlayingSound = rmsTotal > 0.005;
        boolean hasVocalPresence = isPlayingSound && (rmsVocal > 0.014 && voicedFraction > 0.12 || vocalRatio > 0.2 && rmsVocal > 0.008 || voicedFraction > 0.25);
        return new AcousticEnergyProfile(rmsTotal, rmsVocal, vocalRatio, voicedFraction, isPlayingSound, hasVocalPresence);
    }

    public static class Stanza {
        public final String header;
        public final List<String> lines = new ArrayList<String>();

        public Stanza(String header) {
            this.header = header;
        }
    }

    public static class VocalRegion {
        public final long startMs;
        public final long endMs;

        public VocalRegion(long startMs, long endMs) {
            this.startMs = startMs;
            this.endMs = endMs;
        }

        public long getDuration() {
            return this.endMs - this.startMs;
        }
    }

    public record AcousticEnergyProfile(double rmsTotal, double rmsVocal, double vocalRatio, double voicedFrameFraction, boolean isPlayingSound, boolean hasVocalPresence) {
    }
}

