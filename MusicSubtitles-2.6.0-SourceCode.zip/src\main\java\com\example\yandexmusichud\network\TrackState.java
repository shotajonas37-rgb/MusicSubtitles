package com.example.yandexmusichud.network;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public record TrackState(boolean isActive, String title, String artist, String album, String status, long positionMs, long durationMs, String coverHash, long receivedAtMs, String platform, String platformName, String playUrl) {
    public static final TrackState INACTIVE = new TrackState(false, "", "", "", "stopped", 0L, 0L, null, 0L, "music", "\u041c\u0443\u0437\u044b\u043a\u0430", "");
    private static volatile long lastProcessCheckTime = 0L;
    private static volatile boolean cachedSpotifyRunning = false;

    public TrackState(boolean isActive, String title, String artist, String album, String status, long positionMs, long durationMs, String coverHash, long receivedAtMs) {
        this(isActive, title, artist, album, status, positionMs, durationMs, coverHash, receivedAtMs, TrackState.detectPlatform(title, artist, album), TrackState.detectPlatformName(title, artist, album), TrackState.generatePlayUrl(title, artist));
    }

    public static String detectPlatform(String title, String artist, String album) {
        String full = ((title != null ? title : "") + " " + (artist != null ? artist : "") + " " + (album != null ? album : "")).toLowerCase();
        if (full.contains("spotify")) {
            return "spotify";
        }
        if (full.contains("youtube") || full.contains("\u044e\u0442\u0443\u0431") || full.contains("music.youtube") || full.contains("youtu.be") || full.contains("- topic") || full.contains("official video") || full.contains("music video")) {
            return "youtube";
        }
        if (full.contains("vk") || full.contains("\u0432\u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0435") || full.contains("vk music")) {
            return "vk";
        }
        if (full.contains("soundcloud")) {
            return "soundcloud";
        }
        if (full.contains("apple") || full.contains("itunes") || full.contains("apple music")) {
            return "apple";
        }
        if (full.contains("yandex") || full.contains("\u044f\u043d\u0434\u0435\u043a\u0441")) {
            return "yandex";
        }
        if (full.contains("chrome") || full.contains("edge") || full.contains("firefox") || full.contains("opera") || full.contains("brave") || full.contains("browser") || full.contains("\u0431\u0440\u0430\u0443\u0437\u0435\u0440")) {
            return "browser";
        }
        if (full.contains("aimp") || full.contains("vlc") || full.contains("foobar") || full.contains("winamp")) {
            return "player";
        }
        if (TrackState.isSpotifyRunning()) {
            return "spotify";
        }
        return "music";
    }

    public static boolean isSpotifyRunning() {
        long now = System.currentTimeMillis();
        if (now - lastProcessCheckTime < 2500L) {
            return cachedSpotifyRunning;
        }
        lastProcessCheckTime = now;
        try {
            cachedSpotifyRunning = ProcessHandle.allProcesses().anyMatch(p -> {
                String cmd = p.info().command().orElse("").toLowerCase();
                return cmd.contains("spotify.exe") || cmd.endsWith("\\spotify") || cmd.endsWith("/spotify") || cmd.contains("spotify");
            });
        }
        catch (Exception e) {
            cachedSpotifyRunning = false;
        }
        return cachedSpotifyRunning;
    }

    public static String detectPlatformName(String title, String artist, String album) {
        String p;
        return switch (p = TrackState.detectPlatform(title, artist, album)) {
            case "spotify" -> "Spotify";
            case "youtube" -> "YouTube Music";
            case "soundcloud" -> "SoundCloud";
            case "vk" -> "VK \u041c\u0443\u0437\u044b\u043a\u0430";
            case "apple" -> "Apple Music";
            case "yandex" -> "\u042f\u043d\u0434\u0435\u043a\u0441 \u041c\u0443\u0437\u044b\u043a\u0430";
            case "browser" -> "\u0411\u0440\u0430\u0443\u0437\u0435\u0440";
            case "player" -> "\u041c\u0435\u0434\u0438\u0430\u043f\u043b\u0435\u0435\u0440";
            default -> "\u041c\u0443\u0437\u044b\u043a\u0430";
        };
    }

    public String detectPlatformName() {
        if (this.platformName != null && !this.platformName.isBlank()) {
            return this.platformName;
        }
        return TrackState.detectPlatformName(this.title, this.artist, this.album);
    }

    public static String generatePlayUrl(String title, String artist) {
        String p;
        if (title == null || title.isBlank()) {
            return "https://music.yandex.ru";
        }
        String query = URLEncoder.encode(((String)(artist != null ? artist + " " : "") + title).trim(), StandardCharsets.UTF_8);
        return switch (p = TrackState.detectPlatform(title, artist, "")) {
            case "spotify" -> "https://open.spotify.com/search/" + query;
            case "youtube" -> "https://music.youtube.com/search?q=" + query;
            case "soundcloud" -> "https://soundcloud.com/search?q=" + query;
            case "vk" -> "https://vk.com/audio";
            case "apple" -> "https://music.apple.com/search?term=" + query;
            case "yandex" -> "https://music.yandex.ru/search?text=" + query;
            default -> "https://music.yandex.ru/search?text=" + query;
        };
    }

    public boolean isPlaying() {
        return "playing".equalsIgnoreCase(this.status);
    }

    public boolean isPaused() {
        return "paused".equalsIgnoreCase(this.status);
    }

    public long getInterpolatedPositionMs() {
        if (!this.isPlaying() || this.receivedAtMs == 0L) {
            return this.positionMs;
        }
        long elapsed = System.currentTimeMillis() - this.receivedAtMs;
        long interpolated = this.positionMs + elapsed;
        return this.durationMs > 0L ? Math.min(interpolated, this.durationMs) : interpolated;
    }

    public float getProgress() {
        if (this.durationMs <= 0L) {
            return 0.0f;
        }
        return Math.min(1.0f, (float)this.getInterpolatedPositionMs() / (float)this.durationMs);
    }
}

