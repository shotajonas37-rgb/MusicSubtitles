package com.example.yandexmusichud.hud;

import com.example.yandexmusichud.hud.NiaFoxMaidModel;
import net.minecraft.class_591;

public class RunTest {
    public static void main(String[] stringArray) {
        try {
            System.out.println("Starting model creation...");
            class_591 class_5912 = NiaFoxMaidModel.createPlayerModel();
            System.out.println("SUCCESS: Model created successfully! " + String.valueOf(class_5912));
        }
        catch (Throwable throwable) {
            System.out.println("FAILED WITH EXCEPTION:");
            throwable.printStackTrace(System.out);
        }
    }
}

