package com.example.yandexmusichud.lyrics;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.lyrics.GeniusLyricsProvider;
import com.example.yandexmusichud.lyrics.LyricLine;
import com.example.yandexmusichud.lyrics.LyricsConsensusEngine;
import com.example.yandexmusichud.lyrics.StudioCascadeAligner;
import com.example.yandexmusichud.lyrics.SubtitleBubble;
import com.example.yandexmusichud.network.TrackState;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_5250;
import org.joml.Quaternionf;

public class LyricsManager {
    private static final Pattern LRC_LINE_PATTERN = Pattern.compile("^\\[(\\d+):(\\d+(?:\\.\\d+)?)\\](.*)$");
    private static final Pattern ENHANCED_WORD_PATTERN = Pattern.compile("<(\\d+):(\\d+(?:\\.\\d+)?>)([^<]*)");
    private static final Pattern OFFSET_PATTERN = Pattern.compile("^\\[offset:([+-]?\\d+)\\]", 2);
    private static final Pattern NOISE_PATTERN = Pattern.compile("(?i)\\s*[\\[\\(]?(?:official\\s*(?:music\\s*)?(?:video|audio|lyric\\s*video|visualizer|clip)|\u043f\u0440\u0435\u043c\u044c\u0435\u0440\u0430\\s*\u043a\u043b\u0438\u043f\u0430|\u043a\u043b\u0438\u043f|\u043b\u0438\u0440\u0438\u043a\\s*\u0432\u0438\u0434\u0435\u043e|slowed\\s*\\+?\\s*reverb|speed\\s*up|nightcore|sped\\s*up|mood\\s*video|remastered|deluxe|prod\\.?\\s+by|4k|hd|hq|live|acoustic|remix)[\\]\\)]?.*");
    private static final Pattern SPLIT_PATTERN = Pattern.compile("^(.*?)\\s+[-\u2014\u2013]\\s+(.*)$");
    private static final Pattern SPEED_UP_PATTERN = Pattern.compile("(?i)(?:speed\\s*[-_]?\\s*up|sped\\s*[-_]?\\s*up|nightcore|fast\\s*version|fast\\s*ver|\u0443\u0441\u043a\u043e\u0440\u0435\u043d\u043d(?:\u0430\u044f|\u044b\u0439|\u043e\u0435|\u043e))");
    private static final Pattern SLOWED_PATTERN = Pattern.compile("(?i)(?:slowed\\s*(?:(?:\\+|&|and)?\\s*reverb)?|slowed\\s*[-_]?\\s*down|daycore|chopped\\s*(?:and|&)?\\s*screwed|\u0437\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d(?:\u0430\u044f|\u044b\u0439|\u043e\u0435|\u043e))");
    private static final double SPEED_UP_FACTOR = 0.75;
    private static final double SLOWED_FACTOR = 1.3;
    private static final Path LOCAL_LYRICS_DIR = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud").resolve("lyrics");
    public static final long PERCEPTUAL_LEAD_MS = 70L;
    private final Map<String, List<LyricLine>> lyricsCache = new ConcurrentHashMap<String, List<LyricLine>>();
    private final List<SubtitleBubble> activeBubbles = new CopyOnWriteArrayList<SubtitleBubble>();
    private final ExecutorService executor;
    private final Random random = new Random();
    private String currentTrackKey = "";
    private LyricLine lastSpawnedLine = null;
    private LyricLine cachedSprintLine = null;
    private List<LyricLine> cachedSprintChunks = new ArrayList<LyricLine>();
    private LyricLine lastSpawnedSprintChunk = null;
    private int sprintChunkIndex = 0;
    private final AtomicLong currentFetchId = new AtomicLong(0L);
    private volatile String activeFetchTrackKey = null;
    private long lastBlockRaycastTime = 0L;
    private final Set<String> disabledTracks = Collections.newSetFromMap(new ConcurrentHashMap());
    private final Set<String> promptedMismatchTracks = Collections.newSetFromMap(new ConcurrentHashMap());
    private final AtomicInteger acousticMismatchStrikes = new AtomicInteger(0);
    private volatile long lastAcousticCheckTime = 0L;
    private volatile boolean isAcousticChecking = false;
    private final Set<String> autoShutoffTracks = Collections.newSetFromMap(new ConcurrentHashMap());
    private static final Pattern BROWSER_SUFFIX_PATTERN = Pattern.compile("(?i)\\s*[-\u2013\u2014|/]\\s*(?:YouTube\\s*(?:Music)?|\u042f\u043d\u0434\u0435\u043a\u0441\\s*\u041c\u0443\u0437\u044b\u043a\u0430|Yandex\\s*Music|SoundCloud|Spotify|Google\\s*Chrome|Microsoft\\s*Edge|Opera|Firefox|Brave|Vivaldi)\\s*$");
    private static final Pattern PIPE_NOISE_PATTERN = Pattern.compile("(?i)\\s*[|/]\\s*(?:Official|\u041f\u0440\u0435\u043c\u044c\u0435\u0440\u0430|\u041a\u043b\u0438\u043f|Video|Audio|Visualizer|Lyric|Remastered|Mood|Soundtrack|OST).*$");
    private static final Pattern BRACKET_TAGS_PATTERN = Pattern.compile("(?i)\\s*[\\[\\(]\\s*(?:official(?:\\s+(?:music\\s+)?video|\\s+audio|\\s+visualizer|\\s+live|\\s*\\d+k)?|music\\s+video|video|audio|visualizer|lyric\\s+video|lyrics|\u043a\u043b\u0438\u043f|\u043f\u0440\u0435\u043c\u044c\u0435\u0440\u0430(?:\\s+\u043a\u043b\u0438\u043f\u0430|\\s+\u0442\u0440\u0435\u043a\u0430)?(?:\\s*\\d{4})?|\u043e\u0444\u0438\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0439\\s+\u043a\u043b\u0438\u043f|\u0432\u0438\u0434\u0435\u043e\u043a\u043b\u0438\u043f|mood\\s+video|live(?:\\s+performance|\\s+session)?|acoustic(?:\\s+version)?|remastered(?:\\s*\\d{4})?|deluxe(?:\\s+edition)?|prod(?:\\.|\\s+by)?\\s+[^)\\]]+|feat\\.?\\s+[^)\\]]+|ft\\.?\\s+[^)\\]]+|slowed(?:\\s*\\+?\\s*reverb)?|speed\\s*up|sped\\s*up|nightcore|hd|4k|hq|4k\\s*60fps|\\d{4}|ost(?:\\s+.*)?|soundtrack(?:\\s+.*)?)\\s*[\\]\\)]");
    private static final Pattern TRAILING_NOISE_PATTERN = Pattern.compile("(?i)\\s*[-\u2013\u2014]\\s*(?:\u041f\u0440\u0435\u043c\u044c\u0435\u0440\u0430\\s+\u043a\u043b\u0438\u043f\u0430|\u041e\u0444\u0438\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0439\\s+\u043a\u043b\u0438\u043f|Official\\s+Video|Lyric\\s+Video)(?:\\s*\\d{4})?$");

    public void disableCurrentTrack() {
        if (this.currentTrackKey != null && !this.currentTrackKey.isEmpty()) {
            this.disabledTracks.add(this.currentTrackKey);
            this.activeBubbles.clear();
            this.lastSpawnedLine = null;
            this.lastSpawnedSprintChunk = null;
            this.cachedSprintLine = null;
            this.cachedSprintChunks.clear();
        }
    }

    public void enableCurrentTrack() {
        if (this.currentTrackKey != null && !this.currentTrackKey.isEmpty()) {
            this.disabledTracks.remove(this.currentTrackKey);
            this.autoShutoffTracks.add(this.currentTrackKey);
            this.acousticMismatchStrikes.set(0);
        }
    }

    public boolean isCurrentTrackDisabled() {
        return this.currentTrackKey != null && this.disabledTracks.contains(this.currentTrackKey);
    }

    public void reloadCurrentTrack() {
        this.lyricsCache.clear();
        this.promptedMismatchTracks.clear();
        this.autoShutoffTracks.clear();
        this.acousticMismatchStrikes.set(0);
        this.activeBubbles.clear();
        this.lastSpawnedLine = null;
        this.lastSpawnedSprintChunk = null;
        this.cachedSprintLine = null;
        this.cachedSprintChunks.clear();
        this.currentTrackKey = "";
    }

    public LyricsManager() {
        this.executor = Executors.newFixedThreadPool(8, r -> {
            Thread t = new Thread(r, "MusicSubtitles-LyricsWorker");
            t.setDaemon(true);
            return t;
        });
        try {
            Files.createDirectories(LOCAL_LYRICS_DIR, new FileAttribute[0]);
        }
        catch (Exception exception) {

        }
    }

    public List<SubtitleBubble> getActiveBubbles() {
        return this.activeBubbles;
    }

    public void update(TrackState state, int screenWidth, int screenHeight) {
        boolean isSprinting;
        if (!HudConfig.INSTANCE.subtitlesEnabled || state == null || !state.isActive() || state.title().isEmpty()) {
            this.activeBubbles.clear();
            this.lastSpawnedLine = null;
            return;
        }
        String trackKey = this.getTrackKey(state);
        if (!trackKey.equals(this.currentTrackKey)) {
            this.currentTrackKey = trackKey;
            this.lastSpawnedLine = null;
            this.lastSpawnedSprintChunk = null;
            this.cachedSprintLine = null;
            this.cachedSprintChunks.clear();
            this.activeBubbles.clear();
            this.acousticMismatchStrikes.set(0);
            this.lastAcousticCheckTime = System.currentTimeMillis();
            this.fetchLyricsAsync(state);
        } else if (!(this.lyricsCache.containsKey(trackKey) || this.activeFetchTrackKey != null && this.activeFetchTrackKey.equals(trackKey))) {
            this.fetchLyricsAsync(state);
        }
        if (this.disabledTracks.contains(trackKey)) {
            this.activeBubbles.clear();
            this.lastSpawnedLine = null;
            return;
        }
        List<LyricLine> lines = this.lyricsCache.get(trackKey);
        if (lines != null && !lines.isEmpty() && !this.promptedMismatchTracks.contains(trackKey) && this.isLyricsMismatched(lines, state)) {
            this.promptedMismatchTracks.add(trackKey);
            this.sendMismatchNotification();
        }
        long rawPosMs = state.getInterpolatedPositionMs();
        int trackOffset = HudConfig.INSTANCE.getTrackSyncOffset(state.artist(), state.title());
        long currentPosMs = Math.max(0L, rawPosMs + (long)HudConfig.INSTANCE.subtitlesOffsetMs + (long)trackOffset + PERCEPTUAL_LEAD_MS);
        long now = System.currentTimeMillis();
        this.activeBubbles.removeIf(b -> b.isExpired(currentPosMs, now));
        if (lines == null || lines.isEmpty()) {
            return;
        }
        LyricLine activeLine = null;
        for (int i = lines.size() - 1; i >= 0; --i) {
            LyricLine line = lines.get(i);
            if (currentPosMs < line.startMs || currentPosMs >= line.endMs) continue;
            activeLine = line;
            break;
        }
        boolean modeIs3D = "WORLD_3D".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode);
        class_310 mc = class_310.method_1551();
        boolean bl = isSprinting = mc.field_1724 != null && (mc.field_1724.method_5624() || mc.field_1724.method_18798().method_37268() > 0.04 && !mc.field_1724.method_5715());
        if (modeIs3D && HudConfig.INSTANCE.sprintWordsEnabled && isSprinting) {
            this.lastSpawnedLine = null;
            this.activeBubbles.removeIf(b -> !b.isFastPaced);
            this.updateSprint3DBubbles(activeLine, currentPosMs);
        } else {
            this.lastSpawnedSprintChunk = null;
            this.cachedSprintLine = null;
            this.cachedSprintChunks.clear();
            if (activeLine != null) {
                boolean modeIsBlock;
                boolean bl2 = modeIsBlock = "WORLD_BLOCK".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode) || "WORLD_SURFACE".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode);
                if (activeLine != this.lastSpawnedLine) {
                    this.lastSpawnedLine = activeLine;
                    this.spawnBubble(activeLine, screenWidth, screenHeight);
                } else if (modeIsBlock && (!this.hasBlockAttachedBubble() || this.activeBubbles.isEmpty()) && now - this.lastBlockRaycastTime > 250L) {
                    this.lastBlockRaycastTime = now;
                    this.tryAttachToBlock(activeLine);
                }
            } else {
                this.lastSpawnedLine = null;
            }
        }
        this.triggerLiveAcousticSupervisorIfNeeded(state, lines);
    }

    private void updateSprint3DBubbles(LyricLine activeLine, long currentPosMs) {
        if (activeLine == null) {
            this.cachedSprintLine = null;
            this.cachedSprintChunks.clear();
            this.lastSpawnedSprintChunk = null;
            return;
        }
        if (activeLine != this.cachedSprintLine) {
            this.cachedSprintLine = activeLine;
            int chunkSize = Math.max(1, Math.min(3, HudConfig.INSTANCE.sprintWordsChunkSize));
            this.cachedSprintChunks = this.splitLineIntoChunks(activeLine, chunkSize);
            this.lastSpawnedSprintChunk = null;
            this.sprintChunkIndex = 0;
        }
        LyricLine activeChunk = null;
        for (int i = this.cachedSprintChunks.size() - 1; i >= 0; --i) {
            LyricLine chunk = this.cachedSprintChunks.get(i);
            if (currentPosMs < chunk.startMs || currentPosMs >= chunk.endMs) continue;
            activeChunk = chunk;
            break;
        }
        if (activeChunk != null && activeChunk != this.lastSpawnedSprintChunk) {
            this.lastSpawnedSprintChunk = activeChunk;
            this.spawn3DSprintBubble(activeChunk);
        }
    }

    private List<LyricLine> splitLineIntoChunks(LyricLine line, int chunkSize) {
        ArrayList<LyricLine> chunks = new ArrayList<LyricLine>();
        if (line == null || line.text.isEmpty()) {
            return chunks;
        }
        if (line.words != null && !line.words.isEmpty()) {
            List<LyricLine.Word> words = line.words;
            for (int i = 0; i < words.size(); i += chunkSize) {
                int endIdx = Math.min(i + chunkSize, words.size());
                List<LyricLine.Word> subWords = words.subList(i, endIdx);
                StringBuilder sb = new StringBuilder();
                ArrayList<LyricLine.Word> newWordList = new ArrayList<LyricLine.Word>();
                for (int wIdx = 0; wIdx < subWords.size(); ++wIdx) {
                    LyricLine.Word w = subWords.get(wIdx);
                    if (wIdx > 0) {
                        sb.append(" ");
                    }
                    int charStart = sb.length();
                    sb.append(w.text());
                    int charEnd = sb.length();
                    newWordList.add(new LyricLine.Word(w.startMs(), w.endMs(), w.text(), charStart, charEnd));
                }
                long startMs = subWords.get(0).startMs();
                long vocalEnd = subWords.get(subWords.size() - 1).endMs();
                long chunkVocalDur = Math.max(70L, vocalEnd - startMs);
                long trailLinger = Math.max(160L, Math.min(420L, (long)((float)chunkVocalDur * 1.15f)));
                long endMs = vocalEnd + trailLinger;
                chunks.add(new LyricLine(startMs, endMs, vocalEnd, sb.toString(), newWordList));
            }
        } else {
            String[] tokens = line.text.split("\\s+");
            ArrayList<String> validTokens = new ArrayList<String>();
            for (String t : tokens) {
                if (t.isEmpty()) continue;
                validTokens.add(t);
            }
            if (validTokens.isEmpty()) {
                return chunks;
            }
            long rawDur = line.vocalEndMs - line.startMs;
            long lineDur = Math.max(rawDur, 200L);
            for (int i = 0; i < validTokens.size(); i += chunkSize) {
                int endIdx = Math.min(i + chunkSize, validTokens.size());
                List<String> subTokens = validTokens.subList(i, endIdx);
                String chunkText = String.join(" ", subTokens);
                long startMs = line.startMs + (long)((double)i / (double)validTokens.size() * (double)lineDur);
                long vocalEnd = line.startMs + (long)((double)endIdx / (double)validTokens.size() * (double)lineDur);
                long chunkVocalDur = Math.max(70L, vocalEnd - startMs);
                long trailLinger = Math.max(160L, Math.min(420L, (long)((float)chunkVocalDur * 1.15f)));
                long endMs = vocalEnd + trailLinger;
                chunks.add(new LyricLine(startMs, endMs, vocalEnd, chunkText, List.of()));
            }
        }
        return chunks;
    }

    private void spawn3DSprintBubble(LyricLine chunk) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1773 == null) {
            return;
        }
        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null) {
            return;
        }
        class_243 cameraPos = camera.method_71156();
        float pitch = camera.method_19329();
        float yaw = camera.method_19330();
        float dist = Math.max(1.5f, Math.min(12.0f, HudConfig.INSTANCE.sprintWordsDistance));
        float heightOffset = Math.max(-1.5f, Math.min(1.5f, HudConfig.INSTANCE.sprintWordsHeight));
        class_243 forward = class_243.method_1030((float)pitch, (float)yaw).method_1029();
        class_243 right = class_243.method_1030((float)0.0f, (float)(yaw + 90.0f)).method_1029();
        class_243 camUp = right.method_1036(forward).method_1029();
        if (camUp.field_1351 < 0.0) {
            camUp = camUp.method_1021(-1.0);
        }
        double speedSq = mc.field_1724.method_18798().method_37268();
        float speedLead = (float)Math.min(2.5, Math.sqrt(speedSq) * 3.5);
        float effectiveDist = dist + speedLead;
        float spread = Math.max(0.05f, Math.min(1.0f, HudConfig.INSTANCE.sprintWordsSpread));
        float horizExtent = effectiveDist * spread * 0.7f;
        float vertExtent = effectiveDist * (spread * 0.35f);
        float hOffset = (this.random.nextFloat() - 0.5f) * 2.0f * horizExtent;
        float vOffset = (this.random.nextFloat() - 0.5f) * 2.0f * vertExtent;
        class_243 spawnPos = cameraPos.method_1019(forward.method_1021((double)effectiveDist)).method_1019(right.method_1021((double)hOffset)).method_1019(camUp.method_1021((double)(heightOffset + vOffset)));
        double playerFeetY = mc.field_1724.method_23318();
        if (spawnPos.field_1351 < playerFeetY + 0.3) {
            spawnPos = new class_243(spawnPos.field_1352, playerFeetY + 0.3 + (double)this.random.nextFloat() * 0.25, spawnPos.field_1350);
        }
        double dx = cameraPos.field_1352 - spawnPos.field_1352;
        double dz = cameraPos.field_1350 - spawnPos.field_1350;
        float lookAngle = (float)Math.atan2(dx, dz);
        Quaternionf rotation = new Quaternionf().rotationY(lookAngle);
        int maxTrail = Math.max(1, Math.min(HudConfig.INSTANCE.sprintWordsTrailLength, 8));
        while (this.activeBubbles.size() >= maxTrail) {
            this.activeBubbles.remove(0);
        }
        this.activeBubbles.add(new SubtitleBubble(chunk, spawnPos, rotation, false, true));
    }

    private void spawnBubble(LyricLine line, int screenWidth, int screenHeight) {
        class_310 mc = class_310.method_1551();
        boolean isSprinting = mc.field_1724 != null && (mc.field_1724.method_5624() || mc.field_1724.method_18798().method_37268() > 0.04);
        String mode = HudConfig.INSTANCE.subtitlesMode;
        if ("WORLD_BLOCK".equalsIgnoreCase(mode) || "WORLD_SURFACE".equalsIgnoreCase(mode)) {
            this.spawnBlockAttachedBubble(line, isSprinting);
        } else if ("WORLD_3D".equalsIgnoreCase(mode)) {
            this.spawn3DWorldBubble(line, isSprinting);
        } else if ("HUD_BOTTOM".equalsIgnoreCase(mode)) {
            this.spawn2DBottomBubble(line, screenWidth, screenHeight, isSprinting);
        } else {
            this.spawn2DRandomBubble(line, screenWidth, screenHeight, isSprinting);
        }
    }

    private SubtitleBubble createBlockBubble(LyricLine line, boolean isFastPaced) {
        class_243 lookVec;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1773 == null) {
            return null;
        }
        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null) {
            return null;
        }
        class_243 cameraPos = camera.method_71156();
        class_3959 context = new class_3959(cameraPos, cameraPos.method_1019((lookVec = mc.field_1724.method_5828(1.0f)).method_1021(24.0)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)mc.field_1724);
        class_3965 hit = mc.field_1687.method_17742(context);
        if (hit.method_17783() == class_239.class_240.field_1332) {
            class_2350 side = hit.method_17780();
            class_243 hitPos = hit.method_17784();
            double offsetDistance = 0.065;
            class_243 normal = class_243.method_24954((class_2382)side.method_62675());
            class_243 surfacePos = hitPos.method_1019(normal.method_1021(offsetDistance));
            Quaternionf rotation = new Quaternionf();
            float yaw = mc.field_1724.method_36454();
            switch (side) {
                case field_11036: {
                    rotation.rotateY((float)Math.toRadians(180.0f - yaw));
                    rotation.rotateX((float)Math.toRadians(-90.0));
                    break;
                }
                case field_11033: {
                    rotation.rotateY((float)Math.toRadians(180.0f - yaw));
                    rotation.rotateX((float)Math.toRadians(90.0));
                    break;
                }
                case field_11043: {
                    rotation.rotateY((float)Math.toRadians(180.0));
                    break;
                }
                case field_11035: {
                    rotation.rotateY(0.0f);
                    break;
                }
                case field_11039: {
                    rotation.rotateY((float)Math.toRadians(-90.0));
                    break;
                }
                case field_11034: {
                    rotation.rotateY((float)Math.toRadians(90.0));
                }
            }
            return new SubtitleBubble(line, surfacePos, rotation, true, isFastPaced);
        }
        return null;
    }

    private void spawnBlockAttachedBubble(LyricLine line, boolean isFastPaced) {
        SubtitleBubble bubble = this.createBlockBubble(line, isFastPaced);
        if (bubble != null) {
            this.activeBubbles.clear();
            this.activeBubbles.add(bubble);
        } else {
            this.spawn3DWorldBubble(line, isFastPaced);
        }
    }

    private void tryAttachToBlock(LyricLine line) {
        class_310 mc = class_310.method_1551();
        boolean isSprinting = mc.field_1724 != null && (mc.field_1724.method_5624() || mc.field_1724.method_18798().method_37268() > 0.04);
        SubtitleBubble bubble = this.createBlockBubble(line, isSprinting);
        if (bubble != null) {
            this.activeBubbles.clear();
            this.activeBubbles.add(bubble);
        }
    }

    private boolean hasBlockAttachedBubble() {
        for (SubtitleBubble b : this.activeBubbles) {
            if (!b.isSurfaceAttached) continue;
            return true;
        }
        return false;
    }

    private void spawn3DWorldBubble(LyricLine line, boolean isFastPaced) {
        float baseDist;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1773 == null) {
            return;
        }
        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null) {
            return;
        }
        class_243 cameraPos = camera.method_71156();
        float min = baseDist = Math.max(4.0f, Math.min(12.0f, HudConfig.INSTANCE.subtitlesDistance));
        float max = baseDist + 1.5f;
        float distance = min + this.random.nextFloat() * (max - min);
        if (isFastPaced) {
            double speedSq = mc.field_1724.method_18798().method_37268();
            distance += (float)Math.min(2.5, Math.sqrt(speedSq) * 3.5);
        }
        float yawOffset = (this.random.nextFloat() - 0.5f) * (isFastPaced ? 40.0f : 90.0f);
        float pitchOffset = (this.random.nextFloat() - 0.5f) * (isFastPaced ? 20.0f : 40.0f);
        float yaw = camera.method_19330() + yawOffset;
        float pitch = camera.method_19329() + pitchOffset;
        pitch = Math.max(-50.0f, Math.min(50.0f, pitch));
        class_243 direction = class_243.method_1030((float)pitch, (float)yaw).method_1029();
        class_243 spawnPos = cameraPos.method_1019(direction.method_1021((double)distance));
        double playerFeetY = mc.field_1724.method_23318();
        if (spawnPos.field_1351 < playerFeetY + 0.3) {
            spawnPos = new class_243(spawnPos.field_1352, playerFeetY + 0.3 + (double)this.random.nextFloat() * 0.4, spawnPos.field_1350);
        }
        double dx = cameraPos.field_1352 - spawnPos.field_1352;
        double dz = cameraPos.field_1350 - spawnPos.field_1350;
        float lookAngle = (float)Math.atan2(dx, dz);
        Quaternionf rotation = new Quaternionf().rotationY(lookAngle);
        this.activeBubbles.clear();
        this.activeBubbles.add(new SubtitleBubble(line, spawnPos, rotation, false, isFastPaced));
    }

    private void spawn2DRandomBubble(LyricLine line, int screenWidth, int screenHeight, boolean isFastPaced) {
        int paddingX = 80;
        int paddingY = 80;
        int minX = paddingX;
        int maxX = Math.max(minX + 1, screenWidth - paddingX - 160);
        int minY = paddingY;
        int maxY = Math.max(minY + 1, screenHeight - paddingY - 40);
        float x = minX + this.random.nextInt(Math.max(1, maxX - minX));
        float y = minY + this.random.nextInt(Math.max(1, maxY - minY));
        this.activeBubbles.clear();
        this.activeBubbles.add(new SubtitleBubble(line, x, y, isFastPaced));
    }

    private void spawn2DBottomBubble(LyricLine line, int screenWidth, int screenHeight, boolean isFastPaced) {
        class_310 mc = class_310.method_1551();
        class_327 textRenderer = mc.field_1772;
        int maxAllowedWidth = (int)((float)screenWidth * 0.65f);
        List<LyricLine.SubLine> subLines = line.getSubLines(textRenderer, maxAllowedWidth);
        int maxWidth = 0;
        for (LyricLine.SubLine sl : subLines) {
            if (sl.width() <= maxWidth) continue;
            maxWidth = sl.width();
        }
        Objects.requireNonNull(textRenderer);
        int lineHeight = 9 + 3;
        int totalHeight = subLines.size() * lineHeight;
        double posX = HudConfig.INSTANCE.sub2DPositionX;
        double posY = HudConfig.INSTANCE.sub2DPositionY;
        float x = (float)((double)screenWidth * posX) - (float)maxWidth * 0.5f;
        float y = (float)((double)screenHeight * posY) - (float)totalHeight * 0.5f;
        this.activeBubbles.clear();
        this.activeBubbles.add(new SubtitleBubble(line, x, y, isFastPaced));
    }

    private String getTrackKey(TrackState state) {
        return state.artist() + "___" + state.title();
    }

    private void fetchLyricsAsync(TrackState state) {
        String key = this.getTrackKey(state);
        if (this.lyricsCache.containsKey(key)) {
            return;
        }
        long fetchId = this.currentFetchId.incrementAndGet();
        this.activeFetchTrackKey = key;
        CompletableFuture.runAsync(() -> {
            try {
                boolean mismatch;
                if (fetchId != this.currentFetchId.get()) {
                    return;
                }
                String rawTitle = state.title();
                String rawArtist = state.artist();
                long durationSec = state.durationMs() / 1000L;
                FetchResult result = this.searchMultiProviderLyrics(rawTitle, rawArtist, durationSec, fetchId);
                if (fetchId != this.currentFetchId.get()) {
                    return;
                }
                List<LyricLine> lines = result != null && result.lines() != null ? result.lines() : Collections.emptyList();
                boolean bl = mismatch = result != null && result.possibleMismatch() || this.isLyricsMismatched(lines, state);
                if (!lines.isEmpty()) {
                    this.lyricsCache.put(key, lines);
                    if (mismatch && !this.promptedMismatchTracks.contains(key)) {
                        this.promptedMismatchTracks.add(key);
                        this.sendMismatchNotification();
                    }
                } else {
                    this.lyricsCache.put(key, Collections.emptyList());
                }
            }
            catch (Exception e) {
                if (fetchId == this.currentFetchId.get()) {
                    this.lyricsCache.put(key, Collections.emptyList());
                }
            }
            finally {
                if (fetchId == this.currentFetchId.get()) {
                    this.activeFetchTrackKey = null;
                }
            }
        }, this.executor);
    }

    private void sendMismatchNotification() {
        class_310 mc = class_310.method_1551();
        if (mc == null) {
            return;
        }
        mc.execute(() -> {
            if (mc.field_1705 != null && mc.field_1705.method_1743() != null) {
                class_5250 msg = class_2561.method_43470((String)"\u00a76[\u041c\u0443\u0437\u044b\u043a\u0430] \u00a7f\u041a\u0430\u0436\u0435\u0442\u0441\u044f, \u0442\u0435\u043a\u0441\u0442 \u043f\u0435\u0441\u043d\u0438 \u0438 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u044b \u0440\u0430\u0441\u0445\u043e\u0434\u044f\u0442\u0441\u044f. ");
                class_5250 cancelBtn = class_2561.method_43470((String)"\u00a7c\u00a7n[\u041e\u0442\u043c\u0435\u043d\u0438\u0442\u044c]\u00a7r").method_27694(style -> style.method_10977(class_124.field_1061).method_10982(Boolean.valueOf(true)).method_30938(Boolean.valueOf(true)).method_10958((class_2558)new class_2558.class_10609("/musicsubtitles cancel")).method_10949((class_2568)new class_2568.class_10613((class_2561)class_2561.method_43470((String)"\u00a7e\u041d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u043e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u044b \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u043f\u0435\u0441\u043d\u0438"))));
                msg.method_10852((class_2561)cancelBtn);
                mc.field_1705.method_1743().method_1812((class_2561)msg);
            }
        });
    }

    public void pushLiveCaption(String text, long durationMs) {
        if (text == null || text.trim().isEmpty()) {
            return;
        }
        long dur = durationMs > 0L ? durationMs : 3500L;
        LyricLine line = new LyricLine(0L, dur, text.trim(), null);
        class_310 mc = class_310.method_1551();
        if (mc != null && mc.method_22683() != null) {
            int sw = mc.method_22683().method_4486();
            int sh = mc.method_22683().method_4502();
            mc.execute(() -> this.spawnBubble(line, sw, sh));
        }
    }

    public void pushTranscript(String videoTitle, List<LyricLine> lines) {
        if (lines == null || lines.isEmpty()) {
            return;
        }
        if (videoTitle != null && !videoTitle.isEmpty()) {
            this.lyricsCache.put(videoTitle, lines);
        }
        if (this.currentTrackKey != null && !this.currentTrackKey.isEmpty()) {
            this.lyricsCache.put(this.currentTrackKey, lines);
        }
        System.out.println("[MusicSubtitles] Received live transcript with " + lines.size() + " lines for: " + videoTitle);
    }

    private void triggerLiveAcousticSupervisorIfNeeded(TrackState state, List<LyricLine> lines) {
        if (state == null || !state.isActive() || state.isPaused()) {
            return;
        }
        if (lines == null || lines.isEmpty()) {
            return;
        }
        String trackKey = this.currentTrackKey;
        if (trackKey == null || trackKey.isEmpty()) {
            return;
        }
        if (this.disabledTracks.contains(trackKey) || this.autoShutoffTracks.contains(trackKey)) {
            return;
        }
        if (this.isAcousticChecking) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastAcousticCheckTime < 6500L) {
            return;
        }
        long rawPosMs = state.getInterpolatedPositionMs();
        long durationMs = state.durationMs();
        if (durationMs > 20000L && (rawPosMs < 4000L || rawPosMs > durationMs - 5000L)) {
            return;
        }
        this.lastAcousticCheckTime = now;
        this.isAcousticChecking = true;
        this.executor.submit(() -> {
            try {
                this.checkLiveAcousticMatchAsync(state, lines, trackKey);
            }
            catch (Exception exception) {
            }
            finally {
                this.isAcousticChecking = false;
            }
        });
    }

    private void checkLiveAcousticMatchAsync(TrackState state, List<LyricLine> lines, String trackKey) {
        if (!trackKey.equals(this.currentTrackKey) || this.disabledTracks.contains(trackKey)) {
            return;
        }
        int port = this.resolveHelperPort();
        if (port <= 0) {
            return;
        }
        String helperBase = "http://127.0.0.1:" + port;
        int captureDurationMs = 2500;
        long windowStartMs = state.getInterpolatedPositionMs();
        long windowEndMs = windowStartMs + (long)captureDurationMs;
        String startResp = LyricsManager.httpPost(helperBase + "/capture/start", "{\"durationMs\":" + captureDurationMs + "}", 2000);
        if (startResp == null || startResp.isEmpty()) {
            return;
        }
        try {
            Thread.sleep(captureDurationMs + 250);
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
        if (!trackKey.equals(this.currentTrackKey) || this.disabledTracks.contains(trackKey)) {
            return;
        }
        byte[] wavBytes = LyricsManager.httpGetBytes(helperBase + "/capture/result", 3000);
        if (wavBytes == null || wavBytes.length <= 44) {
            return;
        }
        StudioCascadeAligner.AcousticEnergyProfile profile = StudioCascadeAligner.analyzeAcousticEnergy(wavBytes);
        if (!profile.isPlayingSound()) {
            return;
        }
        boolean lyricsExpectVocals = false;
        for (LyricLine line : lines) {
            if (Math.max(windowStartMs, line.startMs) >= Math.min(windowEndMs, line.endMs)) continue;
            lyricsExpectVocals = true;
            break;
        }
        if (lyricsExpectVocals && !profile.hasVocalPresence()) {
            int strikes = this.acousticMismatchStrikes.incrementAndGet();
            if (strikes == 3) {
                System.out.println("[MusicSubtitles] Acoustic diagnostic: lyrics expect vocals, but live audio is instrumental/quiet at " + windowStartMs + "ms");
            }
        } else if (!lyricsExpectVocals && profile.hasVocalPresence() && profile.rmsVocal() > 0.025 && profile.vocalRatio() > 0.35) {
            int strikes = this.acousticMismatchStrikes.incrementAndGet();
            if (strikes == 3) {
                System.out.println("[MusicSubtitles] Acoustic diagnostic: lyrics expect pause, but live audio has loud vocals at " + windowStartMs + "ms");
            }
        } else if (lyricsExpectVocals && profile.hasVocalPresence()) {
            this.acousticMismatchStrikes.updateAndGet(s -> Math.max(0, s - 1));
        }
    }

    private int resolveHelperPort() {
        if (HudConfig.INSTANCE.helperPort > 0) {
            return HudConfig.INSTANCE.helperPort;
        }
        try {
            Path portFile;
            String temp = System.getenv("TEMP");
            if (temp == null) {
                temp = System.getProperty("java.io.tmpdir");
            }
            if (Files.exists(portFile = Path.of(temp, new String[0]).resolve("yandexmusichud_port.txt"), new LinkOption[0])) {
                return Integer.parseInt(Files.readString(portFile).trim());
            }
        }
        catch (Exception exception) {

        }
        return 38472;
    }

    private FetchResult searchMultiProviderLyrics(String rawTitle, String rawArtist, long durationSec, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        boolean isSpeedUp = SPEED_UP_PATTERN.matcher(rawTitle).find() || SPEED_UP_PATTERN.matcher(rawArtist).find();
        boolean isSlowed = SLOWED_PATTERN.matcher(rawTitle).find() || SLOWED_PATTERN.matcher(rawArtist).find();
        List<LyricLine> local = this.checkLocalLyrics(rawTitle, rawArtist);
        if (local != null && !local.isEmpty()) {
            if (isSpeedUp || isSlowed) {
                return new FetchResult(this.applySpeedAdjustment(local, durationSec, isSpeedUp, isSlowed), false);
            }
            return new FetchResult(local, false);
        }
        List<LyricLine> pushed = this.lyricsCache.get(rawTitle);
        if (pushed == null && !rawTitle.isEmpty()) {
            pushed = this.lyricsCache.get(this.cleanForSearch(rawTitle));
        }
        if (pushed != null && !pushed.isEmpty()) {
            return new FetchResult(pushed, false);
        }
        String cleanTitle = this.cleanForSearch(rawTitle);
        String cleanArtist = this.cleanForSearch(rawArtist);
        Matcher m = SPLIT_PATTERN.matcher(cleanTitle);
        if (m.find()) {
            String extractedArtist = this.cleanForSearch(m.group(1));
            String extractedTitle = this.cleanForSearch(m.group(2));
            if (!extractedArtist.isEmpty() && !extractedTitle.isEmpty()) {
                cleanArtist = extractedArtist;
                cleanTitle = extractedTitle;
            }
        }
        String targetTitle = cleanTitle;
        String targetArtist = cleanArtist;
        String primaryArtist = this.extractPrimaryArtist(targetArtist);
        long queryDurationSec = isSpeedUp || isSlowed ? 0L : durationSec;
        ArrayList<CompletableFuture<LyricsConsensusEngine.Candidate>> futures = new ArrayList<CompletableFuture<LyricsConsensusEngine.Candidate>>();
        futures.add(CompletableFuture.supplyAsync(() -> {
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            return this.wrapSyncedResult("YANDEX_SYNCED", this.queryYandexMusic(targetTitle, targetArtist, queryDurationSec, fetchId));
        }, this.executor));
        futures.add(CompletableFuture.supplyAsync(() -> {
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            return this.queryGeniusLyrics(targetTitle, targetArtist, fetchId);
        }, this.executor));
        if (!primaryArtist.equals(targetArtist)) {
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.queryGeniusLyrics(targetTitle, primaryArtist, fetchId);
            }, this.executor));
        }
        if (!targetTitle.isEmpty() && !targetArtist.isEmpty()) {
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.queryLrclibGetCandidate(targetTitle, targetArtist, queryDurationSec, fetchId);
            }, this.executor));
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("LRCLIB_SYNCED", this.queryLrclibSearchSynced(targetArtist + " " + targetTitle, queryDurationSec, targetTitle, targetArtist, fetchId));
            }, this.executor));
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("NETEASE", this.queryNeteaseLyrics(targetArtist + " " + targetTitle, targetTitle, targetArtist, fetchId));
            }, this.executor));
            if (!primaryArtist.equals(targetArtist)) {
                futures.add(CompletableFuture.supplyAsync(() -> {
                    if (fetchId != this.currentFetchId.get()) {
                        return null;
                    }
                    return this.queryLrclibGetCandidate(targetTitle, primaryArtist, queryDurationSec, fetchId);
                }, this.executor));
                futures.add(CompletableFuture.supplyAsync(() -> {
                    if (fetchId != this.currentFetchId.get()) {
                        return null;
                    }
                    return this.wrapSyncedResult("LRCLIB_SYNCED", this.queryLrclibSearchSynced(primaryArtist + " " + targetTitle, queryDurationSec, targetTitle, primaryArtist, fetchId));
                }, this.executor));
                futures.add(CompletableFuture.supplyAsync(() -> {
                    if (fetchId != this.currentFetchId.get()) {
                        return null;
                    }
                    return this.wrapSyncedResult("NETEASE", this.queryNeteaseLyrics(primaryArtist + " " + targetTitle, targetTitle, primaryArtist, fetchId));
                }, this.executor));
            }
        }
        if (!targetTitle.isEmpty()) {
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("LRCLIB_SYNCED", this.queryLrclibSearchSynced(targetTitle, queryDurationSec, targetTitle, targetArtist, fetchId));
            }, this.executor));
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("NETEASE", this.queryNeteaseLyrics(targetTitle, targetTitle, targetArtist, fetchId));
            }, this.executor));
        }
        if (!targetTitle.isEmpty() && !targetArtist.isEmpty()) {
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("LRCLIB_SYNCED", this.queryLrclibSearchSynced(targetTitle + " " + targetArtist, queryDurationSec, targetTitle, targetArtist, fetchId));
            }, this.executor));
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("NETEASE", this.queryNeteaseLyrics(targetTitle + " " + targetArtist, targetTitle, targetArtist, fetchId));
            }, this.executor));
        }
        if (!rawTitle.equals(targetTitle) || !rawArtist.equals(targetArtist)) {
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("LRCLIB_SYNCED", this.queryLrclibSearchSynced(rawArtist + " " + rawTitle, queryDurationSec, targetTitle, targetArtist, fetchId));
            }, this.executor));
            futures.add(CompletableFuture.supplyAsync(() -> {
                if (fetchId != this.currentFetchId.get()) {
                    return null;
                }
                return this.wrapSyncedResult("NETEASE", this.queryNeteaseLyrics(rawArtist + " " + rawTitle, targetTitle, targetArtist, fetchId));
            }, this.executor));
        }
        futures.add(CompletableFuture.supplyAsync(() -> {
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            return this.queryLrclibSearchPlainCandidate(targetArtist + " " + targetTitle, queryDurationSec, targetTitle, targetArtist, fetchId);
        }, this.executor));
        futures.add(CompletableFuture.supplyAsync(() -> {
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            return this.queryLyricsOvhCandidate(targetArtist, targetTitle, fetchId);
        }, this.executor));
        List<LyricsConsensusEngine.Candidate> candidatePool = Collections.synchronizedList(new ArrayList());
        CountDownLatch latch = new CountDownLatch(1);
        AtomicInteger pending = new AtomicInteger(futures.size());
        for (CompletableFuture<LyricsConsensusEngine.Candidate> completableFuture : futures) {
            completableFuture.thenAccept((LyricsConsensusEngine.Candidate cand) -> {
                if (cand != null) {
                    candidatePool.add(cand);
                    if (cand.isSynced) {
                        for (LyricsConsensusEngine.Candidate other : candidatePool) {
                            if (cand == other || !"GENIUS".equalsIgnoreCase(other.provider) && !other.isSynced || !(LyricsConsensusEngine.computePhraseOverlap(cand.phrases, other.phrases) >= 0.6)) continue;
                            latch.countDown();
                            break;
                        }
                    }
                }
                if (pending.decrementAndGet() == 0) {
                    latch.countDown();
                }
            });
        }
        try {
            latch.await(2600L, TimeUnit.MILLISECONDS);
        }
        catch (Exception exception) {

        }
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        LyricsConsensusEngine.Candidate winner = LyricsConsensusEngine.selectBest(candidatePool, durationSec);
        if (winner == null) {
            return new FetchResult(Collections.emptyList(), false);
        }
        FetchResult result;
        if (winner.isSynced && !winner.lines.isEmpty()) {
            result = new FetchResult(winner.lines, winner.possibleMismatch);
        } else if (!winner.rawText.isBlank()) {
            long targetDurMs = durationSec > 0L ? durationSec * 1000L : 180000L;
            result = this.parsePlainLyrics(winner.rawText, targetDurMs, fetchId);
        } else {
            result = new FetchResult(Collections.emptyList(), false);
        }
        if (result != null && result.lines() != null && !result.lines().isEmpty()) {
            List<LyricLine> lines = result.lines();
            if (isSpeedUp || isSlowed) {
                lines = this.applySpeedAdjustment(lines, durationSec, isSpeedUp, isSlowed);
            }
            return new FetchResult(lines, result.possibleMismatch());
        }
        return new FetchResult(Collections.emptyList(), false);
    }

    private List<LyricLine> applySpeedAdjustment(List<LyricLine> lines, long actualDurationSec, boolean isSpeedUp, boolean isSlowed) {
        double factor;
        long targetDurationMs;
        if (lines == null || lines.isEmpty()) {
            return lines;
        }
        long origLastMs = lines.get((int)(lines.size() - 1)).endMs;
        long l = targetDurationMs = actualDurationSec > 0L ? actualDurationSec * 1000L : 0L;
        if (targetDurationMs > 30000L && origLastMs > 30000L) {
            double ratio = (double)targetDurationMs / (double)origLastMs;
            if (Math.abs(ratio - 1.0) < 0.05) {
                return lines;
            }
            factor = isSpeedUp && ratio >= 0.45 && ratio <= 0.95 ? ratio : (isSlowed && ratio >= 1.05 && ratio <= 2.0 ? ratio : (isSpeedUp ? 0.75 : 1.3));
        } else {
            factor = isSpeedUp ? 0.75 : 1.3;
        }
        ArrayList<LyricLine> scaled = new ArrayList<LyricLine>(lines.size());
        for (LyricLine l2 : lines) {
            scaled.add(l2.scaled(factor));
        }
        System.out.println("[MusicSubtitles] Auto-adjusted lyrics timestamps for " + (isSpeedUp ? "SPEED_UP" : "SLOWED") + " track (factor: " + String.format(Locale.US, "%.3f", factor) + ")");
        return scaled;
    }

    private List<LyricLine> checkLocalLyrics(String title, String artist) {
        try {
            if (!Files.exists(LOCAL_LYRICS_DIR, new LinkOption[0])) {
                return null;
            }
            File[] files = LOCAL_LYRICS_DIR.toFile().listFiles((dir, name) -> name.toLowerCase().endsWith(".lrc"));
            if (files == null || files.length == 0) {
                return null;
            }
            String normTitle = LyricsManager.normalizeForComparison(title);
            String normArtist = LyricsManager.normalizeForComparison(artist);
            for (File f : files) {
                String content;
                List<LyricLine> parsed;
                String fname = f.getName().toLowerCase().replace(".lrc", "");
                String normFile = LyricsManager.normalizeForComparison(fname);
                if (!normFile.contains(normTitle) && (normArtist.isEmpty() || !normFile.contains(normArtist) || !normFile.contains(normTitle)) || (parsed = this.parseLrc(content = Files.readString(f.toPath(), StandardCharsets.UTF_8))).isEmpty()) continue;
                return parsed;
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private static String httpGet(String urlStr, Map<String, String> headers, int timeoutMs) {
        HttpURLConnection conn = null;
        try {
            URL url = URI.create(urlStr).toURL();
            conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setUseCaches(false);
            conn.setInstanceFollowRedirects(true);
            if (headers != null) {
                for (Map.Entry<String, String> entry : headers.entrySet()) {
                    conn.setRequestProperty(entry.getKey(), entry.getValue());
                }
            }
            if (conn.getResponseCode() != 200) {
                return null;
            }
            try (InputStream is = conn.getInputStream()) {
                return new String(is.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Exception ignored) {}
            }
        }
    }

    private FetchResult queryYandexMusic(String trackName, String artistName, long durationSec, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            String searchResp;
            String query = (artistName + " " + trackName).trim();
            String searchUrl = "https://api.music.yandex.net/search?text=" + URLEncoder.encode(query, StandardCharsets.UTF_8) + "&type=track&page=0";
            HashMap<String, String> headers = new HashMap<String, String>();
            headers.put("User-Agent", "YandexMusic/2024.01.1 (Android 14; Pixel 8 Pro)");
            headers.put("Accept", "application/json");
            if (HudConfig.INSTANCE.yandexMusicToken != null && !HudConfig.INSTANCE.yandexMusicToken.isBlank()) {
                headers.put("Authorization", "OAuth " + HudConfig.INSTANCE.yandexMusicToken.trim());
            }
            if ((searchResp = LyricsManager.httpGet(searchUrl, headers, 2500)) == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject searchJson = JsonParser.parseString((String)searchResp).getAsJsonObject();
            if (!searchJson.has("result")) {
                return null;
            }
            JsonObject resultObj = searchJson.getAsJsonObject("result");
            if (!resultObj.has("tracks")) {
                return null;
            }
            JsonObject tracksObj = resultObj.getAsJsonObject("tracks");
            if (!tracksObj.has("results")) {
                return null;
            }
            JsonArray results = tracksObj.getAsJsonArray("results");
            if (results.isEmpty()) {
                return null;
            }
            JsonObject trackObj = results.get(0).getAsJsonObject();
            String foundTitle = trackObj.has("title") && !trackObj.get("title").isJsonNull() ? trackObj.get("title").getAsString() : "";
            double sim = LyricsManager.computeStringSimilarity(trackName, foundTitle);
            if (sim < 0.4) {
                return null;
            }
            boolean possibleMismatch = sim < 0.75;
            String trackId = trackObj.get("id").getAsString();
            long trackDurationMs = trackObj.has("durationMs") ? trackObj.get("durationMs").getAsLong() : 0L;
            String supplementUrl = "https://api.music.yandex.net/tracks/" + trackId + "/supplement";
            String supplementResp = LyricsManager.httpGet(supplementUrl, headers, 2500);
            if (supplementResp == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject supplementJson = JsonParser.parseString((String)supplementResp).getAsJsonObject();
            if (!supplementJson.has("result")) {
                return null;
            }
            JsonObject suppResult = supplementJson.getAsJsonObject("result");
            if (suppResult.has("lyrics") && !suppResult.get("lyrics").isJsonNull()) {
                List<LyricLine> lines;
                JsonObject lyrObj = suppResult.getAsJsonObject("lyrics");
                if (lyrObj.has("syncedLyrics") && !lyrObj.get("syncedLyrics").isJsonNull() && !(lines = this.parseLrc(lyrObj.get("syncedLyrics").getAsString())).isEmpty()) {
                    return new FetchResult(lines, possibleMismatch);
                }
                if (lyrObj.has("fullLyrics") && !lyrObj.get("fullLyrics").isJsonNull()) {
                    long targetDur = durationSec > 0L ? durationSec * 1000L : (trackDurationMs > 0L ? trackDurationMs : 180000L);
                    return this.parsePlainLyrics(lyrObj.get("fullLyrics").getAsString(), targetDur, fetchId);
                }
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private FetchResult queryNeteaseLyrics(String query, String targetTitle, String targetArtist, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            List<LyricLine> lines;
            JsonObject lrc;
            String searchUrl = "https://music.163.com/api/search/get/web?s=" + URLEncoder.encode(query, StandardCharsets.UTF_8) + "&type=1&offset=0&total=true&limit=3";
            Map<String, String> headers = Map.of("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Referer", "https://music.163.com/");
            String searchResp = LyricsManager.httpGet(searchUrl, headers, 2500);
            if (searchResp == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject searchJson = JsonParser.parseString((String)searchResp).getAsJsonObject();
            if (!searchJson.has("result") || searchJson.get("result").isJsonNull()) {
                return null;
            }
            JsonObject resObj = searchJson.getAsJsonObject("result");
            if (!resObj.has("songs") || resObj.get("songs").isJsonNull()) {
                return null;
            }
            JsonArray songs = resObj.getAsJsonArray("songs");
            if (songs.isEmpty()) {
                return null;
            }
            JsonObject bestSong = null;
            double bestSim = 0.0;
            for (JsonElement se : songs) {
                if (!se.isJsonObject()) continue;
                JsonObject sObj = se.getAsJsonObject();
                String string = sObj.has("name") && !sObj.get("name").isJsonNull() ? sObj.get("name").getAsString() : "";
                String name = string;
                double sim = LyricsManager.computeStringSimilarity(targetTitle, name);
                if (!(sim > bestSim)) continue;
                bestSim = sim;
                bestSong = sObj;
            }
            if (bestSong == null || bestSim < 0.45) {
                return null;
            }
            boolean possibleMismatch = bestSim < 0.75;
            long songId = bestSong.get("id").getAsLong();
            String lyricUrl = "https://music.163.com/api/song/lyric?os=pc&id=" + songId + "&lv=-1&kv=-1&tv=-1";
            String lyricResp = LyricsManager.httpGet(lyricUrl, headers, 2500);
            if (lyricResp == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject lyricJson = JsonParser.parseString((String)lyricResp).getAsJsonObject();
            if (lyricJson.has("lrc") && !lyricJson.get("lrc").isJsonNull() && (lrc = lyricJson.getAsJsonObject("lrc")).has("lyric") && !lrc.get("lyric").isJsonNull() && !(lines = this.parseLrc(lrc.get("lyric").getAsString())).isEmpty()) {
                return new FetchResult(lines, possibleMismatch);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private LyricsConsensusEngine.Candidate wrapSyncedResult(String provider, FetchResult res) {
        if (res == null || res.lines() == null || res.lines().isEmpty()) {
            return null;
        }
        LyricsConsensusEngine.Candidate c = new LyricsConsensusEngine.Candidate(provider, res.lines(), null, true);
        c.possibleMismatch = res.possibleMismatch();
        return c;
    }

    private LyricsConsensusEngine.Candidate queryGeniusLyrics(String title, String artist, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            String lyrics = GeniusLyricsProvider.fetchLyrics(title, artist, 3000L);
            if (lyrics != null && !lyrics.isBlank()) {
                return new LyricsConsensusEngine.Candidate("GENIUS", null, lyrics, false);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private LyricsConsensusEngine.Candidate queryLrclibGetCandidate(String trackName, String artistName, long durationSec, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            String plain;
            List<LyricLine> lines;
            StringBuilder urlBuilder = new StringBuilder("https://lrclib.net/api/get?");
            urlBuilder.append("track_name=").append(URLEncoder.encode(trackName, StandardCharsets.UTF_8));
            urlBuilder.append("&artist_name=").append(URLEncoder.encode(artistName, StandardCharsets.UTF_8));
            if (durationSec > 0L) {
                urlBuilder.append("&duration=").append(durationSec);
            }
            Map<String, String> headers = Map.of("User-Agent", "MusicSubtitles/2.3.0 (Minecraft Fabric)");
            String resp = LyricsManager.httpGet(urlBuilder.toString(), headers, 2500);
            if (resp == null || fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject obj = JsonParser.parseString((String)resp).getAsJsonObject();
            if (obj.has("syncedLyrics") && !obj.get("syncedLyrics").isJsonNull() && !(lines = this.parseLrc(obj.get("syncedLyrics").getAsString())).isEmpty()) {
                return new LyricsConsensusEngine.Candidate("LRCLIB_SYNCED", lines, null, true);
            }
            if (obj.has("plainLyrics") && !obj.get("plainLyrics").isJsonNull() && !(plain = obj.get("plainLyrics").getAsString()).isBlank()) {
                return new LyricsConsensusEngine.Candidate("LRCLIB_PLAIN", null, plain, false);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private LyricsConsensusEngine.Candidate queryLrclibSearchPlainCandidate(String query, long durationSec, String targetTitle, String targetArtist, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            String plain;
            String url = "https://lrclib.net/api/search?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8);
            Map<String, String> headers = Map.of("User-Agent", "MusicSubtitles/2.3.0 (Minecraft Fabric)");
            String resp = LyricsManager.httpGet(url, headers, 2500);
            if (resp == null || fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonArray arr = JsonParser.parseString((String)resp).getAsJsonArray();
            if (arr.isEmpty()) {
                return null;
            }
            JsonObject bestPlainObj = null;
            int bestPlainScore = 40;
            for (JsonElement elem : arr) {
                int score;
                JsonObject obj;
                if (!elem.isJsonObject() || !(obj = elem.getAsJsonObject()).has("plainLyrics") || obj.get("plainLyrics").isJsonNull() || (score = this.calculateMatchScore(obj, durationSec, targetTitle, targetArtist)) <= bestPlainScore) continue;
                bestPlainScore = score;
                bestPlainObj = obj;
            }
            if (bestPlainObj != null && !(plain = bestPlainObj.get("plainLyrics").getAsString()).isBlank()) {
                return new LyricsConsensusEngine.Candidate("LRCLIB_PLAIN", null, plain, false);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private LyricsConsensusEngine.Candidate queryLyricsOvhCandidate(String artist, String title, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            String lyrics;
            Map<String, String> headers;
            if (artist.isEmpty() || title.isEmpty()) {
                return null;
            }
            String url = "https://api.lyrics.ovh/v1/" + URLEncoder.encode(artist, StandardCharsets.UTF_8) + "/" + URLEncoder.encode(title, StandardCharsets.UTF_8);
            String resp = LyricsManager.httpGet(url, headers = Map.of("User-Agent", "MusicSubtitles/2.3.0"), 2500);
            if (resp == null || fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject json = JsonParser.parseString((String)resp).getAsJsonObject();
            if (json.has("lyrics") && !json.get("lyrics").isJsonNull() && !(lyrics = json.get("lyrics").getAsString()).isBlank()) {
                return new LyricsConsensusEngine.Candidate("OVH", null, lyrics, false);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private FetchResult queryLyricsOvh(String artist, String title, long durationSec, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            Map<String, String> headers;
            if (artist.isEmpty() || title.isEmpty()) {
                return null;
            }
            String url = "https://api.lyrics.ovh/v1/" + URLEncoder.encode(artist, StandardCharsets.UTF_8) + "/" + URLEncoder.encode(title, StandardCharsets.UTF_8);
            String resp = LyricsManager.httpGet(url, headers = Map.of("User-Agent", "MusicSubtitles/2.2.5"), 2500);
            if (resp == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject json = JsonParser.parseString((String)resp).getAsJsonObject();
            if (json.has("lyrics") && !json.get("lyrics").isJsonNull()) {
                long dur = durationSec > 0L ? durationSec * 1000L : 180000L;
                return this.parsePlainLyrics(json.get("lyrics").getAsString(), dur, fetchId);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private FetchResult queryLrclibGet(String trackName, String artistName, long durationSec, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            List<LyricLine> lines;
            StringBuilder urlBuilder = new StringBuilder("https://lrclib.net/api/get?");
            urlBuilder.append("track_name=").append(URLEncoder.encode(trackName, StandardCharsets.UTF_8));
            urlBuilder.append("&artist_name=").append(URLEncoder.encode(artistName, StandardCharsets.UTF_8));
            if (durationSec > 0L) {
                urlBuilder.append("&duration=").append(durationSec);
            }
            Map<String, String> headers = Map.of("User-Agent", "MusicSubtitles/2.2.5 (Minecraft Fabric)");
            String resp = LyricsManager.httpGet(urlBuilder.toString(), headers, 2500);
            if (resp == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject obj = JsonParser.parseString((String)resp).getAsJsonObject();
            if (obj.has("syncedLyrics") && !obj.get("syncedLyrics").isJsonNull() && !(lines = this.parseLrc(obj.get("syncedLyrics").getAsString())).isEmpty()) {
                return new FetchResult(lines, false);
            }
            if (obj.has("plainLyrics") && !obj.get("plainLyrics").isJsonNull()) {
                long targetDurationMs = durationSec > 0L ? durationSec * 1000L : 180000L;
                return this.parsePlainLyrics(obj.get("plainLyrics").getAsString(), targetDurationMs, fetchId);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private FetchResult queryLrclibSearchSynced(String query, long durationSec, String targetTitle, String targetArtist, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            List<LyricLine> lines;
            String url = "https://lrclib.net/api/search?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8);
            Map<String, String> headers = Map.of("User-Agent", "MusicSubtitles/2.2.5 (Minecraft Fabric)");
            String resp = LyricsManager.httpGet(url, headers, 2500);
            if (resp == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonArray arr = JsonParser.parseString((String)resp).getAsJsonArray();
            if (arr.isEmpty()) {
                return null;
            }
            JsonObject bestSyncedObj = null;
            int bestSyncedScore = 40;
            for (JsonElement elem : arr) {
                int score;
                JsonObject obj;
                if (!elem.isJsonObject() || !(obj = elem.getAsJsonObject()).has("syncedLyrics") || obj.get("syncedLyrics").isJsonNull() || (score = this.calculateMatchScore(obj, durationSec, targetTitle, targetArtist)) <= bestSyncedScore) continue;
                bestSyncedScore = score;
                bestSyncedObj = obj;
            }
            if (bestSyncedObj != null && !(lines = this.parseLrc(bestSyncedObj.get("syncedLyrics").getAsString())).isEmpty()) {
                boolean possibleMismatch = bestSyncedScore < 250;
                return new FetchResult(lines, possibleMismatch);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private FetchResult queryLrclibSearchPlain(String query, long durationSec, String targetTitle, String targetArtist, long fetchId) {
        if (fetchId != this.currentFetchId.get()) {
            return null;
        }
        try {
            String url = "https://lrclib.net/api/search?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8);
            Map<String, String> headers = Map.of("User-Agent", "MusicSubtitles/2.2.5 (Minecraft Fabric)");
            String resp = LyricsManager.httpGet(url, headers, 2500);
            if (resp == null) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonArray arr = JsonParser.parseString((String)resp).getAsJsonArray();
            if (arr.isEmpty()) {
                return null;
            }
            JsonObject bestPlainObj = null;
            int bestPlainScore = 40;
            for (JsonElement elem : arr) {
                int score;
                JsonObject obj;
                if (!elem.isJsonObject() || !(obj = elem.getAsJsonObject()).has("plainLyrics") || obj.get("plainLyrics").isJsonNull() || (score = this.calculateMatchScore(obj, durationSec, targetTitle, targetArtist)) <= bestPlainScore) continue;
                bestPlainScore = score;
                bestPlainObj = obj;
            }
            if (bestPlainObj != null) {
                long targetDurationMs = durationSec > 0L ? durationSec * 1000L : 180000L;
                return this.parsePlainLyrics(bestPlainObj.get("plainLyrics").getAsString(), targetDurationMs, fetchId);
            }
        }
        catch (Exception exception) {

        }
        return null;
    }

    private int calculateMatchScore(JsonObject obj, long durationSec, String targetTitle, String targetArtist) {
        long itemDurSec;
        String itemTrack = obj.has("trackName") && !obj.get("trackName").isJsonNull() ? obj.get("trackName").getAsString() : "";
        String itemArtist = obj.has("artistName") && !obj.get("artistName").isJsonNull() ? obj.get("artistName").getAsString() : "";
        double titleSim = LyricsManager.computeStringSimilarity(targetTitle, itemTrack);
        double artistSim = LyricsManager.computeStringSimilarity(targetArtist, itemArtist);
        if (titleSim < 0.35) {
            return 0;
        }
        int score = 0;
        int n = titleSim >= 0.9 ? (score += 300) : (score = titleSim >= 0.5 ? (score = score + (int)(240.0 * titleSim)) : (score = score + (int)(150.0 * titleSim)));
        if (artistSim >= 0.85) {
            score += 150;
        } else if (artistSim >= 0.3) {
            score += (int)(120.0 * artistSim);
        } else if (!targetArtist.isEmpty()) {
            score -= 100;
        }
        long l = itemDurSec = obj.has("duration") && !obj.get("duration").isJsonNull() ? (long)obj.get("duration").getAsDouble() : 0L;
        if (durationSec > 0L && itemDurSec > 0L) {
            long diff = Math.abs(itemDurSec - durationSec);
            if (diff <= 2L) {
                score += 500;
            } else if (diff <= 5L) {
                score += 250;
            } else if (diff <= 10L) {
                score += 100;
            } else if (diff > 30L) {
                score -= 300;
            }
        }
        return score;
    }

    private static double computeStringSimilarity(String s1, String s2) {
        if (s1 == null || s2 == null) {
            return 0.0;
        }
        String a = LyricsManager.normalizeForComparison(s1);
        String b = LyricsManager.normalizeForComparison(s2);
        if (a.isEmpty() || b.isEmpty()) {
            return 0.0;
        }
        if (a.equals(b)) {
            return 1.0;
        }
        if (a.contains(b) || b.contains(a)) {
            return (double)Math.min(a.length(), b.length()) / (double)Math.max(a.length(), b.length());
        }
        HashSet<String> wordsA = new HashSet<String>(Arrays.asList(a.split("\\s+")));
        HashSet<String> wordsB = new HashSet<String>(Arrays.asList(b.split("\\s+")));
        wordsA.removeIf(w -> w.length() < 2);
        wordsB.removeIf(w -> w.length() < 2);
        if (wordsA.isEmpty() || wordsB.isEmpty()) {
            return 0.0;
        }
        HashSet<String> intersection = new HashSet<String>(wordsA);
        intersection.retainAll(wordsB);
        HashSet<String> union = new HashSet<String>(wordsA);
        union.addAll(wordsB);
        return (double)intersection.size() / (double)union.size();
    }

    private boolean isLyricsMismatched(List<LyricLine> lines, TrackState state) {
        if (lines == null || lines.isEmpty() || state == null) {
            return false;
        }
        long durationMs = state.durationMs();
        if (durationMs > 30000L) {
            boolean isSpeedUp;
            long lastLineEnd = lines.get((int)(lines.size() - 1)).endMs;
            long firstLineStart = lines.get((int)0).startMs;
            if ((double)firstLineStart > (double)durationMs * 0.5) {
                return true;
            }
            if (lastLineEnd > durationMs + 8000L) {
                return true;
            }
            boolean bl = isSpeedUp = SPEED_UP_PATTERN.matcher(state.title()).find() || SPEED_UP_PATTERN.matcher(state.artist()).find();
            if (!isSpeedUp && (double)lastLineEnd < (double)durationMs * 0.45 && lines.size() > 2) {
                return true;
            }
            if (!isSpeedUp && Math.abs(lastLineEnd - durationMs) > 25000L && lines.size() > 3) {
                return true;
            }
        }
        String trackInfo = (state.artist() + " " + state.title()).toLowerCase();
        int cyrillicInTrack = LyricsManager.countCyrillicChars(trackInfo);
        int cjkInTrack = LyricsManager.countCjkChars(trackInfo);
        StringBuilder sampleLyrics = new StringBuilder();
        int sampleLimit = Math.min(10, lines.size());
        for (int i = 0; i < sampleLimit; ++i) {
            sampleLyrics.append(lines.get((int)i).text).append(" ");
        }
        String lyricsStr = sampleLyrics.toString();
        int cjkInLyrics = LyricsManager.countCjkChars(lyricsStr);
        int cyrillicInLyrics = LyricsManager.countCyrillicChars(lyricsStr);
        if (cyrillicInTrack >= 3 && cyrillicInLyrics == 0 && cjkInLyrics >= 5) {
            return true;
        }
        return cjkInTrack == 0 && cjkInLyrics > 15 && cyrillicInTrack >= 2;
    }

    private static int countCyrillicChars(String s) {
        if (s == null) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < s.length(); ++i) {
            char c = s.charAt(i);
            if ((c < '\u0400' || c > '\u04ff') && (c < '\u0500' || c > '\u052f')) continue;
            ++count;
        }
        return count;
    }

    private static int countCjkChars(String s) {
        if (s == null) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < s.length(); ++i) {
            char c = s.charAt(i);
            if ((c < '\u4e00' || c > '\u9fff') && (c < '\u3400' || c > '\u4dbf')) continue;
            ++count;
        }
        return count;
    }

    private static String normalizeForComparison(String s) {
        if (s == null) {
            return "";
        }
        return s.toLowerCase().replaceAll("[^a-z\u0430-\u044f0-9\\s]", "").replaceAll("\\s+", " ").trim();
    }

    private List<LyricLine> parseLrc(String lrcContent) {
        if (lrcContent == null || lrcContent.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList<RawLine> rawList = new ArrayList<RawLine>();
        String[] lines = lrcContent.split("\\r?\\n");
        long offsetMs = 0L;
        for (String raw : lines) {
            Matcher offMatcher = OFFSET_PATTERN.matcher(raw);
            if (!offMatcher.find()) continue;
            try {
                offsetMs = Long.parseLong(offMatcher.group(1).trim());
            }
            catch (Exception exception) {

            }
        }
        for (String raw : lines) {
            Matcher matcher = LRC_LINE_PATTERN.matcher(raw);
            if (!matcher.find()) continue;
            long min = Long.parseLong(matcher.group(1));
            double sec = Double.parseDouble(matcher.group(2));
            long timeMs = Math.max(0L, min * 60000L + (long)(sec * 1000.0) + offsetMs);
            String text = matcher.group(3).trim();
            rawList.add(new RawLine(timeMs, text));
        }
        if (rawList.isEmpty()) {
            return Collections.emptyList();
        }
        rawList.sort(Comparator.comparingLong(r -> r.timeMs));
        ArrayList<LyricLine> result = new ArrayList<LyricLine>();
        for (int i = 0; i < rawList.size(); ++i) {
            String plainText;
            RawLine current = (RawLine)rawList.get(i);
            if (current.text.isEmpty() || (plainText = this.stripEnhancedLrcTags(current.text)).isEmpty() || plainText.matches("(?i)^\\[?(?:instrumental|\u0441\u043e\u043b\u043e|guitar\\s*solo|\u0438\u043d\u0441\u0442\u0440\u0443\u043c\u0435\u043d\u0442\u0430\u043b|\u043c\u0443\u0437\u044b\u043a\u0430|intro|outro|solo)\\]?$")) continue;
            long startMs = current.timeMs;
            long nextTimeMs = i < rawList.size() - 1 ? ((RawLine)rawList.get((int)(i + 1))).timeMs : startMs + 5000L;
            long gap = Math.max(600L, nextTimeMs - startMs);
            String[] tokens = plainText.split("\\s+");
            int wordCount = 0;
            for (String t : tokens) {
                if (!t.isEmpty()) ++wordCount;
            }
            if (wordCount == 0) wordCount = 1;

            long estimatedVocalDur;
            if (wordCount >= 7) {
                estimatedVocalDur = Math.min(gap, Math.max(900L, (long)wordCount * 220L + 250L));
            } else if (wordCount >= 3) {
                estimatedVocalDur = Math.min(gap, Math.max(800L, (long)wordCount * 320L + 300L));
            } else {
                estimatedVocalDur = Math.min(gap, Math.max(600L, (long)wordCount * 450L + 300L));
            }
            long vocalEndMs = startMs + estimatedVocalDur;

            long endMs = Math.min(nextTimeMs, vocalEndMs + Math.min(1500L, Math.max(400L, (gap - estimatedVocalDur) / 2)));
            if (endMs <= startMs) {
                endMs = startMs + estimatedVocalDur;
            }
            List<LyricLine.Word> words = this.parseEnhancedLrcWords(current.text, startMs, vocalEndMs);
            result.add(new LyricLine(startMs, endMs, vocalEndMs, plainText, words));
        }
        return result;
    }

    private List<LyricLine> splitLongLyricLine(long startMs, long endMs, String plainText, List<LyricLine.Word> words) {
        ArrayList<LyricLine> result = new ArrayList<LyricLine>();
        if (plainText == null || plainText.trim().isEmpty()) {
            return result;
        }
        plainText = plainText.trim();
        String[] allWords = plainText.split("\\s+");
        long duration = endMs - startMs;
        if (allWords.length <= 5) {
            result.add(new LyricLine(startMs, endMs, plainText, words));
            return result;
        }
        int MAX_WORDS = 5;
        int numChunks = (int)Math.ceil((double)allWords.length / 5.0);
        int wordsPerChunk = (int)Math.ceil((double)allWords.length / (double)numChunks);
        if (wordsPerChunk > 5) {
            wordsPerChunk = 5;
        }
        int wordIdx = 0;
        long currentStart = startMs;
        int totalChars = plainText.length();
        for (int c = 0; c < numChunks && wordIdx < allWords.length; ++c) {
            int remainingChunks = numChunks - c;
            int remainingWords = allWords.length - wordIdx;
            int count = remainingChunks == 1 ? Math.min(5, remainingWords) : Math.min(wordsPerChunk, remainingWords);
            CharSequence[] chunkWords = Arrays.copyOfRange(allWords, wordIdx, wordIdx + count);
            String chunkText = String.join((CharSequence)" ", chunkWords);
            long chunkDur = remainingChunks == 1 || (wordIdx += count) >= allWords.length ? endMs - currentStart : (long)((double)duration * ((double)chunkText.length() / (double)totalChars));
            long l = chunkDur;
            if (chunkDur < 700L) {
                chunkDur = Math.min(duration, 700L);
            }
            long chunkEnd = remainingChunks == 1 || wordIdx >= allWords.length ? endMs : Math.min(endMs, currentStart + chunkDur);
            result.add(new LyricLine(currentStart, chunkEnd, chunkText, null));
            currentStart = chunkEnd;
        }
        return result;
    }

    private List<LyricLine.Word> parseEnhancedLrcWords(String rawText, long lineStartMs, long lineEndMs) {
        ArrayList<LyricLine.Word> words = new ArrayList<LyricLine.Word>();
        Matcher matcher = ENHANCED_WORD_PATTERN.matcher(rawText);
        int textOffset = 0;
        long lastWordEnd = lineStartMs;
        while (matcher.find()) {
            long min = Long.parseLong(matcher.group(1));
            double sec = Double.parseDouble(matcher.group(2));
            long wordTime = min * 60000L + (long)(sec * 1000.0);
            String wordText = matcher.group(3).trim();
            if (wordText.isEmpty()) continue;
            int charStart = textOffset;
            int charEnd = charStart + wordText.length();
            words.add(new LyricLine.Word(wordTime, wordTime + 500L, wordText, charStart, charEnd));
            textOffset = charEnd + 1;
            lastWordEnd = wordTime + 500L;
        }
        for (int i = 0; i < words.size(); ++i) {
            LyricLine.Word w = words.get(i);
            long end = i < words.size() - 1 ? words.get(i + 1).startMs() : Math.min(lineEndMs, w.startMs() + 800L);
            words.set(i, new LyricLine.Word(w.startMs(), end, w.text(), w.charStart(), w.charEnd()));
        }
        return words;
    }

    private String stripEnhancedLrcTags(String rawText) {
        return rawText.replaceAll("<\\d+:\\d+(?:\\.\\d+)?>", "").replaceAll("\\[\\d+:\\d+(?:\\.\\d+)?\\]", "").trim();
    }

    private FetchResult parsePlainLyrics(String plainLyrics, long totalDurationMs, long fetchId) {
        if (plainLyrics == null || plainLyrics.isEmpty()) {
            return new FetchResult(Collections.emptyList(), false);
        }
        String[] rawLines = plainLyrics.split("\\r?\\n");
        ArrayList<String> validLines = new ArrayList<String>();
        for (String l : rawLines) {
            String trimmed = l.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("[") || trimmed.endsWith("]")) continue;
            validLines.add(trimmed);
        }
        if (validLines.isEmpty()) {
            return new FetchResult(Collections.emptyList(), false);
        }
        FetchResult aiResult = this.tryAiAlignment(validLines, totalDurationMs, fetchId);
        if (aiResult != null && aiResult.lines() != null && !aiResult.lines().isEmpty()) {
            return aiResult;
        }
        if (fetchId != this.currentFetchId.get()) {
            return new FetchResult(Collections.emptyList(), false);
        }
        List<LyricLine> cascadeLines = StudioCascadeAligner.align(plainLyrics, null, totalDurationMs);
        if (cascadeLines != null && !cascadeLines.isEmpty()) {
            return new FetchResult(cascadeLines, false);
        }
        ArrayList<LyricLine> result = new ArrayList<LyricLine>();
        long timePerLine = Math.max(3000L, totalDurationMs / (long)validLines.size());
        for (int i = 0; i < validLines.size(); ++i) {
            long start = (long)i * timePerLine;
            long end = start + timePerLine;
            result.addAll(this.splitLongLyricLine(start, end, validLines.get(i), null));
        }
        return new FetchResult(result, true);
    }

    private FetchResult tryAiAlignment(List<String> plainLines, long totalDurationMs, long fetchId) {
        try {
            double confidence;
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            int port = this.resolveHelperPort();
            if (port <= 0) {
                return null;
            }
            String helperBase = "http://127.0.0.1:" + port;
            int captureDurationMs = 4000;
            LyricsManager.httpPost(helperBase + "/capture/start", "{\"durationMs\":" + captureDurationMs + "}", 2000);
            for (int elapsed = 0; elapsed < captureDurationMs + 400; elapsed += 150) {
                if (fetchId != this.currentFetchId.get()) {
                    LyricsManager.httpPost(helperBase + "/capture/stop", "", 1000);
                    return null;
                }
                Thread.sleep(150L);
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            String wavBase64 = null;
            byte[] wavBytes = LyricsManager.httpGetBytes(helperBase + "/capture/result", 3000);
            if (wavBytes != null && wavBytes.length > 44) {
                List<LyricLine> localCascade = StudioCascadeAligner.align(String.join((CharSequence)"\n", plainLines), wavBytes, totalDurationMs);
                if (localCascade != null && !localCascade.isEmpty()) {
                    return new FetchResult(localCascade, false);
                }
                wavBase64 = Base64.getEncoder().encodeToString(wavBytes);
            }
            StringBuilder bodyBuilder = new StringBuilder();
            bodyBuilder.append("{\"lines\":[");
            for (int i = 0; i < plainLines.size(); ++i) {
                if (i > 0) {
                    bodyBuilder.append(",");
                }
                bodyBuilder.append("\"").append(plainLines.get(i).replace("\\", "\\\\").replace("\"", "\\\"")).append("\"");
            }
            bodyBuilder.append("],\"durationMs\":").append(totalDurationMs);
            if (wavBase64 != null) {
                bodyBuilder.append(",\"wavBase64\":\"").append(wavBase64).append("\"");
            }
            bodyBuilder.append("}");
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            String alignResponse = LyricsManager.httpPost(helperBase + "/ai-align", bodyBuilder.toString(), 5000);
            if (alignResponse == null || alignResponse.isEmpty()) {
                return null;
            }
            if (fetchId != this.currentFetchId.get()) {
                return null;
            }
            JsonObject json = JsonParser.parseString((String)alignResponse).getAsJsonObject();
            if (!json.has("success") || !json.get("success").getAsBoolean()) {
                return null;
            }
            if (!json.has("lines") || json.get("lines").isJsonNull()) {
                return null;
            }
            boolean possibleMismatch = false;
            if (json.has("possibleMismatch") && json.get("possibleMismatch").getAsBoolean()) {
                possibleMismatch = true;
            }
            double d = confidence = json.has("confidence") ? json.get("confidence").getAsDouble() : 1.0;
            if (confidence < 0.35) {
                possibleMismatch = true;
            }
            JsonArray linesArr = json.getAsJsonArray("lines");
            ArrayList<LyricLine> result = new ArrayList<LyricLine>();
            for (JsonElement lineElem : linesArr) {
                String text;
                if (!lineElem.isJsonObject()) continue;
                JsonObject lineObj = lineElem.getAsJsonObject();
                long startMs = lineObj.has("startMs") ? lineObj.get("startMs").getAsLong() : 0L;
                long endMs = lineObj.has("endMs") ? lineObj.get("endMs").getAsLong() : startMs + 4000L;
                String string = text = lineObj.has("text") ? lineObj.get("text").getAsString() : "";
                if (text.isEmpty()) continue;
                ArrayList<LyricLine.Word> words = null;
                if (lineObj.has("words") && lineObj.get("words").isJsonArray()) {
                    JsonArray wordsArr = lineObj.getAsJsonArray("words");
                    words = new ArrayList<LyricLine.Word>();
                    for (JsonElement wElem : wordsArr) {
                        int charEnd;
                        if (!wElem.isJsonObject()) continue;
                        JsonObject wObj = wElem.getAsJsonObject();
                        long wStart = wObj.has("startMs") ? wObj.get("startMs").getAsLong() : startMs;
                        long wEnd = wObj.has("endMs") ? wObj.get("endMs").getAsLong() : wStart + 500L;
                        String wText = wObj.has("text") ? wObj.get("text").getAsString() : "";
                        int charStart = wObj.has("charStart") ? wObj.get("charStart").getAsInt() : 0;
                        int n = charEnd = wObj.has("charEnd") ? wObj.get("charEnd").getAsInt() : wText.length();
                        if (wText.isEmpty()) continue;
                        words.add(new LyricLine.Word(wStart, wEnd, wText, charStart, charEnd));
                    }
                    if (words.isEmpty()) {
                        words = null;
                    }
                }
                long vocalEnd = (words != null && !words.isEmpty()) ? words.get(words.size() - 1).endMs() : endMs;
                result.add(new LyricLine(startMs, endMs, vocalEnd, text, words));
            }
            if (!result.isEmpty()) {
                System.out.println("[MusicSubtitles] AI alignment successful: " + result.size() + " lines aligned (confidence: " + confidence + ")");
            }
            return result.isEmpty() ? null : new FetchResult(result, possibleMismatch);
        }
        catch (Exception e) {
            System.out.println("[MusicSubtitles] AI alignment failed, using fallback: " + e.getMessage());
            return null;
        }
    }

    private static String httpPost(String urlStr, String body, int timeoutMs) {
        HttpURLConnection conn = null;
        try {
            URL url = URI.create(urlStr).toURL();
            conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bodyBytes.length);
            conn.getOutputStream().write(bodyBytes);
            conn.getOutputStream().flush();
            int code = conn.getResponseCode();
            if (code != 200) {
                return null;
            }
            try (InputStream is = conn.getInputStream()) {
                return new String(is.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Exception ignored) {}
            }
        }
    }

    private static byte[] httpGetBytes(String urlStr, int timeoutMs) {
        HttpURLConnection conn = null;
        try {
            URL url = URI.create(urlStr).toURL();
            conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            int code = conn.getResponseCode();
            if (code != 200) {
                return null;
            }
            try (InputStream is = conn.getInputStream()) {
                return is.readAllBytes();
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Exception ignored) {}
            }
        }
    }

    private String cleanForSearch(String input) {
        if (input == null) {
            return "";
        }
        String s = input.trim();
        s = BROWSER_SUFFIX_PATTERN.matcher(s).replaceAll("");
        s = PIPE_NOISE_PATTERN.matcher(s).replaceAll("");
        for (int i = 0; i < 3; ++i) {
            s = BRACKET_TAGS_PATTERN.matcher(s).replaceAll("");
        }
        s = TRAILING_NOISE_PATTERN.matcher(s).replaceAll("");
        s = s.replaceAll("[\u25ba\u25c4\"'\u00ab\u00bb\u201c\u201d\u201e]", "");
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    private String extractPrimaryArtist(String artist) {
        if (artist == null) {
            return "";
        }
        String s = artist.replaceAll("(?i)\\s*(?:feat\\.?|ft\\.?|featuring)\\s+.*$", "").trim();
        String[] parts = s.split("(?i)\\s*(?:,|&|x|\\+)\\s*");
        if (parts.length > 0 && !parts[0].trim().isEmpty()) {
            return parts[0].trim();
        }
        return s;
    }

    public record FetchResult(List<LyricLine> lines, boolean possibleMismatch) {
    }

    private record RawLine(long timeMs, String text) {
    }
}

