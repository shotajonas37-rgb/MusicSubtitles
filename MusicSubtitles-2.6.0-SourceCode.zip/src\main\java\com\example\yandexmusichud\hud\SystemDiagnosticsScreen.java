package com.example.yandexmusichud.hud;

import com.example.yandexmusichud.YandexMusicHudMod;
import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.hud.MusicHudRenderer;
import com.example.yandexmusichud.network.NowPlayingClient;
import com.example.yandexmusichud.network.TrackState;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_437;
import net.minecraft.class_6880;

public class SystemDiagnosticsScreen
extends class_437 {
    private final class_437 parent;
    private final class_437 nextScreen;
    private final Random random = new Random();
    private final List<DiagnosticItem> items = new ArrayList<DiagnosticItem>();
    private final List<DiagParticle> particles = new ArrayList<DiagParticle>();
    private final List<DiagShockwave> shockwaves = new ArrayList<DiagShockwave>();
    private boolean isScanning = false;
    private long lastScanTime = 0L;
    private int hoveredCardIndex = -1;

    public SystemDiagnosticsScreen(class_437 parent, class_437 nextScreen) {
        super((class_2561)class_2561.method_43470((String)"Music Subtitles - \u0414\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0430 \u0441\u0438\u0441\u0442\u0435\u043c\u044b"));
        this.parent = parent;
        this.nextScreen = nextScreen;
    }

    protected void method_25426() {
        super.method_25426();
        this.playSound(class_3417.field_14703, 1.8f, 0.7f);
        this.playSound(class_3417.field_26980, 1.2f, 0.8f);
        for (int i = 0; i < 35; ++i) {
            this.spawnAmbientParticle(true);
        }
        this.runDiagnostics();
    }

    private void playSound(class_3414 sound, float pitch, float volume) {
        try {
            class_310.method_1551().method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)sound, (float)pitch, (float)volume));
        }
        catch (Exception exception) {

        }
    }

    private void playSound(class_6880<class_3414> sound, float pitch, float volume) {
        if (sound != null && sound.comp_349() != null) {
            this.playSound((class_3414)sound.comp_349(), pitch, volume);
        }
    }

    private void spawnAmbientParticle(boolean randomY) {
        String[] symbols = new String[]{"\u2726", "\u25c6", "\u25cf", "0", "1", "\u26a1", "\u2727"};
        String sym = symbols[this.random.nextInt(symbols.length)];
        float x = this.random.nextFloat() * (float)this.field_22789;
        float y = randomY ? this.random.nextFloat() * (float)this.field_22790 : (float)(this.field_22790 + 10);
        float vy = -0.3f - this.random.nextFloat() * 0.5f;
        float vx = (this.random.nextFloat() - 0.5f) * 0.4f;
        int[] colors = new int[]{58879, 65416, 8444159, 0xFFCC00, 12289788};
        int col = colors[this.random.nextInt(colors.length)];
        this.particles.add(new DiagParticle(x, y, vx, vy, col, sym, 90 + this.random.nextInt(70), 8.0f));
    }

    private void spawnBurstParticles(float originX, float originY, int color) {
        this.shockwaves.add(new DiagShockwave(originX, originY, 44.0f, color, 20));
        for (int i = 0; i < 35; ++i) {
            float angle = (float)((double)this.random.nextFloat() * Math.PI * 2.0);
            float speed = 1.2f + this.random.nextFloat() * 3.8f;
            float vx = (float)Math.cos(angle) * speed;
            float vy = (float)Math.sin(angle) * speed - 0.6f;
            this.particles.add(new DiagParticle(originX, originY, vx, vy, color, null, 25 + this.random.nextInt(20), 2.0f));
        }
    }

    public synchronized void runDiagnostics() {
        if (this.isScanning) {
            return;
        }
        this.isScanning = true;
        this.lastScanTime = System.currentTimeMillis();
        this.items.clear();
        DiagnosticItem osItem = new DiagnosticItem("\u041e\u043f\u0435\u0440\u0430\u0446\u0438\u043e\u043d\u043d\u0430\u044f \u0441\u0438\u0441\u0442\u0435\u043c\u0430 \u0438 \u043f\u043b\u0430\u0442\u0444\u043e\u0440\u043c\u0430");
        DiagnosticItem helperItem = new DiagnosticItem("\u0421\u043b\u0443\u0436\u0431\u0430 \u043c\u0435\u0434\u0438\u0430-\u0438\u043d\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u0438 (MusicHelper)");
        DiagnosticItem mediaItem = new DiagnosticItem("Медиа-сессия (GSMTC / MPRIS)");
        DiagnosticItem lyricsItem = new DiagnosticItem("Серверы синхронизации субтитров");
        DiagnosticItem twitchItem = new DiagnosticItem("Twitch Live и EventSub Gateway");
        this.items.add(osItem);
        this.items.add(helperItem);
        this.items.add(mediaItem);
        this.items.add(lyricsItem);
        this.items.add(twitchItem);
        CompletableFuture.runAsync(() -> {
            try {
                TrackState state;
                boolean isWin11;
                String osName = System.getProperty("os.name", "Unknown");
                String osVersion = System.getProperty("os.version", "");
                String osArch = System.getProperty("os.arch", "");
                boolean isWindows = osName.toLowerCase().contains("win");
                boolean isLinux = osName.toLowerCase().contains("linux");
                boolean isMac = osName.toLowerCase().contains("mac");
                boolean bl = isWin11 = isWindows && (osName.contains("11") || osVersion.startsWith("10.0") && SystemDiagnosticsScreen.parseBuild(osVersion) >= 22000);
                if (isWin11) {
                    osItem.status = Status.OK;
                    osItem.message = "Windows 11 (" + osArch + ") - полная поддержка системных медиа-сессий GSMTC.";
                    osItem.solution = "";
                } else if (isWindows) {
                    osItem.status = Status.OK;
                    osItem.message = osName + " (" + osArch + ") - поддерживается Windows Media Session.";
                    osItem.solution = "";
                } else if (isLinux) {
                    osItem.status = Status.OK;
                    osItem.message = osName + " (" + osArch + ") - полная поддержка медиа через MPRIS D-Bus.";
                    osItem.solution = "";
                } else if (isMac) {
                    osItem.status = Status.OK;
                    osItem.message = osName + " (" + osArch + ") - поддержка внешнего хелпера macOS MediaRemote.";
                    osItem.solution = "";
                } else {
                    osItem.status = Status.WARNING;
                    osItem.message = osName + " (" + osArch + ") - стандартные медиа-сессии не настроены.";
                    osItem.solution = "Рекомендуется Windows или Linux с playerctl.";
                }
                Path configDir = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud");
                Path exePath = configDir.resolve("YandexMusicHelper.exe");
                boolean exeExists = Files.exists(exePath, new LinkOption[0]);
                boolean isHelperResponding = false;
                try {
                    int port = HudConfig.INSTANCE.helperPort;
                    if (port <= 0) {
                        String tempEnv;
                        Path portFile = Path.of(System.getProperty("java.io.tmpdir"), new String[0]).resolve("yandexmusichud_port.txt");
                        if (!Files.exists(portFile, new LinkOption[0]) && (tempEnv = System.getenv("TEMP")) != null) {
                            portFile = Path.of(tempEnv, new String[0]).resolve("yandexmusichud_port.txt");
                        }
                        if (Files.exists(portFile, new LinkOption[0])) {
                            port = Integer.parseInt(Files.readString(portFile).trim());
                        }
                    }
                    if (port > 0) {
                        URL pingUrl = URI.create("http://127.0.0.1:" + port + "/now-playing").toURL();
                        HttpURLConnection conn = (HttpURLConnection)pingUrl.openConnection();
                        conn.setRequestMethod("GET");
                        conn.setConnectTimeout(800);
                        conn.setReadTimeout(800);
                        int respCode = conn.getResponseCode();
                        isHelperResponding = respCode == 200;
                        conn.disconnect();
                    }
                }
                catch (Exception ignored) {
                    isHelperResponding = false;
                }
                if (isHelperResponding) {
                    helperItem.status = Status.OK;
                    helperItem.message = "\u0424\u043e\u043d\u043e\u0432\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 \u0430\u043a\u0442\u0438\u0432\u043d\u0430 \u0438 \u043f\u0435\u0440\u0435\u0434\u0430\u0451\u0442 \u043c\u0435\u0434\u0438\u0430-\u0441\u043e\u0431\u044b\u0442\u0438\u044f \u0432 \u043c\u043e\u0434.";
                } else if (isWindows && exeExists) {
                    helperItem.status = Status.ERROR;
                    helperItem.message = "Файл службы найден, но фоновый процесс не отвечает на запросы.";
                    helperItem.solution = "Нажмите «Перезапустить службу». Если не помогает, проверьте исключения Защитника Windows для папки config/yandexmusichud.";
                    helperItem.actionButtonText = "⚡ Запустить службу";
                    helperItem.actionButtonAction = () -> {
                        if (YandexMusicHudMod.INSTANCE != null) {
                            YandexMusicHudMod.INSTANCE.restartHelper();
                        }
                        this.runDiagnostics();
                    };
                } else if (isLinux) {
                    helperItem.status = Status.WARNING;
                    helperItem.message = "Служба MPRIS не отвечает на запросы.";
                    helperItem.solution = "Убедитесь, что установлен playerctl (sudo apt install playerctl / sudo pacman -S playerctl) и запущен плеер.";
                    helperItem.actionButtonText = "⚡ Перезапустить службу";
                    helperItem.actionButtonAction = () -> {
                        if (YandexMusicHudMod.INSTANCE != null) {
                            YandexMusicHudMod.INSTANCE.restartHelper();
                        }
                        this.runDiagnostics();
                    };
                } else if (isMac) {
                    helperItem.status = Status.WARNING;
                    helperItem.message = "Ожидается внешний хелпер macOS MediaRemote.";
                    helperItem.solution = "Запустите MediaRemote хелпер, пишущий порт в yandexmusichud_port.txt.";
                } else {
                    helperItem.status = Status.ERROR;
                    helperItem.message = "Файл службы не найден в папке конфигурации.";
                    helperItem.solution = "Файл будет автоматически извлечён из мода при перезапуске службы.";
                    helperItem.actionButtonText = "⚡ Восстановить и запустить";
                    helperItem.actionButtonAction = () -> {
                        if (YandexMusicHudMod.INSTANCE != null) {
                            YandexMusicHudMod.INSTANCE.restartHelper();
                        }
                        this.runDiagnostics();
                    };
                }
                NowPlayingClient client = NowPlayingClient.INSTANCE;
                TrackState trackState = state = client != null ? client.getState() : TrackState.INACTIVE;
                if (state != null && state.isActive() && !state.title().isEmpty()) {
                    mediaItem.status = Status.OK;
                    mediaItem.message = "\u041f\u043b\u0435\u0435\u0440 \u043e\u0431\u043d\u0430\u0440\u0443\u0436\u0435\u043d [" + state.detectPlatformName() + "]: " + state.artist() + " - " + state.title();
                    mediaItem.solution = "";
                } else if (isHelperResponding) {
                    boolean spotifyRunning = TrackState.isSpotifyRunning();
                    mediaItem.status = Status.OK;
                    mediaItem.message = spotifyRunning ? "Spotify \u0437\u0430\u043f\u0443\u0449\u0435\u043d \u0438 \u0433\u043e\u0442\u043e\u0432 \u043a \u0440\u0430\u0431\u043e\u0442\u0435. \u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u043b\u044e\u0431\u043e\u0439 \u0442\u0440\u0435\u043a." : "\u0421\u043b\u0443\u0436\u0431\u0430 \u0430\u043a\u0442\u0438\u0432\u043d\u0430 \u0438 \u043e\u0436\u0438\u0434\u0430\u0435\u0442 \u0432\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u044f \u0442\u0440\u0435\u043a\u0430 (Spotify, \u043f\u043b\u0435\u0435\u0440 \u0438\u043b\u0438 \u0431\u0440\u0430\u0443\u0437\u0435\u0440).";
                    mediaItem.solution = "";
                    mediaItem.actionButtonText = "\ud83d\udd04 \u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c";
                    mediaItem.actionButtonAction = this::runDiagnostics;
                } else {
                    mediaItem.status = Status.WARNING;
                    mediaItem.message = "\u041c\u0435\u0434\u0438\u0430-\u0441\u0435\u0441\u0441\u0438\u044f \u043d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0430 (\u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044f \u0440\u0430\u0431\u043e\u0442\u0430\u044e\u0449\u0430\u044f \u0441\u043b\u0443\u0436\u0431\u0430 Helper).";
                    mediaItem.solution = "\u0417\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u0435 \u0441\u043b\u0443\u0436\u0431\u0443 Helper \u0432\u044b\u0448\u0435.";
                }
                boolean lrclibOk = SystemDiagnosticsScreen.pingUrl("https://lrclib.net/api/search?q=test", 2500);
                boolean yandexOk = SystemDiagnosticsScreen.pingUrl("https://api.music.yandex.net", 2500);
                if (lrclibOk || yandexOk) {
                    lyricsItem.status = Status.OK;
                    lyricsItem.message = "\u0421\u0432\u044f\u0437\u044c \u0441 \u0431\u0430\u0437\u043e\u0439 \u0441\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0445 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432 (LrcLib) \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0441\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u043e.";
                    lyricsItem.solution = "";
                } else {
                    lyricsItem.status = Status.WARNING;
                    lyricsItem.message = "\u0421\u0435\u0440\u0432\u0435\u0440\u044b \u0442\u0435\u043a\u0441\u0442\u043e\u0432 \u043d\u0435 \u043e\u0442\u0432\u0435\u0447\u0430\u044e\u0442 \u0437\u0430 \u043e\u0442\u0432\u0435\u0434\u0451\u043d\u043d\u043e\u0435 \u0432\u0440\u0435\u043c\u044f.";
                    lyricsItem.solution = "\u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443 \u0438\u043b\u0438 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0431\u0440\u0430\u043d\u0434\u043c\u0430\u0443\u044d\u0440\u0430 Windows.";
                    lyricsItem.actionButtonText = "\ud83d\udd04 \u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u044c";
                    lyricsItem.actionButtonAction = this::runDiagnostics;
                }
                if (!com.example.yandexmusichud.config.HudConfig.INSTANCE.twitchEnabled) {
                    twitchItem.status = Status.WARNING;
                    twitchItem.message = "Twitch \u0438\u043d\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044f \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0430 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445.";
                    twitchItem.solution = "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 Twitch \u0432 \u043c\u0435\u043d\u044e \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a (\u043a\u043d\u043e\u043f\u043a\u0430 \u00a7d\u25C8).";
                } else if (com.example.yandexmusichud.config.HudConfig.INSTANCE.twitchChannel == null || com.example.yandexmusichud.config.HudConfig.INSTANCE.twitchChannel.trim().isEmpty()) {
                    twitchItem.status = Status.WARNING;
                    twitchItem.message = "\u041a\u0430\u043d\u0430\u043b Twitch \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d.";
                    twitchItem.solution = "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0438\u043c\u044f \u043a\u0430\u043d\u0430\u043b\u0430 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 Twitch.";
                } else {
                    com.example.yandexmusichud.twitch.TwitchManager tw = com.example.yandexmusichud.twitch.TwitchManager.getInstance();
                    if (tw.getStatus() == com.example.yandexmusichud.twitch.TwitchManager.Status.CONNECTED) {
                        twitchItem.status = Status.OK;
                        twitchItem.message = "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u043a \u043a\u0430\u043d\u0430\u043b\u0443 [#" + tw.getCurrentJoinedChannel() + "]. \u041f\u0438\u043d\u0433: " + tw.getPingLatencyMs() + "\u043c\u0441. \u0410\u043b\u0435\u0440\u0442\u044b \u0430\u043a\u0442\u0438\u0432\u043d\u044b.";
                        twitchItem.solution = "";
                    } else if (tw.getStatus() == com.example.yandexmusichud.twitch.TwitchManager.Status.CONNECTING) {
                        twitchItem.status = Status.WARNING;
                        twitchItem.message = "\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u0441\u043e\u0435\u0434\u0438\u043d\u0435\u043d\u0438\u044f \u0441 Twitch IRC...";
                        twitchItem.solution = "";
                    } else {
                        twitchItem.status = Status.ERROR;
                        twitchItem.message = "\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f: " + tw.getLastErrorMessage();
                        twitchItem.solution = "\u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043f\u0440\u0430\u0432\u0438\u043b\u044c\u043d\u043e\u0441\u0442\u044c \u0438\u043c\u0435\u043d\u0438 \u043a\u0430\u043d\u0430\u043b\u0430 \u0438 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0441\u0435\u0442\u0438.";
                        twitchItem.actionButtonText = "\u21bb \u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u044c";
                        twitchItem.actionButtonAction = this::runDiagnostics;
                    }
                }
            }
            catch (Exception hasErr) {
            }
            finally {
                this.isScanning = false;
                boolean hasErr = this.items.stream().anyMatch(it -> it.status == Status.ERROR);
                if (!hasErr) {
                    this.playSound(class_3417.field_14709, 1.8f, 0.7f);
                    this.playSound((class_6880<class_3414>)class_3417.field_14725, 1.4f, 0.8f);
                } else {
                    this.playSound((class_6880<class_3414>)class_3417.field_14624, 0.8f, 0.8f);
                }
            }
        });
    }

    private static int parseBuild(String osVersion) {
        try {
            String[] parts = osVersion.split("\\.");
            if (parts.length >= 3) {
                return Integer.parseInt(parts[2]);
            }
        }
        catch (Exception exception) {

        }
        return 0;
    }

    private static boolean pingUrl(String urlStr, int timeoutMs) {
        try {
            URL u = URI.create(urlStr).toURL();
            HttpURLConnection conn = (HttpURLConnection)u.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "MusicSubtitles/2.4.0 (Windows 11 Diagnostic)");
            int code = conn.getResponseCode();
            return code >= 200 && code < 400;
        }
        catch (Exception e) {
            return false;
        }
    }

    private void renderParticles(class_332 context) {
        for (int i = this.particles.size() - 1; i >= 0; --i) {
            DiagParticle p = this.particles.get(i);
            p.update();
            if (p.isDead()) {
                this.particles.remove(i);
                continue;
            }
            int alphaInt = (int)(p.getAlpha() * 255.0f);
            if (alphaInt <= 2) continue;
            int col = alphaInt << 24 | p.color & 0xFFFFFF;
            if (p.symbol != null) {
                context.method_51433(this.field_22793, p.symbol, (int)p.x, (int)p.y, col, false);
                continue;
            }
            context.method_25294((int)p.x, (int)p.y, (int)(p.x + p.size), (int)(p.y + p.size), col);
        }
    }

    private void renderShockwaves(class_332 context) {
        for (int i = this.shockwaves.size() - 1; i >= 0; --i) {
            DiagShockwave s = this.shockwaves.get(i);
            s.update();
            if (s.isDead()) {
                this.shockwaves.remove(i);
                continue;
            }
            int alphaInt = (int)(s.getAlpha() * 200.0f);
            if (alphaInt <= 2) continue;
            int col = alphaInt << 24 | s.color & 0xFFFFFF;
            int r = (int)s.radius;
            int cx = (int)s.cx;
            int cy = (int)s.cy;
            context.method_25294(cx - r, cy - 1, cx + r, cy + 1, col);
            context.method_25294(cx - 1, cy - r, cx + 1, cy + r, col);
            int diag = (int)((float)r * 0.707f);
            context.method_25294(cx - diag, cy - diag, cx - diag + 2, cy - diag + 2, col);
            context.method_25294(cx + diag, cy - diag, cx + diag + 2, cy - diag + 2, col);
            context.method_25294(cx - diag, cy + diag, cx - diag + 2, cy + diag + 2, col);
            context.method_25294(cx + diag, cy + diag, cx + diag + 2, cy + diag + 2, col);
        }
    }

    private void renderHeartbeatWaveform(class_332 context, int centerX, int y) {
        int pointCount = 28;
        int barW = 3;
        int barGap = 2;
        int totalW = pointCount * (barW + barGap) - barGap;
        int startX = centerX - totalW / 2;
        long nowMs = System.currentTimeMillis();
        for (int i = 0; i < pointCount; ++i) {
            float wave = (float)Math.sin((double)nowMs * 0.007 + (double)i * 0.38);
            float pulsePeak = i >= 12 && i <= 16 ? (float)Math.sin((double)nowMs * 0.012 + (double)i) * 1.6f : 0.0f;
            float norm = Math.abs(wave + pulsePeak) * 0.5f;
            int barH = (int)(2.0f + norm * 8.0f);
            int col = i >= 12 && i <= 16 ? -587137144 : -1442781697;
            int bx = startX + i * (barW + barGap);
            context.method_25294(bx, y - barH / 2, bx + barW, y + barH / 2 + 1, col);
        }
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        int summaryCol;
        String statusSummary;
        int cardHeight;
        long nowMs = System.currentTimeMillis();
        class_327 tr = this.field_22793;
        int cx = this.field_22789 / 2;
        context.method_25296(0, 0, this.field_22789, this.field_22790, -100070892, -50068215);
        context.method_25296(0, 0, 160, 110, 352380415, 0);
        context.method_25296(this.field_22789 - 160, 0, this.field_22789, 110, 352386952, 0);
        if (this.random.nextFloat() < 0.28f) {
            this.spawnAmbientParticle(false);
        }
        this.renderParticles(context);
        this.renderShockwaves(context);
        MusicHudRenderer.renderRoundedRect(context, cx - 270, 7, 540, 44, 10, 402712063);
        MusicHudRenderer.renderRoundedRect(context, cx - 270, 7, 540, 44, 10, 855696895);
        String title = "\u2726 \u0426\u0415\u041d\u0422\u0420 \u0414\u0418\u0410\u0413\u041d\u041e\u0421\u0422\u0418\u041a\u0418 \u0418 \u0421\u041e\u0412\u041c\u0415\u0421\u0422\u0418\u041c\u041e\u0421\u0422\u0418 WINDOWS 11 / 10 \u2726";
        int titleW = tr.method_1727(title);
        context.method_51433(tr, title, cx - titleW / 2, 12, -16718337, false);
        String subtitle = "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0430\u043d\u0430\u043b\u0438\u0437 \u043e\u043a\u0440\u0443\u0436\u0435\u043d\u0438\u044f, \u043c\u0435\u0434\u0438\u0430-\u0441\u0435\u0441\u0441\u0438\u0439 \u0438 \u0441\u0435\u0440\u0432\u0438\u0441\u0430 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432";
        int subW = tr.method_1727(subtitle);
        context.method_51433(tr, subtitle, cx - subW / 2, 24, -5592406, false);
        this.renderHeartbeatWaveform(context, cx, 39);
        int cardWidth = Math.min(520, this.field_22789 - 40);
        int startX = cx - cardWidth / 2;
        int startY = 56;
        int cardGap = 8;
        int curY = startY;
        int totalCardsH = 0;
        for (DiagnosticItem item : this.items) {
            cardHeight = item.solution.isEmpty() && item.actionButtonText.isEmpty() ? 44 : 64;
            totalCardsH += cardHeight + cardGap;
        }
        if (totalCardsH > 0) {
            totalCardsH -= cardGap;
        }
        if (totalCardsH > 0) {
            float scanProgress = (float)((double)(nowMs % 3200L) / 3200.0);
            int scanY = (int)((float)startY + scanProgress * (float)totalCardsH);
            context.method_25296(startX, Math.max(startY, scanY - 14), startX + cardWidth, scanY, 58879, 805365247);
            context.method_25294(startX, scanY - 1, startX + cardWidth, scanY + 1, -872349697);
            context.method_25296(startX, scanY + 1, startX + cardWidth, Math.min(startY + totalCardsH, scanY + 15), 805365247, 58879);
        }
        this.hoveredCardIndex = -1;
        for (int i = 0; i < this.items.size(); ++i) {
            Object badge;
            boolean isHovered;
            DiagnosticItem item = this.items.get(i);
            cardHeight = item.solution.isEmpty() && item.actionButtonText.isEmpty() ? 44 : 64;
            boolean bl = isHovered = mouseX >= startX && mouseX <= startX + cardWidth && mouseY >= curY && mouseY <= curY + cardHeight;
            if (isHovered) {
                this.hoveredCardIndex = i;
            }
            int bg = switch (item.status.ordinal()) {
                default -> throw new MatchException(null, null);
                case 1 -> {
                    if (isHovered) {
                        yield -1441584354;
                    }
                    yield -2012143080;
                }
                case 2 -> {
                    if (isHovered) {
                        yield -1439159020;
                    }
                    yield -2010504689;
                }
                case 3 -> {
                    if (isHovered) {
                        yield -1438509541;
                    }
                    yield -2009919212;
                }
                case 0 -> isHovered ? -1440997328 : -2011883484;
            };
            int border = switch (item.status.ordinal()) {
                default -> throw new MatchException(null, null);
                case 1 -> -16718218;
                case 2 -> -10929;
                case 3 -> -44462;
                case 0 -> -12285185;
            };
            MusicHudRenderer.renderRoundedRect(context, startX, curY, cardWidth, cardHeight, 6, bg);
            int borderCol = isHovered ? 0xCC000000 | border & 0xFFFFFF : 0x55000000 | border & 0xFFFFFF;
            MusicHudRenderer.renderRoundedRect(context, startX, curY, cardWidth, cardHeight, 6, borderCol);
            if (isHovered) {
                MusicHudRenderer.renderRoundedRect(context, startX + 1, curY + 1, cardWidth - 2, cardHeight - 2, 5, 302048767);
            }
            if (item.status == Status.CHECKING) {
                String[] SPINNER = new String[]{"\u280b", "\u2819", "\u2839", "\u2838", "\u283c", "\u2834", "\u2826", "\u2827", "\u2807", "\u280f"};
                String spin = SPINNER[(int)(nowMs / 80L % (long)SPINNER.length)];
                badge = spin + " \u041f\u0420\u041e\u0412\u0415\u0420\u041a\u0410...";
            } else {
                badge = item.status == Status.OK ? "\u2713 \u0413\u041e\u0422\u041e\u0412\u041e" : (item.status == Status.WARNING ? "\u26a0 \u0412\u041d\u0418\u041c\u0410\u041d\u0418\u0415" : "\u2715 \u041e\u0428\u0418\u0411\u041a\u0410");
            }
            int badgeBg = switch (item.status.ordinal()) {
                default -> throw new MatchException(null, null);
                case 1 -> 855697014;
                case 2 -> 872404303;
                case 3 -> 872370770;
                case 0 -> 860130047;
            };
            MusicHudRenderer.renderRoundedRect(context, startX + 10, curY + 6, 82, 14, 4, badgeBg);
            MusicHudRenderer.renderRoundedRect(context, startX + 10, curY + 6, 82, 14, 4, 0x66000000 | border & 0xFFFFFF);
            context.method_51433(tr, (String)badge, startX + 14, curY + 9, border, false);
            context.method_51433(tr, item.title, startX + 98, curY + 9, -1, false);
            Object msg = item.message;
            if (tr.method_1727((String)msg) > cardWidth - 24) {
                msg = tr.method_27523((String)msg, cardWidth - 28) + "...";
            }
            context.method_51433(tr, (String)msg, startX + 12, curY + 23, -3355444, false);
            if (!item.solution.isEmpty()) {
                String prefix = item.status == Status.OK ? "\u2139 " : "\ud83d\udca1 \u0420\u0435\u0448\u0435\u043d\u0438\u0435: ";
                String sol = prefix + item.solution;
                int maxSolW = cardWidth - 24 - (item.actionButtonText.isEmpty() ? 0 : 130);
                if (tr.method_1727(sol) > maxSolW) {
                    sol = tr.method_27523(sol, maxSolW - 8) + "...";
                }
                context.method_51433(tr, sol, startX + 12, curY + 39, item.status == Status.OK ? -8271996 : -8062, false);
            }
            if (!item.actionButtonText.isEmpty() && item.actionButtonAction != null) {
                int btnW = 124;
                int btnH = 18;
                int btnX = startX + cardWidth - btnW - 8;
                int btnY = curY + cardHeight - btnH - 6;
                boolean btnHovered = mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH;
                int btnBg = btnHovered ? -16731905 : -16745729;
                MusicHudRenderer.renderRoundedRect(context, btnX, btnY, btnW, btnH, 4, btnBg);
                MusicHudRenderer.renderRoundedRect(context, btnX, btnY, btnW, btnH, 4, btnHovered ? -1 : 0x66FFFFFF);
                int btnTextW = tr.method_1727(item.actionButtonText);
                context.method_51433(tr, item.actionButtonText, btnX + (btnW - btnTextW) / 2, btnY + 5, -1, false);
            }
            curY += cardHeight + cardGap;
        }
        int bottomY = this.field_22790 - 38;
        int btnW = 130;
        int btnH = 22;
        int b1X = cx - 210;
        boolean b1Hover = mouseX >= b1X && mouseX <= b1X + btnW && mouseY >= bottomY && mouseY <= bottomY + btnH;
        MusicHudRenderer.renderRoundedRect(context, b1X, bottomY, btnW, btnH, 5, b1Hover ? -14013124 : -14934486);
        MusicHudRenderer.renderRoundedRect(context, b1X, bottomY, btnW, btnH, 5, b1Hover ? -16718337 : 0x44FFFFFF);
        context.method_51433(tr, "\ud83d\udd04 \u041f\u0435\u0440\u0435\u043f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c", b1X + 16, bottomY + 7, b1Hover ? -16718337 : -2039584, false);
        int b2X = cx - 70;
        boolean b2Hover = mouseX >= b2X && mouseX <= b2X + btnW && mouseY >= bottomY && mouseY <= bottomY + btnH;
        MusicHudRenderer.renderRoundedRect(context, b2X, bottomY, btnW, btnH, 5, b2Hover ? -14013124 : -14934486);
        MusicHudRenderer.renderRoundedRect(context, b2X, bottomY, btnW, btnH, 5, b2Hover ? -8333057 : 0x44FFFFFF);
        context.method_51433(tr, "\ud83d\udcc1 \u041f\u0430\u043f\u043a\u0430 Helper", b2X + 22, bottomY + 7, b2Hover ? -8333057 : -2039584, false);
        int b3W = 150;
        int b3X = cx + 70;
        boolean b3Hover = mouseX >= b3X && mouseX <= b3X + b3W && mouseY >= bottomY && mouseY <= bottomY + btnH;
        int primaryCol = b3Hover ? -16718218 : -16725933;
        MusicHudRenderer.renderRoundedRect(context, b3X, bottomY, b3W, btnH, 5, primaryCol);
        MusicHudRenderer.renderRoundedRect(context, b3X, bottomY, b3W, btnH, 5, b3Hover ? -1 : -2013200504);
        int arrowShift = b3Hover ? (int)(Math.sin((double)nowMs * 0.01) * 2.0) : 0;
        context.method_51433(tr, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043a\u043b\u0430\u0432\u0438\u0448 " + (arrowShift > 0 ? " \u2794" : "\u2794"), b3X + 14 + arrowShift, bottomY + 7, -16777216, false);
        boolean hasError = this.items.stream().anyMatch(it -> it.status == Status.ERROR);
        boolean hasWarn = this.items.stream().anyMatch(it -> it.status == Status.WARNING);
        if (this.isScanning) {
            statusSummary = "\u0418\u0434\u0451\u0442 \u0441\u043a\u0430\u043d\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435 \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u044b\u0445 \u0441\u0435\u0440\u0432\u0438\u0441\u043e\u0432 Windows...";
            summaryCol = -8333057;
        } else if (hasError) {
            statusSummary = "\u041e\u0431\u043d\u0430\u0440\u0443\u0436\u0435\u043d\u044b \u043e\u0448\u0438\u0431\u043a\u0438. \u0412\u044b\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u0440\u0435\u043a\u043e\u043c\u0435\u043d\u0434\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044f \u0432\u044b\u0448\u0435.";
            summaryCol = -44462;
        } else if (hasWarn) {
            statusSummary = "\u0421\u0438\u0441\u0442\u0435\u043c\u0430 \u0433\u043e\u0442\u043e\u0432\u0430 \u043a \u0440\u0430\u0431\u043e\u0442\u0435. \u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u043f\u043b\u0435\u0435\u0440 \u0434\u043b\u044f \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f \u0442\u0440\u0435\u043a\u043e\u0432.";
            summaryCol = -10929;
        } else {
            statusSummary = "\u2713 \u0412\u0441\u0435 \u0441\u043b\u0443\u0436\u0431\u044b \u0440\u0430\u0431\u043e\u0442\u0430\u044e\u0442 \u0438\u0434\u0435\u0430\u043b\u044c\u043d\u043e. \u0413\u043e\u0442\u043e\u0432\u043e \u043a \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044e!";
            summaryCol = -9834322;
        }
        context.method_51433(tr, statusSummary, cx - tr.method_1727(statusSummary) / 2, this.field_22790 - 52, summaryCol, false);
    }

    public boolean method_25402(class_11909 click, boolean bl) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int cx = this.field_22789 / 2;
        int cardWidth = Math.min(520, this.field_22789 - 40);
        int startX = cx - cardWidth / 2;
        int startY = 56;
        int cardGap = 8;
        int curY = startY;
        for (DiagnosticItem item : this.items) {
            int cardHeight;
            int n = cardHeight = item.solution.isEmpty() && item.actionButtonText.isEmpty() ? 44 : 64;
            if (!item.actionButtonText.isEmpty() && item.actionButtonAction != null) {
                int btnW = 124;
                int btnH = 18;
                int btnX = startX + cardWidth - btnW - 8;
                int btnY = curY + cardHeight - btnH - 6;
                if (mouseX >= (double)btnX && mouseX <= (double)(btnX + btnW) && mouseY >= (double)btnY && mouseY <= (double)(btnY + btnH)) {
                    this.playSound((class_6880<class_3414>)class_3417.field_15015, 1.0f, 0.8f);
                    this.spawnBurstParticles((float)btnX + (float)btnW / 2.0f, (float)btnY + (float)btnH / 2.0f, 45311);
                    item.actionButtonAction.run();
                    return true;
                }
            }
            curY += cardHeight + cardGap;
        }
        int bottomY = this.field_22790 - 38;
        int btnW = 130;
        int btnH = 22;
        int b1X = cx - 210;
        if (mouseX >= (double)b1X && mouseX <= (double)(b1X + btnW) && mouseY >= (double)bottomY && mouseY <= (double)(bottomY + btnH)) {
            this.playSound((class_6880<class_3414>)class_3417.field_15015, 1.0f, 0.8f);
            this.spawnBurstParticles((float)b1X + (float)btnW / 2.0f, (float)bottomY + (float)btnH / 2.0f, 58879);
            this.runDiagnostics();
            return true;
        }
        int b2X = cx - 70;
        if (mouseX >= (double)b2X && mouseX <= (double)(b2X + btnW) && mouseY >= (double)bottomY && mouseY <= (double)(bottomY + btnH)) {
            this.playSound((class_6880<class_3414>)class_3417.field_15015, 1.0f, 0.8f);
            this.spawnBurstParticles((float)b2X + (float)btnW / 2.0f, (float)bottomY + (float)btnH / 2.0f, 8444159);
            Path dir = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud");
            class_156.method_668().method_60932(dir);
            return true;
        }
        int b3W = 150;
        int b3X = cx + 70;
        if (mouseX >= (double)b3X && mouseX <= (double)(b3X + b3W) && mouseY >= (double)bottomY && mouseY <= (double)(bottomY + btnH)) {
            this.playSound(class_3417.field_14627, 1.2f, 0.8f);
            this.spawnBurstParticles((float)b3X + (float)b3W / 2.0f, (float)bottomY + (float)btnH / 2.0f, 58998);
            this.proceedNext();
            return true;
        }
        return super.method_25402(click, bl);
    }

    private void proceedNext() {
        if (this.field_22787 != null) {
            if (this.nextScreen != null) {
                this.field_22787.method_1507(this.nextScreen);
            } else {
                this.field_22787.method_1507(this.parent);
            }
        }
    }

    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == 256 || input.comp_4795() == 257 || input.comp_4795() == 32) {
            this.proceedNext();
            return true;
        }
        return super.method_25404(input);
    }

    public boolean method_25421() {
        return true;
    }

    private static class DiagParticle {
        float x;
        float y;
        float vx;
        float vy;
        int color;
        String symbol;
        int maxAge;
        int age = 0;
        float size;

        DiagParticle(float x, float y, float vx, float vy, int color, String symbol, int maxAge, float size) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.color = color;
            this.symbol = symbol;
            this.maxAge = maxAge;
            this.size = size;
        }

        void update() {
            this.x += this.vx;
            this.y += this.vy;
            ++this.age;
        }

        boolean isDead() {
            return this.age >= this.maxAge;
        }

        float getAlpha() {
            float progress = (float)this.age / (float)this.maxAge;
            if (progress < 0.2f) {
                return progress / 0.2f;
            }
            return Math.max(0.0f, 1.0f - (progress - 0.2f) / 0.8f);
        }
    }

    private static class DiagShockwave {
        float cx;
        float cy;
        float radius = 2.0f;
        float maxRadius;
        int color;
        int age = 0;
        int maxAge;

        DiagShockwave(float cx, float cy, float maxRadius, int color, int maxAge) {
            this.cx = cx;
            this.cy = cy;
            this.maxRadius = maxRadius;
            this.color = color;
            this.maxAge = maxAge;
        }

        void update() {
            ++this.age;
            float t = (float)this.age / (float)this.maxAge;
            this.radius = 2.0f + (this.maxRadius - 2.0f) * (float)Math.sin((double)t * Math.PI / 2.0);
        }

        boolean isDead() {
            return this.age >= this.maxAge;
        }

        float getAlpha() {
            return Math.max(0.0f, 1.0f - (float)this.age / (float)this.maxAge);
        }
    }

    public static class DiagnosticItem {
        public final String title;
        public Status status = Status.CHECKING;
        public String message = "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430...";
        public String solution = "";
        public String actionButtonText = "";
        public Runnable actionButtonAction = null;

        public DiagnosticItem(String title) {
            this.title = title;
        }
    }

    public static enum Status {
        CHECKING,
        OK,
        WARNING,
        ERROR;

    }
}

