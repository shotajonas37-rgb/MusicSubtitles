package com.example.yandexmusichud.helper;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.time.Duration;
import java.util.Base64;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.fabricmc.loader.api.FabricLoader;

public class HelperProcessManager {
    private static final String HELPER_EXE_NAME = "YandexMusicHelper.exe";
    private static final String PORT_FILE_NAME = "yandexmusichud_port.txt";
    private static final String PID_FILE_NAME = "yandexmusichud_pid.txt";
    private Process helperProcess;
    private int port = -1;
    private boolean started = false;

    private HttpServer linuxServer;
    private ScheduledExecutorService linuxPoller;
    private volatile String cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
    private volatile String lastCoverUrl = null;
    private volatile String cachedCoverBase64 = null;
    private volatile String lastCoverHash = null;

    public int getPort() {
        return this.port;
    }

    public boolean isStarted() {
        return this.started;
    }

    public int start() {
        if (this.isHelperAlreadyRunning()) {
            this.port = this.readPortFromTempFile();
            if (this.port > 0) {
                this.started = true;
                return this.port;
            }
        }
        int existingPort = this.readPortFromTempFile();
        if (existingPort > 0) {
            this.port = existingPort;
            this.started = true;
            return this.port;
        }
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("linux")) {
            int linuxPort = this.startLinuxMprisBridge();
            if (linuxPort > 0) {
                this.port = linuxPort;
                this.started = true;
                return this.port;
            }
            return -1;
        }
        if (!os.contains("win")) {
            return -1;
        }
        Path helperDir = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud");
        Path helperExePath = helperDir.resolve(HELPER_EXE_NAME);
        try {
            this.extractHelperIfNeeded(helperExePath);
        }
        catch (IOException e) {
            return -1;
        }
        try {
            ProcessBuilder pb = new ProcessBuilder(helperExePath.toString());
            pb.directory(helperDir.toFile());
            pb.redirectErrorStream(true);
            Path logFile = helperDir.resolve("helper.log");
            pb.redirectOutput(ProcessBuilder.Redirect.to(logFile.toFile()));
            this.helperProcess = pb.start();
            this.port = this.waitForPortFile(10000L);
            if (this.port > 0) {
                this.started = true;
            } else {
                this.stop();
            }
        }
        catch (IOException e) {
            return -1;
        }
        return this.port;
    }

    private int startLinuxMprisBridge() {
        try {
            int targetPort = 38472;
            try {
                this.linuxServer = HttpServer.create(new InetSocketAddress("127.0.0.1", targetPort), 0);
            } catch (Exception ex) {
                this.linuxServer = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
                targetPort = this.linuxServer.getAddress().getPort();
            }

            this.linuxServer.createContext("/now-playing", exchange -> {
                byte[] resp = this.cachedNowPlayingJson.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, resp.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp);
                }
            });

            this.linuxServer.createContext("/cover", exchange -> {
                String b64 = this.cachedCoverBase64;
                String json = b64 != null && !b64.isEmpty() ? "{\"coverBase64\":\"" + b64 + "\"}" : "{}";
                byte[] resp = json.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, resp.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp);
                }
            });

            this.linuxServer.createContext("/control/play-pause", exchange -> {
                runLinuxControl("play-pause");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.linuxServer.createContext("/control/next", exchange -> {
                runLinuxControl("next");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.linuxServer.createContext("/control/previous", exchange -> {
                runLinuxControl("previous");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.linuxServer.createContext("/shutdown", exchange -> {
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
                this.stop();
            });

            this.linuxServer.setExecutor(Executors.newCachedThreadPool(r -> {
                Thread t = new Thread(r, "MusicSubtitles-LinuxMprisServer");
                t.setDaemon(true);
                return t;
            }));
            this.linuxServer.start();

            try {
                Path portFile = this.getTempDir().resolve(PORT_FILE_NAME);
                Files.writeString(portFile, String.valueOf(targetPort), StandardCharsets.UTF_8);
                Path pidFile = this.getTempDir().resolve(PID_FILE_NAME);
                Files.writeString(pidFile, String.valueOf(ProcessHandle.current().pid()), StandardCharsets.UTF_8);
            } catch (Exception ignored) {}

            this.linuxPoller = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "MusicSubtitles-LinuxMprisPoller");
                t.setDaemon(true);
                return t;
            });
            this.linuxPoller.scheduleWithFixedDelay(this::pollLinuxMpris, 0, 250, TimeUnit.MILLISECONDS);

            return targetPort;
        } catch (Exception e) {
            return -1;
        }
    }

    private void pollLinuxMpris() {
        try {
            ProcessBuilder pb = new ProcessBuilder("playerctl", "metadata", "--format", "{{status}}:::{{artist}}:::{{title}}:::{{album}}:::{{position}}:::{{mpris:length}}:::{{mpris:artUrl}}");
            pb.redirectErrorStream(true);
            Process p = pb.start();
            String output;
            try (InputStream is = p.getInputStream()) {
                output = new String(is.readAllBytes(), StandardCharsets.UTF_8).trim();
            }
            boolean finished = p.waitFor(300, TimeUnit.MILLISECONDS);
            if (!finished) {
                p.destroyForcibly();
                return;
            }
            if (p.exitValue() != 0 || output.isEmpty() || output.startsWith("No player")) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }
            String[] parts = output.split(":::", -1);
            if (parts.length < 3) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }
            String statusRaw = parts[0].trim().toLowerCase();
            String status = statusRaw.equals("playing") ? "playing" : (statusRaw.equals("paused") ? "paused" : "stopped");
            String artist = parts.length > 1 ? parts[1].trim() : "";
            String title = parts.length > 2 ? parts[2].trim() : "";
            String album = parts.length > 3 ? parts[3].trim() : "";
            long posMs = 0L;
            if (parts.length > 4) {
                try {
                    posMs = Math.max(0L, Long.parseLong(parts[4].trim()) / 1000L);
                } catch (Exception ignored) {}
            }
            long durMs = 0L;
            if (parts.length > 5) {
                try {
                    durMs = Math.max(0L, Long.parseLong(parts[5].trim()) / 1000L);
                } catch (Exception ignored) {}
            }
            String artUrl = parts.length > 6 ? parts[6].trim() : "";

            if (title.isEmpty() && artist.isEmpty()) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }

            String coverHash = null;
            if (!artUrl.isEmpty()) {
                coverHash = Integer.toHexString(artUrl.hashCode());
                if (!artUrl.equals(this.lastCoverUrl)) {
                    this.lastCoverUrl = artUrl;
                    this.lastCoverHash = coverHash;
                    this.fetchLinuxCoverAsync(artUrl);
                }
            }

            StringBuilder sb = new StringBuilder();
            sb.append("{");
            sb.append("\"isActive\":true,");
            sb.append("\"title\":\"").append(escapeJson(title)).append("\",");
            sb.append("\"artist\":\"").append(escapeJson(artist)).append("\",");
            sb.append("\"album\":\"").append(escapeJson(album)).append("\",");
            sb.append("\"status\":\"").append(status).append("\",");
            sb.append("\"positionMs\":").append(posMs).append(",");
            sb.append("\"durationMs\":").append(durMs).append(",");
            if (coverHash != null) {
                sb.append("\"coverHash\":\"").append(coverHash).append("\",");
            }
            sb.append("\"platform\":\"player\",");
            sb.append("\"platformName\":\"Linux Media\"");
            sb.append("}");

            this.cachedNowPlayingJson = sb.toString();
        } catch (Exception e) {
            this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
        }
    }

    private void fetchLinuxCoverAsync(String artUrl) {
        CompletableFuture.runAsync(() -> {
            try {
                byte[] bytes = null;
                if (artUrl.startsWith("file://")) {
                    Path p = Path.of(URI.create(artUrl));
                    if (Files.exists(p)) {
                        bytes = Files.readAllBytes(p);
                    }
                } else if (artUrl.startsWith("http://") || artUrl.startsWith("https://")) {
                    HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
                    HttpRequest req = HttpRequest.newBuilder().uri(URI.create(artUrl)).timeout(Duration.ofSeconds(4)).GET().build();
                    HttpResponse<byte[]> res = client.send(req, HttpResponse.BodyHandlers.ofByteArray());
                    if (res.statusCode() == 200) {
                        bytes = res.body();
                    }
                }
                if (bytes != null && bytes.length > 0) {
                    this.cachedCoverBase64 = Base64.getEncoder().encodeToString(bytes);
                }
            } catch (Exception ignored) {}
        });
    }

    private static void runLinuxControl(String action) {
        try {
            new ProcessBuilder("playerctl", action).start();
        } catch (Exception ignored) {}
    }

    private static String escapeJson(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); ++i) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < ' ') {
                        String hex = Integer.toHexString(c);
                        sb.append("\\u");
                        sb.append("0".repeat(Math.max(0, 4 - hex.length())));
                        sb.append(hex);
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }

    public void stop() {
        this.started = false;
        if (this.linuxPoller != null) {
            this.linuxPoller.shutdownNow();
            this.linuxPoller = null;
        }
        if (this.linuxServer != null) {
            try {
                this.linuxServer.stop(0);
            } catch (Exception ignored) {}
            this.linuxServer = null;
        }
        try {
            Files.deleteIfExists(this.getTempDir().resolve(PORT_FILE_NAME));
            Files.deleteIfExists(this.getTempDir().resolve(PID_FILE_NAME));
        } catch (Exception ignored) {}

        if (this.helperProcess != null && this.helperProcess.isAlive()) {
            try {
                HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2L)).build();
                HttpRequest request = HttpRequest.newBuilder().uri(URI.create("http://127.0.0.1:" + this.port + "/shutdown")).POST(HttpRequest.BodyPublishers.noBody()).timeout(Duration.ofSeconds(2L)).build();
                client.send(request, HttpResponse.BodyHandlers.discarding());
                Thread.sleep(1000L);
            }
            catch (Exception ignored) {}
            if (this.helperProcess.isAlive()) {
                this.helperProcess.destroyForcibly();
            }
        }
        this.helperProcess = null;
    }

    private boolean isHelperAlreadyRunning() {
        Path pidFile = this.getTempDir().resolve(PID_FILE_NAME);
        if (!Files.exists(pidFile, new LinkOption[0])) {
            return false;
        }
        try {
            long pid = Long.parseLong(Files.readString(pidFile).trim());
            return ProcessHandle.of(pid).map(ProcessHandle::isAlive).orElse(false);
        }
        catch (Exception e) {
            return false;
        }
    }

    private int readPortFromTempFile() {
        Path portFile = this.getTempDir().resolve(PORT_FILE_NAME);
        try {
            if (Files.exists(portFile, new LinkOption[0])) {
                return Integer.parseInt(Files.readString(portFile).trim());
            }
        }
        catch (Exception ignored) {}
        return -1;
    }

    private int waitForPortFile(long timeoutMs) {
        Path portFile = this.getTempDir().resolve(PORT_FILE_NAME);
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeoutMs) {
            int p;
            if (Files.exists(portFile, new LinkOption[0]) && (p = this.readPortFromTempFile()) > 0) {
                return p;
            }
            try {
                Thread.sleep(200L);
            }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return -1;
            }
            if (this.helperProcess == null || this.helperProcess.isAlive()) continue;
            return -1;
        }
        return -1;
    }

    private void extractHelperIfNeeded(Path targetPath) throws IOException {
        Files.createDirectories(targetPath.getParent(), new FileAttribute[0]);
        try (InputStream in = this.getClass().getResourceAsStream("/helper/YandexMusicHelper.exe");){
            if (in == null) {
                if (!Files.exists(targetPath, new LinkOption[0])) {
                    throw new IOException("Helper exe not found");
                }
                return;
            }
            try {
                Files.copy(in, targetPath, StandardCopyOption.REPLACE_EXISTING);
            }
            catch (IOException copyEx) {
                if (!Files.exists(targetPath, new LinkOption[0])) {
                    throw copyEx;
                }
            }
        }
    }

    private Path getTempDir() {
        String temp = System.getenv("TEMP");
        if (temp == null) {
            temp = System.getProperty("java.io.tmpdir");
        }
        return Path.of(temp, new String[0]);
    }
}

