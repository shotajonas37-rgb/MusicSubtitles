package com.example.yandexmusichud.hud;

import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public class ModernButtonWidget
extends class_339 {
    private final PressAction onPress;
    private boolean isPrimary = false;
    private int customBgColor = 0;
    private long lastClickTime = 0L;
    private float hoverProgress = 0.0f;
    private long lastRenderTime = 0L;
    private float clickX = -1.0f;
    private float clickY = -1.0f;
    private class_2960 iconTexture = null;
    private int iconSize = 0;

    public ModernButtonWidget(int x, int y, int width, int height, class_2561 message, PressAction onPress) {
        super(x, y, width, height, message);
        this.onPress = onPress;
    }

    public ModernButtonWidget setIconTexture(class_2960 texture, int size) {
        this.iconTexture = texture;
        this.iconSize = size;
        return this;
    }

    public ModernButtonWidget setPrimary(boolean primary) {
        this.isPrimary = primary;
        return this;
    }

    public ModernButtonWidget setCustomBgColor(int argb) {
        this.customBgColor = argb;
        return this;
    }

    public boolean method_25402(class_11909 click, boolean bl) {
        if (this.field_22763 && this.field_22764 && this.method_49606()) {
            this.lastClickTime = System.currentTimeMillis();
            this.clickX = (float)click.comp_4798();
            this.clickY = (float)click.comp_4799();
            this.method_25354(class_310.method_1551().method_1483());
            if (this.onPress != null) {
                this.onPress.onPress(this);
            }
            return true;
        }
        return false;
    }

    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 mc = class_310.method_1551();
        class_327 textRenderer = mc.field_1772;
        long now = System.currentTimeMillis();
        float dt = this.lastRenderTime > 0L ? Math.min(0.1f, (float)(now - this.lastRenderTime) / 1000.0f) : 0.016f;
        this.lastRenderTime = now;
        boolean isTargetHovered = this.method_49606() && this.field_22763;
        float target = isTargetHovered ? 1.0f : 0.0f;
        this.hoverProgress += (target - this.hoverProgress) * Math.min(1.0f, dt * 14.0f);
        long timeSinceClick = now - this.lastClickTime;
        float pressCompression = 0.0f;
        if (timeSinceClick < 160L) {
            float p = (float)timeSinceClick / 160.0f;
            pressCompression = 0.035f * (1.0f - p);
        }
        float totalScale = 1.0f + 0.025f * this.hoverProgress - pressCompression;
        float liftY = -1.0f * this.hoverProgress;
        context.method_51448().pushMatrix();
        float cx = (float)this.method_46426() + (float)this.method_25368() * 0.5f;
        float cy = (float)this.method_46427() + (float)this.method_25364() * 0.5f;
        context.method_51448().translate(cx, cy + liftY);
        context.method_51448().scale(totalScale, totalScale);
        context.method_51448().translate(-cx, -cy);
        int r = 4;
        int normalBg = this.customBgColor != 0 ? this.customBgColor : (!this.field_22763 ? 0x5511111E : (this.isPrimary ? -14326805 : -1441261526));
        int hoverBg = this.customBgColor != 0 ? this.customBgColor : (!this.field_22763 ? 0x5511111E : (this.isPrimary ? -12877066 : -584439228));
        int bg = ModernButtonWidget.lerpColor(normalBg, hoverBg, this.hoverProgress);
        MusicHudRenderer.renderRoundedRect(context, this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), r, bg);
        int normalBorder = !this.field_22763 ? 0x22FFFFFF : (this.isPrimary ? -2003581443 : 0x33FFFFFF);
        int hoverBorder = !this.field_22763 ? 0x22FFFFFF : -1436506630;
        int borderColor = ModernButtonWidget.lerpColor(normalBorder, hoverBorder, this.hoverProgress);
        context.method_25294(this.method_46426() + r, this.method_46427(), this.method_46426() + this.method_25368() - r, this.method_46427() + 1, borderColor);
        context.method_25294(this.method_46426() + r, this.method_46427() + this.method_25364() - 1, this.method_46426() + this.method_25368() - r, this.method_46427() + this.method_25364(), borderColor);
        context.method_25294(this.method_46426(), this.method_46427() + r, this.method_46426() + 1, this.method_46427() + this.method_25364() - r, borderColor);
        context.method_25294(this.method_46426() + this.method_25368() - 1, this.method_46427() + r, this.method_46426() + this.method_25368(), this.method_46427() + this.method_25364() - r, borderColor);
        int glassHighlight = ModernButtonWidget.lerpColor(0x18FFFFFF, 0x48FFFFFF, this.hoverProgress);
        context.method_25294(this.method_46426() + r, this.method_46427() + 1, this.method_46426() + this.method_25368() - r, this.method_46427() + 2, glassHighlight);
        if (this.hoverProgress > 0.02f && this.field_22763) {
            int glowAlpha = (int)(this.hoverProgress * 60.0f);
            int glowColor = glowAlpha << 24 | 0xE5FF;
            MusicHudRenderer.renderRoundedRect(context, this.method_46426() - 1, this.method_46427() - 1, this.method_25368() + 2, this.method_25364() + 2, r + 1, glowColor);
        }
        if (timeSinceClick < 350L && this.clickX >= 0.0f) {
            float p = (float)timeSinceClick / 350.0f;
            float maxR = (float)Math.max(this.method_25368(), this.method_25364()) * 0.9f;
            float currentR = maxR * ModernButtonWidget.easeOutCubic(p);
            int rippleAlpha = (int)((1.0f - p) * 65.0f);
            if (rippleAlpha > 0) {
                int rippleColor = rippleAlpha << 24 | 0xE5FF;
                context.method_44379(this.method_46426(), this.method_46427(), this.method_46426() + this.method_25368(), this.method_46427() + this.method_25364());
                MusicHudRenderer.renderRoundedRect(context, (int)(this.clickX - currentR), (int)(this.clickY - currentR), (int)(currentR * 2.0f), (int)(currentR * 2.0f), (int)currentR, rippleColor);
                context.method_44380();
            }
        }
        int normalText = !this.field_22763 ? -7829368 : (this.isPrimary ? -1 : -2039584);
        int hoverText = !this.field_22763 ? -7829368 : -1;
        int textColor = ModernButtonWidget.lerpColor(normalText, hoverText, this.hoverProgress);
        if (this.iconTexture != null && this.iconSize > 0) {
            int ix = this.method_46426() + (this.method_25368() - this.iconSize) / 2;
            int iy = this.method_46427() + (this.method_25364() - this.iconSize) / 2;
            try {
                context.method_25290(class_10799.field_56883, this.iconTexture, ix, iy, 0.0f, 0.0f, this.iconSize, this.iconSize, this.iconSize, this.iconSize);
            } catch (Throwable t) {
                context.method_27534(textRenderer, this.method_25369(), this.method_46426() + this.method_25368() / 2, this.method_46427() + (this.method_25364() - 8) / 2, textColor);
            }
        } else {
            context.method_27534(textRenderer, this.method_25369(), this.method_46426() + this.method_25368() / 2, this.method_46427() + (this.method_25364() - 8) / 2, textColor);
        }
        context.method_51448().popMatrix();
    }

    private static float easeOutCubic(float t) {
        float f = t - 1.0f;
        return f * f * f + 1.0f;
    }

    private static int lerpColor(int c1, int c2, float t) {
        if (t <= 0.0f) {
            return c1;
        }
        if (t >= 1.0f) {
            return c2;
        }
        int a1 = c1 >> 24 & 0xFF;
        int r1 = c1 >> 16 & 0xFF;
        int g1 = c1 >> 8 & 0xFF;
        int b1 = c1 & 0xFF;
        int a2 = c2 >> 24 & 0xFF;
        int r2 = c2 >> 16 & 0xFF;
        int g2 = c2 >> 8 & 0xFF;
        int b2 = c2 & 0xFF;
        int a = (int)((float)a1 + (float)(a2 - a1) * t);
        int r = (int)((float)r1 + (float)(r2 - r1) * t);
        int g = (int)((float)g1 + (float)(g2 - g1) * t);
        int b = (int)((float)b1 + (float)(b2 - b1) * t);
        return a << 24 | r << 16 | g << 8 | b;
    }

    protected void method_47399(class_6382 builder) {
        this.method_37021(builder);
    }

    public static interface PressAction {
        public void onPress(ModernButtonWidget var1);
    }
}

