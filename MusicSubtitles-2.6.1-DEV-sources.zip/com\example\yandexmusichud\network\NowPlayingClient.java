package com.example.yandexmusichud.network;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.network.TrackState;
import com.example.yandexmusichud.texture.CoverTextureManager;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class NowPlayingClient {
    public static NowPlayingClient INSTANCE;
    private final AtomicReference<TrackState> currentState = new AtomicReference<TrackState>(TrackState.INACTIVE);
    private ScheduledExecutorService scheduler;
    private final CoverTextureManager coverManager;
    private String baseUrl;
    private String lastCoverHash = null;
    private String lastCoverETag = null;
    private int backoffMs = 300;
    private static final int MAX_BACKOFF_MS = 10000;
    private volatile boolean connected = false;

    public NowPlayingClient(CoverTextureManager coverManager) {
        this.coverManager = coverManager;
        INSTANCE = this;
    }

    public TrackState getState() {
        return this.currentState.get();
    }

    public boolean isConnected() {
        return this.connected;
    }

    public void start(int port) {
        this.baseUrl = "http://127.0.0.1:" + port;
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "MusicSubtitles-Poller");
            t.setDaemon(true);
            return t;
        });
        this.scheduleNextPoll(0);
    }

    public void stop() {
        if (this.scheduler != null) {
            this.scheduler.shutdownNow();
            this.scheduler = null;
        }
    }

    private void scheduleNextPoll(int delayMs) {
        if (this.scheduler == null || this.scheduler.isShutdown()) {
            return;
        }
        this.scheduler.schedule(this::poll, (long)Math.max(0, delayMs), TimeUnit.MILLISECONDS);
    }

    private void poll() {
        try {
            URL url = URI.create(this.baseUrl + "/now-playing").toURL();
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(1000);
            conn.setReadTimeout(1000);
            conn.setUseCaches(false);
            long tStart = System.currentTimeMillis();
            int code = conn.getResponseCode();
            long tEnd = System.currentTimeMillis();
            long receivedTime = (tStart + tEnd) / 2L;
            if (code == 200) {
                boolean isActive;
                String body;
                this.connected = true;
                this.backoffMs = Math.max(150, HudConfig.INSTANCE.pollIntervalMs);
                try (InputStream is = conn.getInputStream();){
                    body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                }
                JsonObject json = JsonParser.parseString((String)body).getAsJsonObject();
                boolean bl = isActive = json.has("isActive") && json.get("isActive").getAsBoolean();
                if (isActive) {
                    Object title = this.getStringOrDefault(json, "title", "").replace('\u2014', '-').replace('\u2013', '-');
                    String artist = this.getStringOrDefault(json, "artist", "").replace('\u2014', '-').replace('\u2013', '-');
                    String album = this.getStringOrDefault(json, "album", "").replace('\u2014', '-').replace('\u2013', '-');
                    if (((String)title).matches("^\\d+$") && !artist.isBlank()) {
                        title = artist + "-" + (String)title;
                        artist = "";
                    }
                    if (artist.matches("(?i)^(?:\u043a\u043b\u0438\u043f|\u0432\u0438\u0434\u0435\u043e|video|clip)\\s*[\u2022\u00b7\\-]\\s*.*")) {
                        artist = artist.replaceFirst("(?i)^(?:\u043a\u043b\u0438\u043f|\u0432\u0438\u0434\u0435\u043e|video|clip)\\s*[\u2022\u00b7\\-]\\s*", "").trim();
                    }
                    if (((String)title).matches("(?i)^(?:\u043a\u043b\u0438\u043f|\u0432\u0438\u0434\u0435\u043e|video|clip)\\s*[\u2022\u00b7\\-]\\s*.*")) {
                        title = ((String)title).replaceFirst("(?i)^(?:\u043a\u043b\u0438\u043f|\u0432\u0438\u0434\u0435\u043e|video|clip)\\s*[\u2022\u00b7\\-]\\s*", "").trim();
                    }
                    if ((artist.isBlank() || NowPlayingClient.isGenericArtist(artist)) && ((String)title).contains(" - ")) {
                        int dashIdx = ((String)title).indexOf(" - ");
                        artist = ((String)title).substring(0, dashIdx).trim();
                        title = ((String)title).substring(dashIdx + 3).trim();
                    }
                    String status = this.getStringOrDefault(json, "status", "stopped");
                    long posMs = json.has("positionMs") ? json.get("positionMs").getAsLong() : 0L;
                    long durMs = json.has("durationMs") ? json.get("durationMs").getAsLong() : 0L;
                    String coverHash = json.has("coverHash") && !json.get("coverHash").isJsonNull() ? json.get("coverHash").getAsString() : null;
                    String platform = json.has("platform") && !json.get("platform").isJsonNull() ? json.get("platform").getAsString() : TrackState.detectPlatform((String)title, artist, album);
                    String platformName = json.has("platformName") && !json.get("platformName").isJsonNull() ? json.get("platformName").getAsString() : TrackState.detectPlatformName((String)title, artist, album);
                    String playUrl = json.has("playUrl") && !json.get("playUrl").isJsonNull() ? json.get("playUrl").getAsString() : TrackState.generatePlayUrl((String)title, artist);
                    String detected = TrackState.detectPlatform((String)title, artist, album);
                    if (!"music".equals(detected) && !"yandex".equals(detected)) {
                        platform = detected;
                        platformName = TrackState.detectPlatformName((String)title, artist, album);
                        playUrl = TrackState.generatePlayUrl((String)title, artist);
                    } else if ("yandex".equalsIgnoreCase(platform) && "\u042f\u043d\u0434\u0435\u043a\u0441 \u041c\u0443\u0437\u044b\u043a\u0430".equals(platformName)) {
                        boolean hasYandexTrace;
                        String fullLower = ((String)title + " " + artist + " " + album).toLowerCase();
                        boolean bl2 = hasYandexTrace = fullLower.contains("\u044f\u043d\u0434\u0435\u043a\u0441") || fullLower.contains("yandex");
                        if (!(hasYandexTrace || playUrl != null && playUrl.contains("music.yandex"))) {
                            platform = "music";
                            platformName = "\u041c\u0443\u0437\u044b\u043a\u0430";
                        }
                    }
                    float speed = json.has("playbackSpeed") && !json.get("playbackSpeed").isJsonNull() ? json.get("playbackSpeed").getAsFloat() : 1.0f;
                    TrackState state = new TrackState(true, (String)title, artist, album, status, posMs, durMs, coverHash, receivedTime, platform, platformName, playUrl, speed);
                    this.currentState.set(state);
                    if (coverHash != null && !coverHash.equals(this.lastCoverHash)) {
                        this.fetchCover(coverHash);
                    }
                } else {
                    this.currentState.set(TrackState.INACTIVE);
                }
            }
            conn.disconnect();
        }
        catch (Exception e) {
            this.connected = false;
            this.currentState.set(TrackState.INACTIVE);
            this.backoffMs = Math.min(Math.max(500, this.backoffMs * 2), 10000);
        }
        this.scheduleNextPoll(this.backoffMs);
    }

    private void fetchCover(String coverHash) {
        try {
            int code;
            URL url = URI.create(this.baseUrl + "/cover").toURL();
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(2000);
            conn.setReadTimeout(2000);
            if (this.lastCoverETag != null) {
                conn.setRequestProperty("If-None-Match", this.lastCoverETag);
            }
            if ((code = conn.getResponseCode()) == 304) {
                conn.disconnect();
                return;
            }
            if (code == 200) {
                String base64;
                String body;
                try (InputStream is = conn.getInputStream();){
                    body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                }
                JsonObject coverJson = JsonParser.parseString((String)body).getAsJsonObject();
                String string = base64 = coverJson.has("coverBase64") && !coverJson.get("coverBase64").isJsonNull() ? coverJson.get("coverBase64").getAsString() : null;
                if (base64 != null && !base64.isEmpty()) {
                    this.lastCoverHash = coverHash;
                    String etag = conn.getHeaderField("ETag");
                    this.lastCoverETag = etag != null ? etag : coverHash;
                    this.coverManager.updateCover(base64);
                }
            }
            conn.disconnect();
        }
        catch (Exception exception) {

        }
    }

    private String getStringOrDefault(JsonObject json, String key, String defaultVal) {
        return json.has(key) && !json.get(key).isJsonNull() ? json.get(key).getAsString() : defaultVal;
    }

    public void sendPlayPauseAsync() {
        this.sendControlAsync("/control/play-pause");
    }

    public void sendNextAsync() {
        this.sendControlAsync("/control/next");
    }

    public void sendPreviousAsync() {
        this.sendControlAsync("/control/previous");
    }

    private void sendControlAsync(String path) {
        if (!this.connected || this.baseUrl == null) {
            return;
        }
        CompletableFuture.runAsync(() -> {
            try {
                URL url = URI.create(this.baseUrl + path).toURL();
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(1000);
                conn.setReadTimeout(1000);
                conn.setDoOutput(true);
                conn.getOutputStream().close();
                conn.getResponseCode();
                conn.disconnect();
            }
            catch (Exception exception) {

            }
        });
    }

    public static boolean isGenericArtist(String a) {
        if (a == null || a.isBlank()) {
            return true;
        }
        String s = a.trim().toLowerCase();
        return s.equals("youtube") || s.equals("youtube music") || s.equals("soundcloud") || s.equals("spotify") || s.equals("google chrome") || s.equals("chrome") || s.equals("chrome.exe") || s.equals("msedge") || s.equals("msedge.exe") || s.equals("opera") || s.equals("firefox") || s.equals("firefox.exe") || s.equals("brave") || s.equals("vivaldi") || s.equals("yandex") || s.equals("browser");
    }
}

