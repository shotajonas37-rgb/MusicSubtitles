package com.example.yandexmusichud.hud;

import com.example.yandexmusichud.hud.MusicHudRenderer;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;

public class ModernSliderWidget
extends class_357 {
    private final String label;
    private final Formatter formatter;
    private final Consumer<Double> onValueChange;
    private float hoverProgress = 0.0f;
    private long lastRenderTime = 0L;

    public ModernSliderWidget(int x, int y, int width, int height, String label, double initialValue, Formatter formatter, Consumer<Double> onValueChange) {
        super(x, y, width, height, (class_2561)class_2561.method_43473(), class_3532.method_15350((double)initialValue, (double)0.0, (double)1.0));
        this.label = label;
        this.formatter = formatter;
        this.onValueChange = onValueChange;
        this.method_25346();
    }

    protected void method_25346() {
        if (this.formatter != null) {
            this.method_25355((class_2561)class_2561.method_43470((String)(this.label + this.formatter.format(this.field_22753))));
        } else {
            this.method_25355((class_2561)class_2561.method_43470((String)(this.label + String.format("%.2f", this.field_22753))));
        }
    }

    protected void method_25344() {
        if (this.onValueChange != null) {
            this.onValueChange.accept(this.field_22753);
        }
    }

    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 mc = class_310.method_1551();
        class_327 textRenderer = mc.field_1772;
        long now = System.currentTimeMillis();
        float dt = this.lastRenderTime > 0L ? Math.min(0.1f, (float)(now - this.lastRenderTime) / 1000.0f) : 0.016f;
        this.lastRenderTime = now;
        boolean activeOrHovered = this.method_49606() || this.method_25370();
        float target = activeOrHovered ? 1.0f : 0.0f;
        this.hoverProgress += (target - this.hoverProgress) * Math.min(1.0f, dt * 14.0f);
        int r = 4;
        int trackBg = activeOrHovered ? -584965576 : -1441524700;
        MusicHudRenderer.renderRoundedRect(context, this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), r, trackBg);
        int filledWidth = (int)((double)(this.method_25368() - 8) * this.field_22753);
        if (filledWidth > 2) {
            MusicHudRenderer.renderRoundedRect(context, this.method_46426() + 2, this.method_46427() + 2, filledWidth, this.method_25364() - 4, r - 1, 1715176182);
        }
        int thumbW = (int)(8.0f + 4.0f * this.hoverProgress);
        int thumbX = this.method_46426() + (int)((double)(this.method_25368() - thumbW - 4) * this.field_22753) + 2;
        int normalThumb = -12877066;
        int hoverThumb = -7092739;
        int thumbColor = ModernSliderWidget.lerpColor(normalThumb, hoverThumb, this.hoverProgress);
        MusicHudRenderer.renderRoundedRect(context, thumbX, this.method_46427() + 2, thumbW, this.method_25364() - 4, 3, thumbColor);
        int borderColor = activeOrHovered ? -2006931974 : 0x33FFFFFF;
        context.method_25294(this.method_46426() + r, this.method_46427(), this.method_46426() + this.method_25368() - r, this.method_46427() + 1, borderColor);
        context.method_25294(this.method_46426() + r, this.method_46427() + this.method_25364() - 1, this.method_46426() + this.method_25368() - r, this.method_46427() + this.method_25364(), borderColor);
        context.method_25294(this.method_46426(), this.method_46427() + r, this.method_46426() + 1, this.method_46427() + this.method_25364() - r, borderColor);
        context.method_25294(this.method_46426() + this.method_25368() - 1, this.method_46427() + r, this.method_46426() + this.method_25368(), this.method_46427() + this.method_25364() - r, borderColor);
        int textColor = activeOrHovered ? -1 : -1906448;
        context.method_27534(textRenderer, this.method_25369(), this.method_46426() + this.method_25368() / 2, this.method_46427() + (this.method_25364() - 8) / 2, textColor);
        if (this.hoverProgress > 0.05f) {
            String valText = this.formatter != null ? this.formatter.format(this.field_22753) : String.format("%.2f", this.field_22753);
            if ((valText = valText.trim()).startsWith(":")) {
                valText = valText.substring(1).trim();
            }
            int bubbleTextW = textRenderer.method_1727(valText);
            int bubbleW = bubbleTextW + 10;
            int bubbleH = 13;
            int bubbleX = thumbX + thumbW / 2 - bubbleW / 2;
            int bubbleY = this.method_46427() - 15 - (int)(this.hoverProgress * 3.0f);
            int bAlpha = (int)(this.hoverProgress * 240.0f);
            if (bAlpha > 5) {
                MusicHudRenderer.renderRoundedRect(context, bubbleX, bubbleY, bubbleW, bubbleH, 4, bAlpha << 24 | 0x121320);
                MusicHudRenderer.renderRoundedBorder(context, bubbleX, bubbleY, bubbleW, bubbleH, 4, (int)(this.hoverProgress * 200.0f) << 24 | 0xE5FF, (int)(this.hoverProgress * 140.0f) << 24 | 0x77AA);
                int arrowX = thumbX + thumbW / 2;
                int arrowAlpha = (int)(this.hoverProgress * 200.0f);
                context.method_25294(arrowX - 2, bubbleY + bubbleH, arrowX + 2, bubbleY + bubbleH + 1, arrowAlpha << 24 | 0xE5FF);
                context.method_25294(arrowX - 1, bubbleY + bubbleH + 1, arrowX + 1, bubbleY + bubbleH + 2, arrowAlpha << 24 | 0xE5FF);
                context.method_27534(textRenderer, (class_2561)class_2561.method_43470((String)valText), thumbX + thumbW / 2, bubbleY + 2, bAlpha << 24 | 0xFFFFFF);
            }
        }
    }

    private static int lerpColor(int c1, int c2, float t) {
        if (t <= 0.0f) {
            return c1;
        }
        if (t >= 1.0f) {
            return c2;
        }
        int a1 = c1 >> 24 & 0xFF;
        int r1 = c1 >> 16 & 0xFF;
        int g1 = c1 >> 8 & 0xFF;
        int b1 = c1 & 0xFF;
        int a2 = c2 >> 24 & 0xFF;
        int r2 = c2 >> 16 & 0xFF;
        int g2 = c2 >> 8 & 0xFF;
        int b2 = c2 & 0xFF;
        int a = (int)((float)a1 + (float)(a2 - a1) * t);
        int r = (int)((float)r1 + (float)(r2 - r1) * t);
        int g = (int)((float)g1 + (float)(g2 - g1) * t);
        int b = (int)((float)b1 + (float)(b2 - b1) * t);
        return a << 24 | r << 16 | g << 8 | b;
    }

    public static interface Formatter {
        public String format(double var1);
    }
}

