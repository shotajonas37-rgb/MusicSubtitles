package com.example.yandexmusichud.lyrics;

import com.example.yandexmusichud.lyrics.LyricLine;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LyricsConsensusEngine {
    public static Set<String> extractPhrases(List<LyricLine> lines, String rawText) {
        HashSet<String> set = new HashSet<String>();
        ArrayList<String> rawLines = new ArrayList<String>();
        if (lines != null && !lines.isEmpty()) {
            for (LyricLine l : lines) {
                if (l == null || l.text == null) continue;
                rawLines.add(l.text);
            }
        } else if (rawText != null && !rawText.isBlank()) {
            String[] split = rawText.split("\\r?\\n");
            rawLines.addAll(Arrays.asList(split));
        }
        for (String raw : rawLines) {
            String norm = LyricsConsensusEngine.normalize(raw);
            if (norm.isEmpty()) continue;
            String[] words = norm.split("\\s+");
            if (words.length >= 2) {
                set.add(norm);
            }
            if (words.length < 3) continue;
            for (int i = 0; i <= words.length - 3; ++i) {
                set.add(words[i] + " " + words[i + 1] + " " + words[i + 2]);
            }
        }
        return set;
    }

    public static Candidate selectBest(List<Candidate> candidates, long durationSec) {
        if (candidates == null || candidates.isEmpty()) {
            return null;
        }
        ArrayList<Candidate> valid = new ArrayList<Candidate>();
        for (Candidate c : candidates) {
            if (c == null || c.lines.isEmpty() && c.rawText.isBlank()) continue;
            valid.add(c);
        }
        if (valid.isEmpty()) {
            return null;
        }
        if (valid.size() == 1) {
            Candidate single = (Candidate)valid.get(0);
            single.score = 100.0;
            return single;
        }
        for (Candidate c : valid) {
            if (c.isSynced) {
                c.score += 150.0;
            }
            if ("YANDEX_SYNCED".equalsIgnoreCase(c.provider)) {
                c.score += 120.0;
                continue;
            }
            if ("GENIUS".equalsIgnoreCase(c.provider)) {
                c.score += 110.0;
                continue;
            }
            if ("LRCLIB_SYNCED".equalsIgnoreCase(c.provider)) {
                c.score += 90.0;
                continue;
            }
            if ("LRCLIB_PLAIN".equalsIgnoreCase(c.provider)) {
                c.score += 40.0;
                continue;
            }
            if ("NETEASE".equalsIgnoreCase(c.provider)) {
                c.score += 15.0;
                continue;
            }
            if (!"OVH".equalsIgnoreCase(c.provider)) continue;
            c.score += 20.0;
        }
        for (int i = 0; i < valid.size(); ++i) {
            Candidate a = (Candidate)valid.get(i);
            for (int j = i + 1; j < valid.size(); ++j) {
                Candidate b = (Candidate)valid.get(j);
                double overlap = LyricsConsensusEngine.computePhraseOverlap(a.phrases, b.phrases);
                if (overlap >= 0.45) {
                    double bonus = 450.0 * overlap;
                    a.score += bonus;
                    b.score += bonus;
                    a.hasCrossConsensus = true;
                    b.hasCrossConsensus = true;
                    continue;
                }
                if (!(overlap < 0.1)) continue;
                if ("GENIUS".equalsIgnoreCase(a.provider)) {
                    b.score -= 550.0;
                    continue;
                }
                if (!"GENIUS".equalsIgnoreCase(b.provider)) continue;
                a.score -= 550.0;
            }
        }
        if (durationSec > 25L) {
            for (Candidate c : valid) {
                if (!c.isSynced || c.lines.isEmpty()) continue;
                long firstMs = c.lines.get((int)0).startMs;
                long lastMs = c.lines.get((int)(c.lines.size() - 1)).endMs;
                long durMs = durationSec * 1000L;
                if (lastMs > durMs + 12000L) {
                    c.score -= 500.0;
                } else if ((double)lastMs < (double)durMs * 0.42 && durMs > 60000L) {
                    c.score -= 400.0;
                }
                if (!((double)firstMs > (double)durMs * 0.55) || durMs <= 45000L) continue;
                c.score -= 450.0;
            }
        }
        valid.sort((c1, c2) -> Double.compare(c2.score, c1.score));
        Candidate winner = (Candidate)valid.get(0);
        if (!winner.hasCrossConsensus && valid.size() > 1) {
            winner.possibleMismatch = true;
        }
        return winner;
    }

    public static double computePhraseOverlap(Set<String> setA, Set<String> setB) {
        if (setA == null || setB == null || setA.isEmpty() || setB.isEmpty()) {
            return 0.0;
        }
        int minSize = Math.min(setA.size(), setB.size());
        if (minSize == 0) {
            return 0.0;
        }
        int intersection = 0;
        for (String p : setA) {
            if (!setB.contains(p)) continue;
            ++intersection;
        }
        return (double)intersection / (double)minSize;
    }

    private static String normalize(String s) {
        if (s == null) {
            return "";
        }
        return s.toLowerCase().replaceAll("[^a-z\u0430-\u044f0-9\\s]", "").replaceAll("\\s+", " ").trim();
    }

    public static class Candidate {
        public final String provider;
        public final List<LyricLine> lines;
        public final String rawText;
        public final boolean isSynced;
        public final Set<String> phrases;
        public double score = 0.0;
        public boolean hasCrossConsensus = false;
        public boolean possibleMismatch = false;

        public Candidate(String provider, List<LyricLine> lines, String rawText, boolean isSynced) {
            this.provider = provider != null ? provider : "UNKNOWN";
            this.lines = lines != null ? lines : Collections.emptyList();
            this.rawText = rawText != null ? rawText : "";
            this.isSynced = isSynced;
            this.phrases = LyricsConsensusEngine.extractPhrases(this.lines, this.rawText);
        }
    }
}

