package com.example.yandexmusichud.lyrics;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_3532;

public class LyricLine {
    public final long startMs;
    public final long endMs;
    public final long vocalEndMs;
    public final String text;
    public final List<Word> words;

    public LyricLine(long startMs, long endMs, String text, List<Word> words) {
        this(startMs, endMs, endMs, text, words);
    }

    public LyricLine(long startMs, long endMs, long vocalEndMs, String text, List<Word> words) {
        this.startMs = startMs;
        this.endMs = Math.max(endMs, startMs + 60L);
        this.vocalEndMs = Math.max(vocalEndMs, startMs + 50L);
        this.text = text != null ? text.trim().replace('\u2014', '-').replace('\u2013', '-') : "";
        this.words = words != null ? words : List.of();
    }

    public LyricLine scaled(double factor) {
        long newStart = Math.max(0L, (long)((double)this.startMs * factor));
        long newEnd = Math.max(newStart + 60L, (long)((double)this.endMs * factor));
        long newVocalEnd = Math.max(newStart + 50L, (long)((double)this.vocalEndMs * factor));
        ArrayList<Word> newWords = null;
        if (!this.words.isEmpty()) {
            newWords = new ArrayList<Word>(this.words.size());
            for (Word w : this.words) {
                long ws = Math.max(0L, (long)((double)w.startMs() * factor));
                long we = Math.max(ws + 50L, (long)((double)w.endMs() * factor));
                newWords.add(new Word(ws, we, w.text(), w.charStart(), w.charEnd()));
            }
        }
        return new LyricLine(newStart, newEnd, newVocalEnd, this.text, newWords);
    }

    public float getCharAlpha(int charIndex, long trackPosMs) {
        if (this.words.isEmpty()) {
            long totalDur = this.vocalEndMs - this.startMs;
            if (totalDur <= 0L) {
                return 1.0f;
            }
            int len = this.text.length();
            if (len <= 0) {
                return 1.0f;
            }
            long activeSingingDur = (long)((float)totalDur * 0.95f);
            long charStartMs = this.startMs + (long)((float)charIndex / (float)len * (float)activeSingingDur);
            long charFadeDur = Math.max(25L, Math.min(65L, activeSingingDur / (long)len + 20L));
            long charEndMs = charStartMs + charFadeDur;
            if (trackPosMs < charStartMs) {
                return 0.6f;
            }
            if (trackPosMs >= charEndMs) {
                return 1.0f;
            }
            float progress = (float)(trackPosMs - charStartMs) / (float)charFadeDur;
            return 0.6f + 0.4f * progress;
        }
        Word charWord = null;
        int offsetInWord = 0;
        for (Word w : this.words) {
            if (charIndex < w.charStart() || charIndex >= w.charEnd()) continue;
            charWord = w;
            offsetInWord = charIndex - w.charStart();
            break;
        }
        if (charWord == null) {
            return 1.0f;
        }
        long wordDur = Math.max(60L, charWord.endMs() - charWord.startMs());
        int wordLen = Math.max(1, charWord.text().length());
        long charStartMs = charWord.startMs() + (long)((float)offsetInWord / (float)wordLen * (float)wordDur);
        long charFadeDur = Math.max(25L, Math.min(70L, wordDur / (long)wordLen + 15L));
        long charEndMs = charStartMs + charFadeDur;
        if (trackPosMs < charStartMs) {
            return 0.6f;
        }
        if (trackPosMs >= charEndMs) {
            return 1.0f;
        }
        float progress = (float)(trackPosMs - charStartMs) / (float)charFadeDur;
        return 0.6f + 0.4f * progress;
    }

    public boolean isCharActive(int charIndex, long trackPosMs) {
        if (!this.words.isEmpty()) {
            for (Word w : this.words) {
                if (charIndex < w.charStart() || charIndex >= w.charEnd()) continue;
                return trackPosMs >= w.startMs() && trackPosMs <= w.endMs();
            }
            return false;
        }
        long totalDur = this.vocalEndMs - this.startMs;
        if (totalDur <= 0L || this.text.isEmpty()) {
            return false;
        }
        long activeSingingDur = (long)((float)totalDur * 0.95f);
        int len = this.text.length();
        long charStartMs = this.startMs + (long)((float)charIndex / (float)len * (float)activeSingingDur);
        long charEndMs = charStartMs + Math.max(35L, Math.min(85L, activeSingingDur / (long)len + 25L));
        return trackPosMs >= charStartMs && trackPosMs <= charEndMs;
    }

    public float getCharActiveProgress(int charIndex, long trackPosMs) {
        if (!this.words.isEmpty()) {
            for (Word w : this.words) {
                if (charIndex < w.charStart() || charIndex >= w.charEnd()) continue;
                long dur = w.endMs() - w.startMs();
                if (dur <= 0L) {
                    return 1.0f;
                }
                if (trackPosMs < w.startMs()) {
                    return -1.0f;
                }
                if (trackPosMs > w.endMs()) {
                    return 2.0f;
                }
                long activeBounceDur = Math.min(dur, 160L);
                long elapsed = trackPosMs - w.startMs();
                if (elapsed <= activeBounceDur) {
                    return (float)elapsed / (float)activeBounceDur;
                }
                return 1.0f;
            }
            return -1.0f;
        }
        long totalDur = this.vocalEndMs - this.startMs;
        if (totalDur <= 0L || this.text.isEmpty()) {
            return -1.0f;
        }
        long activeSingingDur = (long)((float)totalDur * 0.95f);
        int len = this.text.length();
        long charStartMs = this.startMs + (long)((float)charIndex / (float)len * (float)activeSingingDur);
        long charDur = Math.max(25L, Math.min(65L, activeSingingDur / (long)len + 15L));
        if (trackPosMs < charStartMs) {
            return -1.0f;
        }
        if (trackPosMs > charStartMs + charDur) {
            return 2.0f;
        }
        return (float)(trackPosMs - charStartMs) / (float)charDur;
    }

    public float getCharAnimationOffsetY(int charIndex, long trackPosMs, long systemTimeMs, String animMode) {
        if (animMode == null) {
            animMode = "KARAOKE_BOUNCE";
        }
        switch (animMode.toUpperCase()) {
            case "KARAOKE_BOUNCE": {
                float p = this.getCharActiveProgress(charIndex, trackPosMs);
                if (p >= 0.0f && p <= 1.0f) {
                    return -4.5f * (float)Math.sin((double)p * Math.PI);
                }
                return 0.0f;
            }
            case "WAVE_FLOAT": {
                return (float)Math.sin((double)systemTimeMs / 220.0 + (double)charIndex * 0.42) * 3.2f;
            }
            case "ELASTIC_POP": {
                long age = Math.max(0L, trackPosMs - this.startMs);
                long charDelay = (long)charIndex * 6L;
                long popDur = Math.min(130L, Math.max(65L, (this.vocalEndMs - this.startMs) / Math.max(1, this.text.length()) * 2));
                if (age >= charDelay && age < charDelay + popDur) {
                    float t = (float)(age - charDelay) / (float)popDur;
                    return -6.0f * (float)(Math.sin((double)t * Math.PI * 2.2) * Math.exp((double)(-t) * 3.2));
                }
                return 0.0f;
            }
            case "PULSE_GLOW": {
                float p = this.getCharActiveProgress(charIndex, trackPosMs);
                if (p >= 0.0f && p <= 1.0f) {
                    return -2.2f * (float)Math.sin((double)p * Math.PI);
                }
                return 0.0f;
            }
            case "SLIDE_FADE": {
                long age = Math.max(0L, trackPosMs - this.startMs);
                long slideDur = Math.min(110L, Math.max(55L, this.vocalEndMs - this.startMs));
                if (age < slideDur) {
                    float t = (float)age / (float)slideDur;
                    return 4.0f * (1.0f - t * t);
                }
                return 0.0f;
            }
        }
        return 0.0f;
    }

    public int getCharColor(int charIndex, long trackPosMs, long systemTimeMs, String animMode, int baseRgb, float finalAlpha, int activeColorRgb) {
        if (animMode == null) {
            animMode = "KARAOKE_BOUNCE";
        }
        int alphaInt = Math.min(255, Math.max(16, (int)(finalAlpha * 255.0f)));
        switch (animMode.toUpperCase()) {
            case "KARAOKE_BOUNCE": {
                float p = this.getCharActiveProgress(charIndex, trackPosMs);
                if (p >= 0.0f && p <= 1.0f) {
                    return alphaInt << 24 | activeColorRgb & 0xFFFFFF;
                }
                if (p > 1.0f) {
                    return alphaInt << 24 | baseRgb & 0xFFFFFF;
                }
                int dimAlpha = Math.max(20, (int)((float)alphaInt * 0.75f));
                return dimAlpha << 24 | baseRgb & 0xFFFFFF;
            }
            case "WAVE_FLOAT": {
                float hue = ((float)systemTimeMs / 2800.0f + (float)charIndex * 0.045f) % 1.0f;
                int rgb = class_3532.method_15369((float)hue, (float)0.62f, (float)1.0f);
                return alphaInt << 24 | rgb & 0xFFFFFF;
            }
            case "PULSE_GLOW": {
                float p = this.getCharActiveProgress(charIndex, trackPosMs);
                if (p >= 0.0f && p <= 1.0f) {
                    float pulse = (float)Math.sin((double)systemTimeMs / 130.0) * 0.5f + 0.5f;
                    int r = (int)(0.0f + pulse * 255.0f);
                    int g = (int)(229.0f + pulse * 26.0f);
                    int b = (int)(255.0f - pulse * 187.0f);
                    return alphaInt << 24 | r << 16 | g << 8 | b;
                }
                return alphaInt << 24 | baseRgb & 0xFFFFFF;
            }
            case "ELASTIC_POP": {
                if (this.isCharActive(charIndex, trackPosMs)) {
                    return alphaInt << 24 | 0xFF4081;
                }
                return alphaInt << 24 | baseRgb & 0xFFFFFF;
            }
        }
        return alphaInt << 24 | baseRgb & 0xFFFFFF;
    }

    public List<SubLine> getSubLines(class_327 textRenderer, int maxAllowedWidth) {
        ArrayList<SubLine> result = new ArrayList<SubLine>();
        if (this.text.isEmpty()) {
            return result;
        }
        int totalWidth = textRenderer.method_1727(this.text);
        if (totalWidth <= maxAllowedWidth) {
            result.add(new SubLine(0, this.text.length(), totalWidth));
            return result;
        }
        String[] tokens = this.text.split(" ");
        int lineStart = 0;
        int currentLen = 0;
        for (int i = 0; i < tokens.length; ++i) {
            String token = tokens[i];
            int testLen = currentLen == 0 ? token.length() : currentLen + 1 + token.length();
            String testStr = this.text.substring(lineStart, lineStart + testLen);
            if (textRenderer.method_1727(testStr) > maxAllowedWidth && currentLen > 0) {
                result.add(new SubLine(lineStart, lineStart + currentLen, textRenderer.method_1727(this.text.substring(lineStart, lineStart + currentLen))));
                lineStart = lineStart + currentLen + 1;
                currentLen = token.length();
                continue;
            }
            currentLen = testLen;
        }
        if (currentLen > 0 && lineStart + currentLen <= this.text.length()) {
            result.add(new SubLine(lineStart, lineStart + currentLen, textRenderer.method_1727(this.text.substring(lineStart, lineStart + currentLen))));
        }
        return result;
    }

    public record Word(long startMs, long endMs, String text, int charStart, int charEnd) {
        public Word {
            text = text != null ? text.replace('\u2014', '-').replace('\u2013', '-') : "";
        }
    }

    public record SubLine(int charStart, int charEnd, int width) {
    }
}

