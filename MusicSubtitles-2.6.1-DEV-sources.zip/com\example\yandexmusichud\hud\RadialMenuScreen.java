package com.example.yandexmusichud.hud;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.favorites.FavoritesManager;
import com.example.yandexmusichud.hud.FavoritesScreen;
import com.example.yandexmusichud.hud.HudEditScreen;
import com.example.yandexmusichud.hud.MusicHudRenderer;
import com.example.yandexmusichud.keybinds.MusicControlKeybinds;
import com.example.yandexmusichud.network.NowPlayingClient;
import com.example.yandexmusichud.network.TrackState;
import com.example.yandexmusichud.texture.CoverTextureManager;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10185;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_6880;
import net.minecraft.class_744;
import org.lwjgl.glfw.GLFW;

public class RadialMenuScreen
extends class_437 {
    private static final int SECTOR_COUNT = 8;
    private static final float STEP_ANGLE = 0.7853982f;
    private final NowPlayingClient musicClient;
    private final CoverTextureManager coverManager;
    private int selectedIndex = 0;
    private float currentAngle = 0.0f;
    private float targetAngle = 0.0f;
    private long openTimestamp = -1L;
    private boolean isExiting = false;
    private long exitTimestamp = -1L;
    private int actionToExecuteOnExit = -1;
    private final List<DialItem> items = new ArrayList<DialItem>();

    public RadialMenuScreen(NowPlayingClient musicClient, CoverTextureManager coverManager) {
        super((class_2561)class_2561.method_43470((String)"Music Subtitles Radial Menu"));
        this.musicClient = musicClient;
        this.coverManager = coverManager;
        this.initItems();
        this.selectedIndex = class_3532.method_15340((int)HudConfig.INSTANCE.radialLastSelectedIndex, (int)0, (int)7);
        this.currentAngle = this.targetAngle = (float)this.selectedIndex * 0.7853982f;
    }

    private void initItems() {
        this.items.clear();
        this.items.add(new DialItem("\u23ef", "\u041f\u0430\u0443\u0437\u0430 / \u041f\u043b\u0435\u0439", "\u0412\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u0438 \u043f\u0430\u0443\u0437\u0430", -16711800));
        this.items.add(new DialItem("\u23ed", "\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 \u0442\u0440\u0435\u043a", "\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 \u0442\u0440\u0435\u043a \u0432 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0435", -16718337));
        this.items.add(new DialItem("\u2b50", "\u0412 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435", "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0442\u0440\u0435\u043a \u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435", -10496));
        this.items.add(new DialItem("\ud83d\udcc1", "\u0411\u0438\u0431\u043b\u0438\u043e\u0442\u0435\u043a\u0430", "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0435 \u0442\u0440\u0435\u043a\u0438", -49023));
        this.items.add(new DialItem("\u2699", "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043c\u043e\u0434\u0430", -16718337));
        this.items.add(new DialItem("\ud83d\udc41", "\u0412\u0438\u0434\u0436\u0435\u0442 HUD", "\u0421\u043a\u0440\u044b\u0442\u044c \u0438\u043b\u0438 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0443", -19712));
        this.items.add(new DialItem("\ud83d\udcac", "\u0421\u0443\u0431\u0442\u0438\u0442\u0440\u044b", "\u041f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0440\u0435\u0436\u0438\u043c \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432", -4487428));
        this.items.add(new DialItem("\u23ee", "\u041f\u0440\u0435\u0434\u044b\u0434\u0443\u0449\u0438\u0439 \u0442\u0440\u0435\u043a", "\u041f\u0440\u0435\u0434\u044b\u0434\u0443\u0449\u0438\u0439 \u0442\u0440\u0435\u043a \u0432 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0435", -16718337));
    }

    protected void method_25426() {
        super.method_25426();
        if (this.openTimestamp <= 0L) {
            this.openTimestamp = System.currentTimeMillis();
            this.playSound((class_6880<class_3414>)class_3417.field_14793, 1.4f, 0.75f);
            this.playSound((class_3414)class_3417.field_15015.comp_349(), 1.6f, 0.6f);
        }
    }

    public void method_25393() {
        super.method_25393();
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1724.field_3913 == null) {
            return;
        }
        long windowHandle = mc.method_22683().method_4490();
        boolean forward = RadialMenuScreen.isKeyDown(windowHandle, mc.field_1690.field_1894);
        boolean back = RadialMenuScreen.isKeyDown(windowHandle, mc.field_1690.field_1881);
        boolean left = RadialMenuScreen.isKeyDown(windowHandle, mc.field_1690.field_1913);
        boolean right = RadialMenuScreen.isKeyDown(windowHandle, mc.field_1690.field_1849);
        boolean jump = RadialMenuScreen.isKeyDown(windowHandle, mc.field_1690.field_1903);
        boolean sneak = RadialMenuScreen.isKeyDown(windowHandle, mc.field_1690.field_1832);
        boolean sprint = RadialMenuScreen.isKeyDown(windowHandle, mc.field_1690.field_1867);
        mc.field_1724.field_3913.field_54155 = new class_10185(forward, back, left, right, jump, sneak, sprint);
        float fwd = 0.0f;
        if (forward) {
            fwd += 1.0f;
        }
        if (back) {
            fwd -= 1.0f;
        }
        float strafe = 0.0f;
        if (left) {
            strafe += 1.0f;
        }
        if (right) {
            strafe -= 1.0f;
        }
        class_241 raw = new class_241(strafe, fwd);
        try {
            Field mvField = class_744.class.getDeclaredField("movementVector");
            mvField.setAccessible(true);
            mvField.set(mc.field_1724.field_3913, raw.method_35581());
        }
        catch (Exception ignored) {
            try {
                for (Field f : class_744.class.getDeclaredFields()) {
                    if (f.getType() != class_241.class) continue;
                    f.setAccessible(true);
                    f.set(mc.field_1724.field_3913, raw.method_35581());
                }
            }
            catch (Exception exception) {

            }
        }
    }

    private static boolean isKeyDown(long windowHandle, class_304 binding) {
        class_3675.class_306 key = class_3675.method_15981((String)binding.method_1428());
        if (key.method_1442() == class_3675.class_307.field_1672) {
            return GLFW.glfwGetMouseButton((long)windowHandle, (int)key.method_1444()) == 1;
        }
        if (key.method_1444() > 0) {
            return GLFW.glfwGetKey((long)windowHandle, (int)key.method_1444()) == 1;
        }
        return false;
    }

    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.isExiting) {
            return true;
        }
        if (verticalAmount > 0.05) {
            this.selectedIndex = (this.selectedIndex + 7) % 8;
            this.targetAngle -= 0.7853982f;
            HudConfig.INSTANCE.radialLastSelectedIndex = this.selectedIndex;
            this.playSound((class_6880<class_3414>)class_3417.field_15204, 1.45f + (float)(this.selectedIndex % 4) * 0.1f, 0.85f);
            return true;
        }
        if (verticalAmount < -0.05) {
            this.selectedIndex = (this.selectedIndex + 1) % 8;
            this.targetAngle += 0.7853982f;
            HudConfig.INSTANCE.radialLastSelectedIndex = this.selectedIndex;
            this.playSound((class_6880<class_3414>)class_3417.field_15204, 1.2f + (float)(this.selectedIndex % 4) * 0.1f, 0.85f);
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean method_25404(class_11908 input) {
        if (input.comp_4795() == 256) {
            this.triggerExit(-1);
            return true;
        }
        class_310 mc = class_310.method_1551();
        if (mc != null) {
            int key = input.comp_4795();
            class_3675.class_306 fwd = class_3675.method_15981((String)mc.field_1690.field_1894.method_1428());
            class_3675.class_306 bck = class_3675.method_15981((String)mc.field_1690.field_1881.method_1428());
            class_3675.class_306 lft = class_3675.method_15981((String)mc.field_1690.field_1913.method_1428());
            class_3675.class_306 rgt = class_3675.method_15981((String)mc.field_1690.field_1849.method_1428());
            class_3675.class_306 jmp = class_3675.method_15981((String)mc.field_1690.field_1903.method_1428());
            class_3675.class_306 snk = class_3675.method_15981((String)mc.field_1690.field_1832.method_1428());
            class_3675.class_306 spr = class_3675.method_15981((String)mc.field_1690.field_1867.method_1428());
            if (key == fwd.method_1444() || key == bck.method_1444() || key == lft.method_1444() || key == rgt.method_1444() || key == jmp.method_1444() || key == snk.method_1444() || key == spr.method_1444()) {
                return false;
            }
        }
        return super.method_25404(input);
    }

    public boolean method_25402(class_11909 click, boolean bl) {
        if (this.isExiting) {
            return true;
        }
        float centerX = 0.0f;
        float centerY = (float)this.field_22790 / 2.0f;
        float baseRadius = 80.0f;
        for (int i = 0; i < 8; ++i) {
            float sectorAngle = (float)i * 0.7853982f;
            float phi = sectorAngle - this.currentAngle;
            while ((double)phi > Math.PI) {
                phi -= (float)Math.PI * 2;
            }
            while ((double)phi <= -Math.PI) {
                phi += (float)Math.PI * 2;
            }
            if (Math.cos(phi) < -0.2) continue;
            float pop = i == this.selectedIndex ? 8.0f : 0.0f;
            float r = baseRadius + pop;
            float px = centerX + (float)Math.cos(phi) * r;
            float py = centerY + (float)Math.sin(phi) * r;
            int size = i == this.selectedIndex ? 28 : 22;
            float half = (float)size / 2.0f;
            if (!(click.comp_4798() >= (double)(px - half)) || !(click.comp_4798() <= (double)(px + half)) || !(click.comp_4799() >= (double)(py - half)) || !(click.comp_4799() <= (double)(py + half))) continue;
            this.selectedIndex = i;
            HudConfig.INSTANCE.radialLastSelectedIndex = i;
            this.triggerExit(i);
            return true;
        }
        int tagX = (int)(centerX + baseRadius + 8.0f + 16.0f);
        int tagH = 28;
        int tagY = (int)(centerY - (float)tagH / 2.0f);
        int tagW = 185;
        if (click.comp_4798() >= (double)tagX && click.comp_4798() <= (double)(tagX + tagW) && click.comp_4799() >= (double)tagY && click.comp_4799() <= (double)(tagY + tagH)) {
            HudConfig.INSTANCE.radialLastSelectedIndex = this.selectedIndex;
            this.triggerExit(this.selectedIndex);
            return true;
        }
        return super.method_25402(click, bl);
    }

    private void checkKeyHeld() {
        if (this.isExiting) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.openTimestamp < 180L) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null) {
            return;
        }
        long windowHandle = mc.method_22683().method_4490();
        class_3675.class_306 bound = class_3675.method_15981((String)MusicControlKeybinds.radialMenuKey.method_1428());
        boolean isPressed = false;
        if (bound.method_1442() == class_3675.class_307.field_1672) {
            isPressed = GLFW.glfwGetMouseButton((long)windowHandle, (int)bound.method_1444()) == 1;
        } else if (bound.method_1444() > 0) {
            boolean bl = isPressed = GLFW.glfwGetKey((long)windowHandle, (int)bound.method_1444()) == 1;
        }
        if (!isPressed) {
            this.triggerExit(this.selectedIndex);
        }
    }

    private void triggerExit(int actionIndex) {
        if (this.isExiting) {
            return;
        }
        this.isExiting = true;
        this.exitTimestamp = System.currentTimeMillis();
        this.actionToExecuteOnExit = actionIndex;
        if (actionIndex >= 0) {
            this.selectedIndex = actionIndex;
            HudConfig.INSTANCE.radialLastSelectedIndex = actionIndex;
            HudConfig.save();
            this.playSound((class_6880<class_3414>)class_3417.field_14622, 1.8f, 0.9f);
            this.playSound((class_3414)class_3417.field_15015.comp_349(), 1.4f, 0.7f);
        } else {
            HudConfig.INSTANCE.radialLastSelectedIndex = this.selectedIndex;
            HudConfig.save();
            this.playSound((class_6880<class_3414>)class_3417.field_14624, 0.8f, 0.8f);
        }
    }

    private void executeAction(int index) {
        class_310 mc = class_310.method_1551();
        if (mc == null) {
            return;
        }
        TrackState trackState = this.musicClient != null ? this.musicClient.getState() : null;
        switch (index) {
            case 0: {
                if (this.musicClient == null) break;
                this.musicClient.sendPlayPauseAsync();
                break;
            }
            case 1: {
                if (this.musicClient == null) break;
                this.musicClient.sendNextAsync();
                break;
            }
            case 2: {
                if (trackState == null || !trackState.isActive() || trackState.title().isEmpty()) break;
                boolean isFav = FavoritesManager.INSTANCE.toggleFavorite(trackState, this.coverManager);
                if (mc.field_1705 == null) break;
                String msg = isFav ? "\u00a76[Music Subtitles] \u00a7e\u2605 \u0414\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u043e \u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435: \u00a7f" + trackState.artist() + " - " + trackState.title() : "\u00a76[Music Subtitles] \u00a77\u2606 \u0423\u0434\u0430\u043b\u0435\u043d\u043e \u0438\u0437 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e: \u00a7f" + trackState.artist() + " - " + trackState.title();
                mc.field_1705.method_1758((class_2561)class_2561.method_43470((String)msg), false);
                break;
            }
            case 3: {
                mc.execute(() -> mc.method_1507((class_437)new FavoritesScreen(null)));
                break;
            }
            case 4: {
                mc.execute(() -> mc.method_1507((class_437)new HudEditScreen()));
                break;
            }
            case 5: {
                HudConfig.INSTANCE.enabled = !HudConfig.INSTANCE.enabled;
                HudConfig.save();
                if (mc.field_1705 == null) break;
                String status = HudConfig.INSTANCE.enabled ? "\u00a7a\u0412\u041a\u041b" : "\u00a7c\u0412\u042b\u041a\u041b";
                mc.field_1705.method_1758((class_2561)class_2561.method_43470((String)("\u00a76[Music Subtitles] \u00a7f\u041f\u043b\u0430\u0448\u043a\u0430 HUD: " + status)), false);
                break;
            }
            case 6: {
                String string;
                if (!HudConfig.INSTANCE.subtitlesEnabled) {
                    HudConfig.INSTANCE.subtitlesEnabled = true;
                    HudConfig.INSTANCE.subtitlesMode = "WORLD_3D";
                } else {
                    switch (HudConfig.INSTANCE.subtitlesMode) {
                        case "WORLD_3D": {
                            HudConfig.INSTANCE.subtitlesMode = "WORLD_BLOCK";
                            break;
                        }
                        case "WORLD_BLOCK": {
                            HudConfig.INSTANCE.subtitlesMode = "HUD_BOTTOM";
                            break;
                        }
                        case "HUD_BOTTOM": {
                            HudConfig.INSTANCE.subtitlesMode = "SCREEN_RANDOM";
                            break;
                        }
                        case "SCREEN_RANDOM": {
                            HudConfig.INSTANCE.subtitlesEnabled = false;
                            HudConfig.INSTANCE.subtitlesMode = "WORLD_3D";
                            break;
                        }
                        default: {
                            HudConfig.INSTANCE.subtitlesMode = "WORLD_3D";
                        }
                    }
                }
                HudConfig.save();
                if (mc.field_1705 == null) break;
                if (!HudConfig.INSTANCE.subtitlesEnabled) {
                    string = "\u00a7c\u0412\u042b\u041a\u041b";
                } else {
                    switch (HudConfig.INSTANCE.subtitlesMode) {
                        case "WORLD_3D": {
                            string = "\u00a7a3D \u0432 \u043c\u0438\u0440\u0435";
                            break;
                        }
                        case "WORLD_BLOCK": {
                            string = "\u00a7b3D \u043d\u0430 \u0431\u043b\u043e\u043a\u0430\u0445";
                            break;
                        }
                        case "HUD_BOTTOM": {
                            string = "\u00a7e2D \u0441\u043d\u0438\u0437\u0443";
                            break;
                        }
                        default: {
                            string = "\u00a7d2D \u0441\u043b\u0443\u0447\u0430\u0439\u043d\u043e";
                        }
                    }
                }
                String modeName = string;
                mc.field_1705.method_1758((class_2561)class_2561.method_43470((String)("\u00a76[Music Subtitles] \u00a7f\u0420\u0435\u0436\u0438\u043c \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043e\u0432: " + modeName)), false);
                break;
            }
            case 7: {
                if (this.musicClient == null) break;
                this.musicClient.sendPreviousAsync();
            }
        }
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        float exitAnim;
        this.checkKeyHeld();
        long now = System.currentTimeMillis();
        float openAnim = class_3532.method_15363((float)((float)(now - this.openTimestamp) / 180.0f), (float)0.0f, (float)1.0f);
        float openEase = RadialMenuScreen.easeOutCubic(openAnim);
        float f = exitAnim = this.isExiting ? class_3532.method_15363((float)((float)(now - this.exitTimestamp) / 110.0f), (float)0.0f, (float)1.0f) : 0.0f;
        if (exitAnim >= 1.0f) {
            int toRun = this.actionToExecuteOnExit;
            this.method_25419();
            if (toRun >= 0) {
                this.executeAction(toRun);
            }
            return;
        }
        float alpha = (1.0f - exitAnim) * openEase;
        if (alpha <= 0.01f) {
            return;
        }
        float slideX = (1.0f - openEase) * -90.0f - exitAnim * 90.0f;
        float angleDiff = this.targetAngle - this.currentAngle;
        this.currentAngle += angleDiff * 0.28f;
        TrackState trackState = this.musicClient != null ? this.musicClient.getState() : null;
        boolean hasTrack = trackState != null && trackState.isActive() && !trackState.title().isEmpty();
        long beatInterval = 500L;
        long curPos = hasTrack && trackState.getInterpolatedPositionMs() > 0L ? trackState.getInterpolatedPositionMs() : now - this.openTimestamp;
        float beatCycle = (float)(curPos % beatInterval) / (float)beatInterval;
        float beatEnergy = (float)Math.pow(Math.max(0.0, 1.0 - (double)beatCycle * 1.8), 2.2);
        float centerX = 0.0f + slideX;
        float centerY = (float)this.field_22790 / 2.0f;
        float baseRadius = 80.0f;
        this.renderCenterHub(context, centerX, centerY, alpha, beatEnergy);
        this.renderDialArc(context, centerX, centerY, baseRadius, alpha);
        this.renderSectorPods(context, centerX, centerY, baseRadius, alpha, beatEnergy);
        this.renderActiveTag(context, centerX, centerY, baseRadius, alpha, beatEnergy);
        this.renderBottomHint(context, alpha);
    }

    private void renderCenterHub(class_332 context, float cx, float cy, float alpha, float beatEnergy) {
        int r = (int)(16.0f + beatEnergy * 2.0f);
        int hubAlpha = (int)(alpha * 170.0f);
        MusicHudRenderer.renderRoundedRect(context, (int)(cx - (float)r), (int)(cy - (float)r), r * 2, r * 2, r, hubAlpha << 24 | 0xA0E17);
        MusicHudRenderer.renderRoundedRect(context, (int)(cx - (float)r), (int)(cy - (float)r), r * 2, r * 2, r, (int)(alpha * 130.0f) << 24 | 0xE5FF);
        int dotR = 2;
        int dotCol = (int)(alpha * 230.0f) << 24 | 0xE5FF;
        MusicHudRenderer.renderRoundedRect(context, (int)cx - dotR, (int)cy - dotR, dotR * 2, dotR * 2, dotR, dotCol);
    }

    private void renderDialArc(class_332 context, float cx, float cy, float radius, float alpha) {
        int steps = 28;
        float startAngle = -1.3194689f;
        float endAngle = 1.3194689f;
        int rimCol = (int)(alpha * 65.0f) << 24 | 0xE5FF;
        int subRimCol = (int)(alpha * 30.0f) << 24 | 0xFFFFFF;
        for (int s = 0; s < steps; ++s) {
            float a1 = startAngle + (endAngle - startAngle) * ((float)s / (float)steps);
            float a2 = startAngle + (endAngle - startAngle) * ((float)(s + 1) / (float)steps);
            float x1 = cx + (float)Math.cos(a1) * radius;
            float y1 = cy + (float)Math.sin(a1) * radius;
            float x2 = cx + (float)Math.cos(a2) * radius;
            float y2 = cy + (float)Math.sin(a2) * radius;
            context.method_25294((int)Math.min(x1, x2), (int)Math.min(y1, y2), (int)Math.max(x1, x2) + 2, (int)Math.max(y1, y2) + 2, rimCol);
            float subR = radius - 16.0f;
            float sx1 = cx + (float)Math.cos(a1) * subR;
            float sy1 = cy + (float)Math.sin(a1) * subR;
            float sx2 = cx + (float)Math.cos(a2) * subR;
            float sy2 = cy + (float)Math.sin(a2) * subR;
            context.method_25294((int)Math.min(sx1, sx2), (int)Math.min(sy1, sy2), (int)Math.max(sx1, sx2) + 1, (int)Math.max(sy1, sy2) + 1, subRimCol);
        }
    }

    private void renderSectorPods(class_332 context, float cx, float cy, float radius, float alpha, float beatEnergy) {
        class_327 tr = this.field_22793;
        for (int i = 0; i < 8; ++i) {
            DialItem item = this.items.get(i);
            float sectorAngle = (float)i * 0.7853982f;
            float phi = sectorAngle - this.currentAngle;
            while ((double)phi > Math.PI) {
                phi -= (float)Math.PI * 2;
            }
            while ((double)phi <= -Math.PI) {
                phi += (float)Math.PI * 2;
            }
            if (Math.cos(phi) < -0.2) continue;
            boolean isSelected = i == this.selectedIndex;
            float closeness = Math.max(0.0f, 1.0f - Math.abs(phi) / 1.4137167f);
            float pop = isSelected ? 8.0f + beatEnergy * 2.5f : closeness * 3.0f;
            float r = radius + pop;
            float px = cx + (float)Math.cos(phi) * r;
            float py = cy + (float)Math.sin(phi) * r;
            int size = isSelected ? 28 : 22;
            int half = size / 2;
            int x1 = (int)px - half;
            int y1 = (int)py - half;
            float podAlphaVal = alpha * (isSelected ? 1.0f : class_3532.method_16439((float)closeness, (float)0.45f, (float)0.85f));
            int podAlphaInt = (int)(podAlphaVal * 255.0f);
            if (podAlphaInt <= 4) continue;
            int bgCol = (int)(podAlphaVal * (isSelected ? 230.0f : 160.0f)) << 24 | (isSelected ? 1120808 : 790553);
            int borderCol = podAlphaInt << 24 | (isSelected ? item.color : 3819616);
            if (isSelected) {
                int glowCol = (int)(podAlphaVal * 80.0f) << 24 | item.color & 0xFFFFFF;
                MusicHudRenderer.renderRoundedRect(context, x1 - 2, y1 - 2, size + 4, size + 4, half + 2, glowCol);
            }
            MusicHudRenderer.renderRoundedRect(context, x1, y1, size, size, half, bgCol);
            MusicHudRenderer.renderRoundedRect(context, x1, y1, size, size, half, borderCol);
            int iconCol = podAlphaInt << 24 | (isSelected ? 0xFFFFFF : item.color & 0xFFFFFF);
            int iconY = y1 + (size - 9) / 2;
            context.method_25300(tr, item.icon, (int)px, iconY, iconCol);
        }
    }

    private void renderActiveTag(class_332 context, float cx, float cy, float radius, float alpha, float beatEnergy) {
        DialItem activeItem = this.items.get(this.selectedIndex);
        class_327 tr = this.field_22793;
        float pop = 8.0f + beatEnergy * 2.5f;
        int tagX = (int)(cx + radius + pop + 16.0f);
        int tagH = 28;
        int tagY = (int)(cy - (float)tagH / 2.0f);
        int titleW = tr.method_1727(activeItem.title);
        int descW = tr.method_1727(activeItem.description);
        int contentW = Math.max(titleW, descW);
        int tagW = Math.max(130, Math.min(185, contentW + 18));
        int tagAlphaInt = (int)(alpha * 220.0f);
        int bgCol = tagAlphaInt << 24 | 0xB0F17;
        int borderCol = (int)(alpha * 150.0f) << 24 | activeItem.color;
        MusicHudRenderer.renderRoundedRect(context, tagX - 1, tagY - 1, tagW + 2, tagH + 2, 6, (int)(alpha * 60.0f) << 24 | 0);
        MusicHudRenderer.renderRoundedRect(context, tagX, tagY, tagW, tagH, 5, bgCol);
        MusicHudRenderer.renderRoundedRect(context, tagX, tagY, tagW, tagH, 5, borderCol);
        context.method_25294(tagX, tagY + 3, tagX + 2, tagY + tagH - 3, (int)(alpha * 230.0f) << 24 | activeItem.color);
        int textX = tagX + 8;
        context.method_51433(tr, "\u00a7f\u00a7l" + activeItem.title, textX, tagY + 4, (int)(alpha * 255.0f) << 24 | 0xFFFFFF, true);
        String trimmedDesc = tr.method_27523(activeItem.description, tagW - 14);
        context.method_51433(tr, "\u00a77" + trimmedDesc, textX, tagY + 15, (int)(alpha * 170.0f) << 24 | 0x99AABB, false);
        int arrowX = tagX - 8;
        int arrowCol = (int)(alpha * 220.0f) << 24 | activeItem.color;
        context.method_25294(arrowX, (int)cy - 1, tagX - 2, (int)cy + 1, arrowCol);
    }

    private void renderBottomHint(class_332 context, float alpha) {
        String keyName = MusicControlKeybinds.radialMenuKey.method_16007().getString().toUpperCase();
        String hint = "\u00a78\u041a\u043e\u043b\u0451\u0441\u0438\u043a\u043e \u043c\u044b\u0448\u0438: \u0432\u044b\u0431\u043e\u0440 \u2022 \u041e\u0442\u043f\u0443\u0441\u0442\u0438\u0442\u0435 [\u00a7f" + keyName + "\u00a78] \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f";
        int hx = 10;
        int hy = this.field_22790 - 15;
        context.method_51433(this.field_22793, hint, hx, hy, (int)(alpha * 170.0f) << 24 | 0x8899AA, false);
    }

    private static float easeOutCubic(float t) {
        float f = 1.0f - t;
        return 1.0f - f * f * f;
    }

    public void playSound(class_3414 sound, float pitch, float volume) {
        try {
            class_310.method_1551().method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)sound, (float)pitch, (float)volume));
        }
        catch (Exception exception) {

        }
    }

    public void playSound(class_6880<class_3414> sound, float pitch, float volume) {
        if (sound != null && sound.comp_349() != null) {
            this.playSound((class_3414)sound.comp_349(), pitch, volume);
        }
    }

    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    protected void method_57734(class_332 context) {
    }

    public void method_52752(class_332 context) {
    }

    public void method_25419() {
        HudConfig.INSTANCE.radialLastSelectedIndex = this.selectedIndex;
        HudConfig.save();
        super.method_25419();
    }

    public boolean method_25421() {
        return false;
    }

    private static class DialItem {
        final String icon;
        final String title;
        final String description;
        final int color;

        DialItem(String icon, String title, String description, int color) {
            this.icon = icon;
            this.title = title;
            this.description = description;
            this.color = color;
        }
    }
}

