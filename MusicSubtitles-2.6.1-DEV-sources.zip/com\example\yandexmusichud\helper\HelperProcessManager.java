package com.example.yandexmusichud.helper;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.fabricmc.loader.api.FabricLoader;

public class HelperProcessManager {
    public static HelperProcessManager INSTANCE;
    private static final String HELPER_EXE_NAME = "YandexMusicHelper.exe";
    private static final String PORT_FILE_NAME = "yandexmusichud_port.txt";
    private static final String PID_FILE_NAME = "yandexmusichud_pid.txt";
    private Process helperProcess;
    private int port = -1;
    private boolean started = false;

    private HttpServer linuxServer;
    private ScheduledExecutorService linuxPoller;
    private HttpServer macServer;
    private ScheduledExecutorService macPoller;

    private volatile String cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
    private volatile String lastCoverUrl = null;
    private volatile String cachedCoverBase64 = null;
    private volatile String lastCoverHash = null;

    private volatile List<String> cachedPlayerctlPrefix = null;
    private volatile String cachedNowPlayingCliPath = null;
    private volatile boolean checkedNowPlayingCli = false;

    public HelperProcessManager() {
        INSTANCE = this;
    }

    public static boolean isRunningInFlatpak() {
        return System.getenv("FLATPAK_ID") != null
            || System.getenv("FLATPAK_SANDBOX_DIR") != null
            || Files.exists(Path.of("/.flatpak-info"))
            || (Files.exists(Path.of("/app")) && Files.exists(Path.of("/usr/bin/flatpak-spawn")));
    }

    public int getPort() {
        return this.port;
    }

    public boolean isStarted() {
        return this.started;
    }

    public int start() {
        INSTANCE = this;
        if (this.isHelperAlreadyRunning()) {
            this.port = this.readPortFromTempFile();
            if (this.port > 0) {
                this.started = true;
                return this.port;
            }
        }
        int existingPort = this.readPortFromTempFile();
        if (existingPort > 0) {
            this.port = existingPort;
            this.started = true;
            return this.port;
        }
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("linux")) {
            int linuxPort = this.startLinuxMprisBridge();
            if (linuxPort > 0) {
                this.port = linuxPort;
                this.started = true;
                return this.port;
            }
            return -1;
        }
        if (os.contains("mac")) {
            int macPort = this.startMacOsBridge();
            if (macPort > 0) {
                this.port = macPort;
                this.started = true;
                return this.port;
            }
            return -1;
        }
        if (!os.contains("win")) {
            return -1;
        }
        Path helperDir = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud");
        Path helperExePath = helperDir.resolve(HELPER_EXE_NAME);
        try {
            this.extractHelperIfNeeded(helperExePath);
        }
        catch (IOException e) {
            return -1;
        }
        try {
            ProcessBuilder pb = new ProcessBuilder(helperExePath.toString());
            pb.directory(helperDir.toFile());
            pb.redirectErrorStream(true);
            Path logFile = helperDir.resolve("helper.log");
            pb.redirectOutput(ProcessBuilder.Redirect.to(logFile.toFile()));
            this.helperProcess = pb.start();
            this.port = this.waitForPortFile(10000L);
            if (this.port > 0) {
                this.started = true;
            } else {
                this.stop();
            }
        }
        catch (IOException e) {
            return -1;
        }
        return this.port;
    }

    private List<String> resolvePlayerctlPrefix() {
        if (this.cachedPlayerctlPrefix != null) {
            return this.cachedPlayerctlPrefix;
        }
        List<List<String>> candidates = new ArrayList<>();
        if (isRunningInFlatpak()) {
            candidates.add(List.of("flatpak-spawn", "--host", "playerctl"));
            candidates.add(List.of("playerctl"));
            candidates.add(List.of("flatpak-spawn", "--host", "/usr/bin/playerctl"));
        } else {
            candidates.add(List.of("playerctl"));
            candidates.add(List.of("/usr/bin/playerctl"));
            candidates.add(List.of("/usr/local/bin/playerctl"));
            candidates.add(List.of("flatpak-spawn", "--host", "playerctl"));
        }
        for (List<String> prefix : candidates) {
            try {
                List<String> testCmd = new ArrayList<>(prefix);
                testCmd.add("--version");
                Process p = new ProcessBuilder(testCmd).redirectErrorStream(true).start();
                boolean finished = p.waitFor(350, TimeUnit.MILLISECONDS);
                if (finished && p.exitValue() == 0) {
                    this.cachedPlayerctlPrefix = prefix;
                    return prefix;
                }
                p.destroyForcibly();
            } catch (Exception ignored) {}
        }
        List<String> fallback = isRunningInFlatpak()
            ? List.of("flatpak-spawn", "--host", "playerctl")
            : List.of("playerctl");
        this.cachedPlayerctlPrefix = fallback;
        return fallback;
    }

    private int startLinuxMprisBridge() {
        try {
            int targetPort = 38472;
            try {
                this.linuxServer = HttpServer.create(new InetSocketAddress("127.0.0.1", targetPort), 0);
            } catch (Exception ex) {
                this.linuxServer = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
                targetPort = this.linuxServer.getAddress().getPort();
            }

            this.linuxServer.createContext("/now-playing", exchange -> {
                byte[] resp = this.cachedNowPlayingJson.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, resp.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp);
                }
            });

            this.linuxServer.createContext("/cover", exchange -> {
                String b64 = this.cachedCoverBase64;
                String json = b64 != null && !b64.isEmpty() ? "{\"coverBase64\":\"" + b64 + "\"}" : "{}";
                byte[] resp = json.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, resp.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp);
                }
            });

            this.linuxServer.createContext("/control/play-pause", exchange -> {
                this.runLinuxControl("play-pause");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.linuxServer.createContext("/control/next", exchange -> {
                this.runLinuxControl("next");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.linuxServer.createContext("/control/previous", exchange -> {
                this.runLinuxControl("previous");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.linuxServer.createContext("/shutdown", exchange -> {
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
                this.stop();
            });

            this.linuxServer.setExecutor(Executors.newCachedThreadPool(r -> {
                Thread t = new Thread(r, "MusicSubtitles-LinuxMprisServer");
                t.setDaemon(true);
                return t;
            }));
            this.linuxServer.start();

            this.writePortFiles(targetPort);

            this.linuxPoller = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "MusicSubtitles-LinuxMprisPoller");
                t.setDaemon(true);
                return t;
            });
            this.linuxPoller.scheduleWithFixedDelay(this::pollLinuxMpris, 0, 250, TimeUnit.MILLISECONDS);

            return targetPort;
        } catch (Exception e) {
            return -1;
        }
    }

    private void pollLinuxMpris() {
        try {
            List<String> cmd = new ArrayList<>(this.resolvePlayerctlPrefix());
            cmd.add("metadata");
            cmd.add("--format");
            cmd.add("{{status}}:::{{artist}}:::{{title}}:::{{album}}:::{{position}}:::{{mpris:length}}:::{{mpris:artUrl}}");
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            String output;
            try (InputStream is = p.getInputStream()) {
                output = new String(is.readAllBytes(), StandardCharsets.UTF_8).trim();
            }
            boolean finished = p.waitFor(350, TimeUnit.MILLISECONDS);
            if (!finished) {
                p.destroyForcibly();
                return;
            }
            if (p.exitValue() != 0 || output.isEmpty() || output.startsWith("No player")) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }
            String[] parts = output.split(":::", -1);
            if (parts.length < 3) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }
            String statusRaw = parts[0].trim().toLowerCase();
            String status = statusRaw.equals("playing") ? "playing" : (statusRaw.equals("paused") ? "paused" : "stopped");
            String artist = parts.length > 1 ? parts[1].trim() : "";
            String title = parts.length > 2 ? parts[2].trim() : "";
            String album = parts.length > 3 ? parts[3].trim() : "";
            long posMs = 0L;
            if (parts.length > 4) {
                try {
                    posMs = Math.max(0L, Long.parseLong(parts[4].trim()) / 1000L);
                } catch (Exception ignored) {}
            }
            long durMs = 0L;
            if (parts.length > 5) {
                try {
                    durMs = Math.max(0L, Long.parseLong(parts[5].trim()) / 1000L);
                } catch (Exception ignored) {}
            }
            String artUrl = parts.length > 6 ? parts[6].trim() : "";

            if (title.isEmpty() && artist.isEmpty()) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }

            String coverHash = null;
            if (!artUrl.isEmpty()) {
                coverHash = Integer.toHexString(artUrl.hashCode());
                if (!artUrl.equals(this.lastCoverUrl)) {
                    this.lastCoverUrl = artUrl;
                    this.lastCoverHash = coverHash;
                    this.fetchCoverAsync(artUrl);
                }
            }

            StringBuilder sb = new StringBuilder();
            sb.append("{");
            sb.append("\"isActive\":true,");
            sb.append("\"title\":\"").append(escapeJson(title)).append("\",");
            sb.append("\"artist\":\"").append(escapeJson(artist)).append("\",");
            sb.append("\"album\":\"").append(escapeJson(album)).append("\",");
            sb.append("\"status\":\"").append(status).append("\",");
            sb.append("\"positionMs\":").append(posMs).append(",");
            sb.append("\"durationMs\":").append(durMs).append(",");
            if (coverHash != null) {
                sb.append("\"coverHash\":\"").append(coverHash).append("\",");
            }
            sb.append("\"platform\":\"player\",");
            sb.append("\"platformName\":\"Linux Media\"");
            sb.append("}");

            this.cachedNowPlayingJson = sb.toString();
        } catch (IOException ioEx) {
            this.cachedPlayerctlPrefix = null;
            this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
        } catch (Exception e) {
            this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
        }
    }

    private void runLinuxControl(String action) {
        try {
            List<String> cmd = new ArrayList<>(this.resolvePlayerctlPrefix());
            cmd.add(action);
            new ProcessBuilder(cmd).start();
        } catch (Exception ignored) {}
    }

    private String resolveNowPlayingCli() {
        if (this.checkedNowPlayingCli) {
            return this.cachedNowPlayingCliPath;
        }
        this.checkedNowPlayingCli = true;
        String[] candidates = new String[] {
            "/opt/homebrew/bin/nowplaying-cli",
            "/usr/local/bin/nowplaying-cli",
            "nowplaying-cli"
        };
        for (String c : candidates) {
            try {
                Process p = new ProcessBuilder(c, "--help").start();
                boolean ok = p.waitFor(300, TimeUnit.MILLISECONDS);
                if (ok) {
                    this.cachedNowPlayingCliPath = c;
                    return c;
                }
                p.destroyForcibly();
            } catch (Exception ignored) {}
        }
        return null;
    }

    private int startMacOsBridge() {
        try {
            int targetPort = 38472;
            try {
                this.macServer = HttpServer.create(new InetSocketAddress("127.0.0.1", targetPort), 0);
            } catch (Exception ex) {
                this.macServer = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
                targetPort = this.macServer.getAddress().getPort();
            }

            this.macServer.createContext("/now-playing", exchange -> {
                byte[] resp = this.cachedNowPlayingJson.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, resp.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp);
                }
            });

            this.macServer.createContext("/cover", exchange -> {
                String b64 = this.cachedCoverBase64;
                String json = b64 != null && !b64.isEmpty() ? "{\"coverBase64\":\"" + b64 + "\"}" : "{}";
                byte[] resp = json.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
                exchange.sendResponseHeaders(200, resp.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(resp);
                }
            });

            this.macServer.createContext("/control/play-pause", exchange -> {
                this.runMacControl("playpause");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.macServer.createContext("/control/next", exchange -> {
                this.runMacControl("next");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.macServer.createContext("/control/previous", exchange -> {
                this.runMacControl("previous");
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
            });

            this.macServer.createContext("/shutdown", exchange -> {
                exchange.sendResponseHeaders(200, -1);
                exchange.close();
                this.stop();
            });

            this.macServer.setExecutor(Executors.newCachedThreadPool(r -> {
                Thread t = new Thread(r, "MusicSubtitles-MacOsServer");
                t.setDaemon(true);
                return t;
            }));
            this.macServer.start();

            this.writePortFiles(targetPort);

            this.macPoller = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "MusicSubtitles-MacOsPoller");
                t.setDaemon(true);
                return t;
            });
            this.macPoller.scheduleWithFixedDelay(this::pollMacOsMedia, 0, 300, TimeUnit.MILLISECONDS);

            return targetPort;
        } catch (Exception e) {
            return -1;
        }
    }

    private void pollMacOsMedia() {
        try {
            String cli = this.resolveNowPlayingCli();
            if (cli != null) {
                ProcessBuilder pb = new ProcessBuilder(cli, "get", "title", "artist", "album", "playbackRate", "elapsedTime", "duration");
                pb.redirectErrorStream(true);
                Process p = pb.start();
                String output;
                try (InputStream is = p.getInputStream()) {
                    output = new String(is.readAllBytes(), StandardCharsets.UTF_8).trim();
                }
                boolean finished = p.waitFor(350, TimeUnit.MILLISECONDS);
                if (finished && p.exitValue() == 0 && !output.isEmpty() && !output.contains("null")) {
                    String[] lines = output.split("\\r?\\n");
                    if (lines.length >= 2 && (!lines[0].isBlank() || !lines[1].isBlank())) {
                        String title = lines[0].trim();
                        String artist = lines.length > 1 ? lines[1].trim() : "";
                        String album = lines.length > 2 ? lines[2].trim() : "";
                        double rate = 1.0;
                        if (lines.length > 3) {
                            try {
                                rate = Double.parseDouble(lines[3].trim());
                            } catch (Exception ignored) {}
                        }
                        String status = rate > 0.0 ? "playing" : "paused";
                        long posMs = 0L;
                        if (lines.length > 4) {
                            try {
                                posMs = Math.max(0L, (long)(Double.parseDouble(lines[4].trim()) * 1000.0));
                            } catch (Exception ignored) {}
                        }
                        long durMs = 0L;
                        if (lines.length > 5) {
                            try {
                                durMs = Math.max(0L, (long)(Double.parseDouble(lines[5].trim()) * 1000.0));
                            } catch (Exception ignored) {}
                        }
                        if (!title.isEmpty() || !artist.isEmpty()) {
                            StringBuilder sb = new StringBuilder();
                            sb.append("{");
                            sb.append("\"isActive\":true,");
                            sb.append("\"title\":\"").append(escapeJson(title)).append("\",");
                            sb.append("\"artist\":\"").append(escapeJson(artist)).append("\",");
                            sb.append("\"album\":\"").append(escapeJson(album)).append("\",");
                            sb.append("\"status\":\"").append(status).append("\",");
                            sb.append("\"positionMs\":").append(posMs).append(",");
                            sb.append("\"durationMs\":").append(durMs).append(",");
                            sb.append("\"platform\":\"player\",");
                            sb.append("\"platformName\":\"macOS Media\"");
                            sb.append("}");
                            this.cachedNowPlayingJson = sb.toString();
                            return;
                        }
                    }
                }
            }

            String script = "set out to \"none\"\n"
                + "tell application \"System Events\"\n"
                + "    set isSpotify to (count (every process whose bundle identifier is \"com.spotify.client\")) > 0\n"
                + "    set isMusic to (count (every process whose bundle identifier is \"com.apple.Music\")) > 0\n"
                + "end tell\n"
                + "if isSpotify then\n"
                + "    tell application \"Spotify\"\n"
                + "        set pState to player state as string\n"
                + "        set tArtist to artist of current track\n"
                + "        set tName to name of current track\n"
                + "        set tAlbum to album of current track\n"
                + "        set tPos to player position\n"
                + "        set tDur to (duration of current track) / 1000\n"
                + "        set tArt to \"\"\n"
                + "        try\n"
                + "            set tArt to artwork url of current track\n"
                + "        end try\n"
                + "        set out to \"Spotify:::\" & pState & \":::\" & tArtist & \":::\" & tName & \":::\" & tAlbum & \":::\" & tPos & \":::\" & tDur & \":::\" & tArt\n"
                + "    end tell\n"
                + "else if isMusic then\n"
                + "    tell application \"Music\"\n"
                + "        set pState to player state as string\n"
                + "        set tArtist to artist of current track\n"
                + "        set tName to name of current track\n"
                + "        set tAlbum to album of current track\n"
                + "        set tPos to player position\n"
                + "        set tDur to duration of current track\n"
                + "        set out to \"Apple Music:::\" & pState & \":::\" & tArtist & \":::\" & tName & \":::\" & tAlbum & \":::\" & tPos & \":::\" & tDur & \":::\"\n"
                + "    end tell\n"
                + "end if\n"
                + "return out";

            ProcessBuilder pb = new ProcessBuilder("/usr/bin/osascript", "-e", script);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            String output;
            try (InputStream is = p.getInputStream()) {
                output = new String(is.readAllBytes(), StandardCharsets.UTF_8).trim();
            }
            boolean finished = p.waitFor(400, TimeUnit.MILLISECONDS);
            if (!finished) {
                p.destroyForcibly();
                return;
            }
            if (p.exitValue() != 0 || output.isEmpty() || output.equals("none")) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }
            String[] parts = output.split(":::", -1);
            if (parts.length < 5) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }
            String platformName = parts[0].trim();
            String statusRaw = parts[1].trim().toLowerCase();
            String status = statusRaw.contains("play") ? "playing" : (statusRaw.contains("pause") ? "paused" : "stopped");
            String artist = parts[2].trim();
            String title = parts[3].trim();
            String album = parts[4].trim();
            long posMs = 0L;
            if (parts.length > 5) {
                try {
                    posMs = Math.max(0L, (long)(Double.parseDouble(parts[5].trim()) * 1000.0));
                } catch (Exception ignored) {}
            }
            long durMs = 0L;
            if (parts.length > 6) {
                try {
                    durMs = Math.max(0L, (long)(Double.parseDouble(parts[6].trim()) * 1000.0));
                } catch (Exception ignored) {}
            }
            String artUrl = parts.length > 7 ? parts[7].trim() : "";

            if (title.isEmpty() && artist.isEmpty()) {
                this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
                return;
            }

            String coverHash = null;
            if (!artUrl.isEmpty()) {
                coverHash = Integer.toHexString(artUrl.hashCode());
                if (!artUrl.equals(this.lastCoverUrl)) {
                    this.lastCoverUrl = artUrl;
                    this.lastCoverHash = coverHash;
                    this.fetchCoverAsync(artUrl);
                }
            }

            StringBuilder sb = new StringBuilder();
            sb.append("{");
            sb.append("\"isActive\":true,");
            sb.append("\"title\":\"").append(escapeJson(title)).append("\",");
            sb.append("\"artist\":\"").append(escapeJson(artist)).append("\",");
            sb.append("\"album\":\"").append(escapeJson(album)).append("\",");
            sb.append("\"status\":\"").append(status).append("\",");
            sb.append("\"positionMs\":").append(posMs).append(",");
            sb.append("\"durationMs\":").append(durMs).append(",");
            if (coverHash != null) {
                sb.append("\"coverHash\":\"").append(coverHash).append("\",");
            }
            sb.append("\"platform\":\"player\",");
            sb.append("\"platformName\":\"").append(escapeJson(platformName)).append("\"");
            sb.append("}");

            this.cachedNowPlayingJson = sb.toString();
        } catch (Exception e) {
            this.cachedNowPlayingJson = "{\"isActive\":false,\"status\":\"stopped\"}";
        }
    }

    private void runMacControl(String action) {
        try {
            String cli = this.resolveNowPlayingCli();
            if (cli != null) {
                String cliAction = action.equals("playpause") ? "togglePlayPause" : (action.equals("next") ? "next" : "previous");
                new ProcessBuilder(cli, cliAction).start();
                return;
            }
            String appCmd = action.equals("playpause") ? "playpause" : (action.equals("next") ? "next track" : "previous track");
            String script = "tell application \"System Events\"\n"
                + "    set isSpotify to (count (every process whose bundle identifier is \"com.spotify.client\")) > 0\n"
                + "    set isMusic to (count (every process whose bundle identifier is \"com.apple.Music\")) > 0\n"
                + "end tell\n"
                + "if isSpotify then\n"
                + "    tell application \"Spotify\" to " + appCmd + "\n"
                + "else if isMusic then\n"
                + "    tell application \"Music\" to " + appCmd + "\n"
                + "end if";
            new ProcessBuilder("/usr/bin/osascript", "-e", script).start();
        } catch (Exception ignored) {}
    }

    private void fetchCoverAsync(String artUrl) {
        CompletableFuture.runAsync(() -> {
            try {
                byte[] bytes = null;
                if (artUrl.startsWith("file://")) {
                    Path p = Path.of(URI.create(artUrl));
                    if (Files.exists(p)) {
                        bytes = Files.readAllBytes(p);
                    }
                } else if (artUrl.startsWith("http://") || artUrl.startsWith("https://")) {
                    HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
                    HttpRequest req = HttpRequest.newBuilder().uri(URI.create(artUrl)).timeout(Duration.ofSeconds(4)).GET().build();
                    HttpResponse<byte[]> res = client.send(req, HttpResponse.BodyHandlers.ofByteArray());
                    if (res.statusCode() == 200) {
                        bytes = res.body();
                    }
                }
                if (bytes != null && bytes.length > 0) {
                    this.cachedCoverBase64 = Base64.getEncoder().encodeToString(bytes);
                }
            } catch (Exception ignored) {}
        });
    }

    private static String escapeJson(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); ++i) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < ' ') {
                        String hex = Integer.toHexString(c);
                        sb.append("\\u");
                        sb.append("0".repeat(Math.max(0, 4 - hex.length())));
                        sb.append(hex);
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }

    public void stop() {
        this.started = false;
        if (this.linuxPoller != null) {
            this.linuxPoller.shutdownNow();
            this.linuxPoller = null;
        }
        if (this.linuxServer != null) {
            try {
                this.linuxServer.stop(0);
            } catch (Exception ignored) {}
            this.linuxServer = null;
        }
        if (this.macPoller != null) {
            this.macPoller.shutdownNow();
            this.macPoller = null;
        }
        if (this.macServer != null) {
            try {
                this.macServer.stop(0);
            } catch (Exception ignored) {}
            this.macServer = null;
        }
        try {
            Files.deleteIfExists(this.getTempDir().resolve(PORT_FILE_NAME));
            Files.deleteIfExists(this.getTempDir().resolve(PID_FILE_NAME));
            Path cfgDir = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud");
            Files.deleteIfExists(cfgDir.resolve(PORT_FILE_NAME));
            Files.deleteIfExists(cfgDir.resolve(PID_FILE_NAME));
        } catch (Exception ignored) {}

        if (this.helperProcess != null && this.helperProcess.isAlive()) {
            try {
                HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2L)).build();
                HttpRequest request = HttpRequest.newBuilder().uri(URI.create("http://127.0.0.1:" + this.port + "/shutdown")).POST(HttpRequest.BodyPublishers.noBody()).timeout(Duration.ofSeconds(2L)).build();
                client.send(request, HttpResponse.BodyHandlers.discarding());
                Thread.sleep(1000L);
            }
            catch (Exception ignored) {}
            if (this.helperProcess.isAlive()) {
                this.helperProcess.destroyForcibly();
            }
        }
        this.helperProcess = null;
    }

    private boolean isHelperAlreadyRunning() {
        Path pidFile = this.getTempDir().resolve(PID_FILE_NAME);
        if (!Files.exists(pidFile, new LinkOption[0])) {
            Path cfgPid = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud").resolve(PID_FILE_NAME);
            if (!Files.exists(cfgPid, new LinkOption[0])) {
                return false;
            }
            pidFile = cfgPid;
        }
        try {
            long pid = Long.parseLong(Files.readString(pidFile).trim());
            return ProcessHandle.of(pid).map(ProcessHandle::isAlive).orElse(false);
        }
        catch (Exception e) {
            return false;
        }
    }

    private void writePortFiles(int targetPort) {
        try {
            Path portFile = this.getTempDir().resolve(PORT_FILE_NAME);
            Files.writeString(portFile, String.valueOf(targetPort), StandardCharsets.UTF_8);
            Path pidFile = this.getTempDir().resolve(PID_FILE_NAME);
            Files.writeString(pidFile, String.valueOf(ProcessHandle.current().pid()), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
        try {
            Path cfgDir = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud");
            Files.createDirectories(cfgDir);
            Files.writeString(cfgDir.resolve(PORT_FILE_NAME), String.valueOf(targetPort), StandardCharsets.UTF_8);
            Files.writeString(cfgDir.resolve(PID_FILE_NAME), String.valueOf(ProcessHandle.current().pid()), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private int readPortFromTempFile() {
        try {
            Path cfgPortFile = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud").resolve(PORT_FILE_NAME);
            if (Files.exists(cfgPortFile)) {
                int p = Integer.parseInt(Files.readString(cfgPortFile).trim());
                if (p > 0) {
                    return p;
                }
            }
        } catch (Exception ignored) {}
        Path portFile = this.getTempDir().resolve(PORT_FILE_NAME);
        try {
            if (Files.exists(portFile, new LinkOption[0])) {
                return Integer.parseInt(Files.readString(portFile).trim());
            }
        }
        catch (Exception ignored) {}
        return -1;
    }

    private int waitForPortFile(long timeoutMs) {
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeoutMs) {
            int p = this.readPortFromTempFile();
            if (p > 0) {
                return p;
            }
            try {
                Thread.sleep(200L);
            }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return -1;
            }
            if (this.helperProcess == null || this.helperProcess.isAlive()) continue;
            return -1;
        }
        return -1;
    }

    private void extractHelperIfNeeded(Path targetPath) throws IOException {
        Files.createDirectories(targetPath.getParent(), new FileAttribute[0]);
        try (InputStream in = this.getClass().getResourceAsStream("/helper/YandexMusicHelper.exe");){
            if (in == null) {
                if (!Files.exists(targetPath, new LinkOption[0])) {
                    throw new IOException("Helper exe not found");
                }
                return;
            }
            try {
                Files.copy(in, targetPath, StandardCopyOption.REPLACE_EXISTING);
            }
            catch (IOException copyEx) {
                if (!Files.exists(targetPath, new LinkOption[0])) {
                    throw copyEx;
                }
            }
        }
    }

    private Path getTempDir() {
        String temp = System.getenv("TEMP");
        if (temp == null) {
            temp = System.getProperty("java.io.tmpdir");
        }
        return Path.of(temp, new String[0]);
    }
}
