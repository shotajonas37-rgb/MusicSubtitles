package com.example.yandexmusichud.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

public class HudConfig {
    public static HudConfig INSTANCE = new HudConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("yandexmusichud.json");
    public boolean enabled = true;
    public double hudPositionX = 0.98;
    public double hudPositionY = 0.02;
    public String anchor = "TOP_RIGHT";
    public float hudScale = 1.0f;
    public int hudBackgroundColor = 1710638;
    public float hudBackgroundAlpha = 0.73f;
    public int cornerRadius = 0;
    public boolean showProgressBar = true;
    public int progressBarColor = -13312;
    public int progressBarHeight = 2;
    public String hudDisplayType = "ALWAYS";
    public int popupDurationSeconds = 6;
    public boolean autoAdaptLayout = true;
    public String customBackgroundFile = "";
    public float customBackgroundAlpha = 1.0f;
    public int pollIntervalMs = 300;
    public int hideDelaySeconds = 5;
    public int helperPort = 0;
    public boolean subtitlesEnabled = true;
    public String subtitlesMode = "WORLD_3D";
    public float subtitlesScale = 1.0f;
    public float subtitlesDistance = 4.5f;
    public int subtitlesColor = -1;
    public boolean subtitlesBgEnabled = false;
    public boolean subtitlesSeeThrough = false;
    public int subtitlesBgColor = 0x11111E;
    public float subtitlesBgAlpha = 0.6f;
    public int subtitlesBgRadius = 4;
    public boolean subtitlesTextShadow = true;
    public int subtitlesOffsetMs = 0;
    public boolean subtitlesVisibleInF1 = true;
    public String subtitlesAnimation = "KARAOKE_BOUNCE";
    public int subtitlesActiveColor = -10496;
    public boolean showIntroSplash = true;
    public String hudSize = "LARGE";
    public boolean showEqualizer = true;
    public boolean beatBounce = true;
    public double sub2DPositionX = 0.5;
    public double sub2DPositionY = 0.82;
    public boolean sprintWordsEnabled = true;
    public float sprintWordsDistance = 3.5f;
    public float sprintWordsHeight = 0.0f;
    public float sprintWordsSpread = 0.35f;
    public int sprintWordsChunkSize = 2;
    public int sprintWordsTrailLength = 5;
    public boolean showHelpInspector = true;
    public int radialLastSelectedIndex = 0;
    public boolean smartDuckingEnabled = true;
    public String yandexMusicToken = "";
    public boolean twitchEnabled = false;
    public String twitchChannel = "";
    public boolean twitchShowSubs = true;
    public boolean twitchShowRewards = true;
    public boolean twitchShowBits = true;
    public boolean twitchPlaySound = true;
    public int twitchToastDurationSeconds = 5;
    public String twitchToastPosition = "TOP";
    public boolean twitchAutoCommandEnabled = true;
    public String twitchAutoCommand = "/stream live";
    public boolean daEnabled = true;
    public String daToken = "";
    public boolean daAlertsInHud = true;
    public boolean daSoundEnabled = true;
    public int daMinAmountAlert = 0;
    public boolean hasSeenTutorial = false;
    public Map<String, Integer> trackOffsets = new HashMap<String, Integer>();
    public transient int hudWidth = 260;
    public transient int hudHeight = 74;

    public int getHudBaseWidth() {
        return "LARGE".equalsIgnoreCase(this.hudSize) ? 260 : 200;
    }

    public int getHudBaseHeight() {
        return "LARGE".equalsIgnoreCase(this.hudSize) ? 74 : 56;
    }

    public static void load() {
        if (Files.exists(CONFIG_PATH, new LinkOption[0])) {
            try {
                String json = Files.readString(CONFIG_PATH);
                INSTANCE = (HudConfig)GSON.fromJson(json, HudConfig.class);
                if (INSTANCE == null) {
                    INSTANCE = new HudConfig();
                }
                if (HudConfig.INSTANCE.trackOffsets == null) {
                    HudConfig.INSTANCE.trackOffsets = new HashMap<String, Integer>();
                }
            }
            catch (Exception e) {
                INSTANCE = new HudConfig();
            }
        }
        HudConfig.save();
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent(), new FileAttribute[0]);
            Files.writeString(CONFIG_PATH, (CharSequence)GSON.toJson((Object)INSTANCE), new OpenOption[0]);
        }
        catch (IOException iOException) {

        }
    }

    public int getTrackSyncOffset(String artist, String title) {
        if (this.trackOffsets == null || artist == null || title == null) {
            return 0;
        }
        String key = (artist + "___" + title).toLowerCase();
        return this.trackOffsets.getOrDefault(key, 0);
    }

    public void setTrackSyncOffset(String artist, String title, int offsetMs) {
        if (this.trackOffsets == null) {
            this.trackOffsets = new HashMap<String, Integer>();
        }
        if (artist == null || title == null) {
            return;
        }
        String key = (artist + "___" + title).toLowerCase();
        if (offsetMs == 0) {
            this.trackOffsets.remove(key);
        } else {
            this.trackOffsets.put(key, offsetMs);
        }
        HudConfig.save();
    }


    public int getAbsoluteX(int screenWidth, int widgetWidth) {
        return switch (this.anchor) {
            case "TOP_RIGHT", "BOTTOM_RIGHT" -> (int)((double)screenWidth * this.hudPositionX) - widgetWidth;
            case "TOP_LEFT", "BOTTOM_LEFT" -> (int)((double)screenWidth * this.hudPositionX);
            default -> (int)((double)screenWidth * this.hudPositionX) - widgetWidth / 2;
        };
    }

    public int getAbsoluteY(int screenHeight, int widgetHeight) {
        return switch (this.anchor) {
            case "BOTTOM_LEFT", "BOTTOM_RIGHT" -> (int)((double)screenHeight * this.hudPositionY) - widgetHeight;
            case "TOP_LEFT", "TOP_RIGHT" -> (int)((double)screenHeight * this.hudPositionY);
            default -> (int)((double)screenHeight * this.hudPositionY) - widgetHeight / 2;
        };
    }

    public void setFromAbsolute(int x, int y, int screenWidth, int screenHeight, int widgetWidth, int widgetHeight) {
        int snapThreshold = 15;
        boolean nearLeft = x < snapThreshold;
        boolean nearRight = screenWidth - (x + widgetWidth) < snapThreshold;
        boolean nearTop = y < snapThreshold;
        boolean nearBottom = screenHeight - (y + widgetHeight) < snapThreshold;
        boolean bl = nearBottom;
        if (nearRight && nearTop) {
            this.anchor = "TOP_RIGHT";
            this.hudPositionX = (double)(x + widgetWidth) / (double)screenWidth;
            this.hudPositionY = (double)y / (double)screenHeight;
        } else if (nearLeft && nearTop) {
            this.anchor = "TOP_LEFT";
            this.hudPositionX = (double)x / (double)screenWidth;
            this.hudPositionY = (double)y / (double)screenHeight;
        } else if (nearRight && nearBottom) {
            this.anchor = "BOTTOM_RIGHT";
            this.hudPositionX = (double)(x + widgetWidth) / (double)screenWidth;
            this.hudPositionY = (double)(y + widgetHeight) / (double)screenHeight;
        } else if (nearLeft && nearBottom) {
            this.anchor = "BOTTOM_LEFT";
            this.hudPositionX = (double)x / (double)screenWidth;
            this.hudPositionY = (double)(y + widgetHeight) / (double)screenHeight;
        } else {
            this.anchor = "CUSTOM";
            this.hudPositionX = (double)(x + widgetWidth / 2) / (double)screenWidth;
            this.hudPositionY = (double)(y + widgetHeight / 2) / (double)screenHeight;
        }
    }

    public void resetToDefault() {
        this.hudPositionX = 0.98;
        this.hudPositionY = 0.02;
        this.anchor = "TOP_RIGHT";
        this.hudScale = 1.0f;
        this.hudBackgroundColor = 1710638;
        this.hudBackgroundAlpha = 0.73f;
        this.cornerRadius = 0;
        this.showProgressBar = true;
        this.progressBarColor = -13312;
        this.progressBarHeight = 2;
        this.hudDisplayType = "ALWAYS";
        this.popupDurationSeconds = 6;
        this.autoAdaptLayout = true;
        this.customBackgroundFile = "";
        this.customBackgroundAlpha = 1.0f;
        this.pollIntervalMs = 300;
        this.subtitlesEnabled = true;
        this.subtitlesMode = "WORLD_3D";
        this.subtitlesScale = 1.0f;
        this.subtitlesDistance = 4.5f;
        this.subtitlesColor = -1;
        this.subtitlesBgEnabled = false;
        this.subtitlesSeeThrough = false;
        this.subtitlesBgColor = 0x11111E;
        this.subtitlesBgAlpha = 0.6f;
        this.subtitlesBgRadius = 4;
        this.subtitlesTextShadow = true;
        this.subtitlesOffsetMs = 0;
        this.hudSize = "LARGE";
        this.showEqualizer = true;
        this.beatBounce = true;
        this.sub2DPositionX = 0.5;
        this.sub2DPositionY = 0.82;
        this.sprintWordsEnabled = true;
        this.sprintWordsDistance = 3.5f;
        this.sprintWordsHeight = 0.0f;
        this.sprintWordsSpread = 0.35f;
        this.sprintWordsChunkSize = 2;
        this.sprintWordsTrailLength = 5;
        this.radialLastSelectedIndex = 0;
        this.smartDuckingEnabled = true;
        this.twitchEnabled = false;
        this.twitchChannel = "";
        this.twitchShowSubs = true;
        this.twitchShowRewards = true;
        this.twitchShowBits = true;
        this.twitchPlaySound = true;
        this.twitchToastDurationSeconds = 5;
        this.twitchToastPosition = "TOP";
        this.daEnabled = true;
        this.daToken = "";
        this.daAlertsInHud = true;
        this.daSoundEnabled = true;
        this.daMinAmountAlert = 0;
    }
}

