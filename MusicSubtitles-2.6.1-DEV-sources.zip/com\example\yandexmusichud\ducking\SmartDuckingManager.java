package com.example.yandexmusichud.ducking;

import com.example.yandexmusichud.config.HudConfig;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

public class SmartDuckingManager {
    public static final SmartDuckingManager INSTANCE = new SmartDuckingManager();
    private boolean voiceChatAvailable = false;
    private Method getClientMethod;
    private Method getTalkCacheMethod;
    private Method getMicThreadMethod;
    private Method isMicTalkingMethod;
    private Field playerCacheField;
    private Field lastTalkField;
    private boolean duckingActive = false;
    private float currentDuckingFactor = 1.0f;
    private long lastVoiceActivityTime = 0L;

    private SmartDuckingManager() {
        this.initVoiceChatReflection();
    }

    private void initVoiceChatReflection() {
        if (!FabricLoader.getInstance().isModLoaded("voicechat")) {
            return;
        }
        try {
            Class<?> clientManagerClass = Class.forName("de.maxhenkel.voicechat.voice.client.ClientManager");
            this.getClientMethod = clientManagerClass.getMethod("getClient", new Class[0]);
            Class<?> clientVoicechatClass = Class.forName("de.maxhenkel.voicechat.voice.client.ClientVoicechat");
            this.getTalkCacheMethod = clientVoicechatClass.getMethod("getTalkCache", new Class[0]);
            this.getMicThreadMethod = clientVoicechatClass.getMethod("getMicThread", new Class[0]);
            Class<?> micThreadClass = Class.forName("de.maxhenkel.voicechat.voice.client.MicThread");
            this.isMicTalkingMethod = micThreadClass.getMethod("isTalking", new Class[0]);
            Class<?> talkCacheClass = Class.forName("de.maxhenkel.voicechat.voice.client.TalkCache");
            this.playerCacheField = talkCacheClass.getDeclaredField("playerCache");
            this.playerCacheField.setAccessible(true);
            Class<?> playerCacheClass = Class.forName("de.maxhenkel.voicechat.voice.client.TalkCache$PlayerCache");
            this.lastTalkField = playerCacheClass.getDeclaredField("lastTalk");
            this.lastTalkField.setAccessible(true);
            this.voiceChatAvailable = true;
        }
        catch (Throwable ignored) {
            this.voiceChatAvailable = false;
        }
    }

    public void onTick() {
        boolean shouldDuck;
        if (!HudConfig.INSTANCE.smartDuckingEnabled || !this.voiceChatAvailable) {
            this.duckingActive = false;
            this.currentDuckingFactor = 1.0f;
            return;
        }
        boolean voiceTalking = this.checkVoiceChatTalking();
        long now = System.currentTimeMillis();
        if (voiceTalking) {
            this.lastVoiceActivityTime = now;
        }
        this.duckingActive = shouldDuck = now - this.lastVoiceActivityTime < 800L;
        float target = shouldDuck ? 0.35f : 1.0f;
        this.currentDuckingFactor += (target - this.currentDuckingFactor) * 0.2f;
        if (Math.abs(this.currentDuckingFactor - target) < 0.01f) {
            this.currentDuckingFactor = target;
        }
    }

    private boolean checkVoiceChatTalking() {
        try {
            Object cacheObj;
            Object talkCache;
            Boolean isTalking;
            Object micThread;
            if (this.getClientMethod == null) {
                return false;
            }
            Object client = this.getClientMethod.invoke(null, new Object[0]);
            if (client == null) {
                return false;
            }
            if (this.getMicThreadMethod != null && this.isMicTalkingMethod != null && (micThread = this.getMicThreadMethod.invoke(client, new Object[0])) != null && Boolean.TRUE.equals(isTalking = (Boolean)this.isMicTalkingMethod.invoke(micThread, new Object[0]))) {
                return true;
            }
            if (this.getTalkCacheMethod != null && this.playerCacheField != null && this.lastTalkField != null && (talkCache = this.getTalkCacheMethod.invoke(client, new Object[0])) != null && (cacheObj = this.playerCacheField.get(talkCache)) instanceof Map) {
                Map map = (Map)cacheObj;
                long now = System.currentTimeMillis();
                for (Object playerCache : map.values()) {
                    long lastTalk;
                    if (playerCache == null || now - (lastTalk = this.lastTalkField.getLong(playerCache)) >= 500L) continue;
                    return true;
                }
            }
        }
        catch (Throwable throwable) {

        }
        return false;
    }

    public boolean isDuckingActive() {
        return this.duckingActive;
    }

    public float getCurrentDuckingFactor() {
        return this.currentDuckingFactor;
    }

    public boolean isVoiceChatAvailable() {
        return this.voiceChatAvailable;
    }
}

