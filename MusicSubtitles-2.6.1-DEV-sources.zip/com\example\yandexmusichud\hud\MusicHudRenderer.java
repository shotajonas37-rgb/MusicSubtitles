package com.example.yandexmusichud.hud;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.donationalerts.DonationAlertBanner;
import com.example.yandexmusichud.donationalerts.DonationAlertQueue;
import com.example.yandexmusichud.favorites.FavoritesManager;
import com.example.yandexmusichud.network.NowPlayingClient;
import com.example.yandexmusichud.network.TrackState;
import com.example.yandexmusichud.texture.CoverTextureManager;
import com.example.yandexmusichud.texture.CustomBackgroundManager;
import com.example.yandexmusichud.twitch.TwitchAlertBanner;
import com.example.yandexmusichud.twitch.TwitchAlertQueue;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9779;


public class MusicHudRenderer {
    private final NowPlayingClient client;
    private final CoverTextureManager coverManager;
    private static final int BASE_COVER_SIZE = 40;
    private static final int BASE_PADDING = 6;
    private static final int BASE_HUD_WIDTH = 200;
    private static final int BASE_HUD_HEIGHT = 56;
    private static final int BASE_TEXT_AREA_WIDTH = 142;
    private static final int TITLE_COLOR = -1;
    private static final int ARTIST_COLOR = -5592406;
    private static final int PROGRESS_BG_COLOR = 0x77333344;
    private static final int PLAY_ICON_COLOR = -13312;
    private static final class_2960 TWITCH_ICON = class_2960.method_60655("yandexmusichud", "textures/gui/twitch_icon.png");
    private float currentAlpha = 0.0f;
    private float currentSlide = 0.0f;
    private long lastActiveTime = 0L;
    private long marqueeStartTime = 0L;
    private long popupStartTime = 0L;
    private String lastTitle = "";
    private String lastArtist = "";
    private boolean lastWasPlaying = false;
    private int cachedX;
    private int cachedY;


    public MusicHudRenderer(NowPlayingClient client, CoverTextureManager coverManager) {
        this.client = client;
        this.coverManager = coverManager;
    }


    public void render(class_332 context, class_9779 tickCounter) {
        float targetSlide;
        float targetAlpha;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1690.field_1842) {
            return;
        }
        com.example.yandexmusichud.twitch.TwitchAlertQueue.INSTANCE.update();
        com.example.yandexmusichud.donationalerts.DonationAlertQueue.INSTANCE.update();
        boolean hasTwitchAlert = com.example.yandexmusichud.twitch.TwitchAlertQueue.INSTANCE.isShowing();
        boolean hasDaAlert = com.example.yandexmusichud.donationalerts.DonationAlertQueue.INSTANCE.isShowing();

        int screenWidth = mc.method_22683().method_4486();
        int screenHeight = mc.method_22683().method_4502();
        long now = System.currentTimeMillis();

        if (hasTwitchAlert) {
            com.example.yandexmusichud.twitch.TwitchAlertBanner.INSTANCE.render(context, screenWidth, screenHeight, now);
        }
        if (hasDaAlert) {
            com.example.yandexmusichud.donationalerts.DonationAlertBanner.INSTANCE.render(context, screenWidth, screenHeight, now);
        }

        if (!HudConfig.INSTANCE.enabled) {
            return;
        }
        CustomBackgroundManager.INSTANCE.checkBackgroundsThrottled();
        TrackState state = this.client.getState();
        boolean isNewTrack = !state.title().equals(this.lastTitle) || !state.artist().equals(this.lastArtist);
        boolean justStarted = !this.lastWasPlaying && state.isPlaying();
        boolean bl = justStarted;
        if (state.isActive() && (isNewTrack || justStarted)) {
            this.popupStartTime = now;
        }
        this.lastWasPlaying = state.isPlaying();
        boolean isPopupMode = "POPUP".equalsIgnoreCase(HudConfig.INSTANCE.hudDisplayType);
        if (state.isActive() && state.isPlaying()) {
            this.lastActiveTime = now;
            if (isPopupMode) {
                long popupAge = now - this.popupStartTime;
                long maxPopupDuration = (long)HudConfig.INSTANCE.popupDurationSeconds * 1000L;
                if (popupAge < maxPopupDuration) {
                    targetAlpha = 1.0f;
                    targetSlide = 1.0f;
                } else if (popupAge < maxPopupDuration + 800L) {
                    targetAlpha = 0.0f;
                    targetSlide = 0.0f;
                } else {
                    targetAlpha = 0.0f;
                    targetSlide = 0.0f;
                }
            } else {
                targetAlpha = 1.0f;
                targetSlide = 1.0f;
            }
        } else if (state.isActive() && state.isPaused()) {
            long pausedFor = now - this.lastActiveTime;
            if (pausedFor < (long)HudConfig.INSTANCE.hideDelaySeconds * 1000L) {
                targetAlpha = 0.7f;
                targetSlide = 1.0f;
            } else {
                targetAlpha = 0.0f;
                targetSlide = 0.0f;
            }
        } else {
            long inactiveFor = now - this.lastActiveTime;
            if (this.lastActiveTime > 0L && inactiveFor < 1500L) {
                targetAlpha = 0.3f;
                targetSlide = 1.0f;
            } else {
                targetAlpha = 0.0f;
                targetSlide = 0.0f;
            }
        }
        if (hasTwitchAlert) {
            targetAlpha = 1.0f;
            targetSlide = 1.0f;
            if (this.currentAlpha < 0.25f) {
                this.currentAlpha = 0.25f;
            }
            if (this.currentSlide < 0.25f) {
                this.currentSlide = 0.25f;
            }
        }
        float lerpSpeed = hasTwitchAlert ? 0.16f : 0.08f;
        this.currentAlpha = class_3532.method_16439((float)lerpSpeed, (float)this.currentAlpha, (float)targetAlpha);
        this.currentSlide = class_3532.method_16439((float)lerpSpeed, (float)this.currentSlide, (float)targetSlide);
        if (this.currentAlpha < 0.01f && this.currentSlide < 0.01f && !hasTwitchAlert) {
            return;
        }
        int baseW = HudConfig.INSTANCE.getHudBaseWidth();
        int baseH = HudConfig.INSTANCE.getHudBaseHeight();
        float scale = class_3532.method_15363((float)HudConfig.INSTANCE.hudScale, (float)0.2f, (float)4.0f);
        int scaledWidth = (int)((float)baseW * scale);
        int scaledHeight = (int)((float)baseH * scale);
        int baseX = HudConfig.INSTANCE.getAbsoluteX(screenWidth, scaledWidth);
        int baseY = HudConfig.INSTANCE.getAbsoluteY(screenHeight, scaledHeight);
        baseX = class_3532.method_15340((int)baseX, (int)0, (int)Math.max(0, screenWidth - scaledWidth));
        baseY = class_3532.method_15340((int)baseY, (int)0, (int)Math.max(0, screenHeight - scaledHeight));
        float slideOffsetX = 0.0f;
        float slideOffsetY = 0.0f;
        if (isPopupMode) {
            float hiddenFraction = Math.max(0.0f, 1.0f - this.currentSlide);
            int distToLeft = baseX;
            int distToRight = screenWidth - (baseX + scaledWidth);
            int distToTop = baseY;
            int distToBottom = screenHeight - (baseY + scaledHeight);
            int minDist = Math.min(Math.min(distToLeft, distToRight), Math.min(distToTop, distToBottom));
            if (minDist < 60) {
                if (minDist == distToRight) {
                    slideOffsetX = (float)(scaledWidth + 20) * hiddenFraction;
                } else if (minDist == distToLeft) {
                    slideOffsetX = (float)(-(scaledWidth + 20)) * hiddenFraction;
                } else {
                    slideOffsetY = minDist == distToTop ? (float)(-(scaledHeight + 20)) * hiddenFraction : (float)(scaledHeight + 20) * hiddenFraction;
                }
            }
        }
        float beatBounce = 0.0f;
        if (HudConfig.INSTANCE.beatBounce && state.isActive() && state.isPlaying()) {
            long trackPos = state.getInterpolatedPositionMs();
            float beatCycle = (float)(trackPos % 500L) / 500.0f;
            beatBounce = (float)Math.pow(Math.max(0.0, 1.0 - (double)beatCycle * 1.8), 2.2) * 3.2f;
        }
        int finalX = Math.round((float)baseX + slideOffsetX);
        int finalY = Math.round((float)baseY + slideOffsetY - beatBounce * scale);
        this.cachedX = finalX;
        this.cachedY = finalY;
        HudConfig.INSTANCE.hudWidth = scaledWidth;
        HudConfig.INSTANCE.hudHeight = scaledHeight;
        context.method_51448().pushMatrix();
        context.method_51448().translate((float)finalX, (float)finalY);
        context.method_51448().scale(scale, scale);
        int alpha = (int)(this.currentAlpha * 255.0f);
        this.renderBackground(context, alpha, baseW, baseH);
        if (state.isActive()) {
            boolean mirrorLayout = HudConfig.INSTANCE.autoAdaptLayout && baseX < screenWidth / 2;
            this.renderContent(context, state, mc, alpha, now, mirrorLayout, baseW, baseH, beatBounce);
        } else if (hasTwitchAlert) {
            this.renderStandbyContent(context, mc, alpha, baseW, baseH);
        }
        context.method_51448().popMatrix();
    }

    private void renderStandbyContent(class_332 context, class_310 mc, int alpha, int baseW, int baseH) {
        class_327 tr = mc.field_1772;
        int iconSize = 24;
        int iconX = 10;
        int iconY = (baseH - iconSize) / 2;
        try {
            context.method_25290(class_10799.field_56883, TWITCH_ICON, iconX, iconY, 0.0f, 0.0f, iconSize, iconSize, iconSize, iconSize);
        } catch (Throwable ignored) {}
        int textX = iconX + iconSize + 8;
        String title = "\u00a7d\u00a7lTwitch Live";
        String sub = "\u00a77\u0418\u043d\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044f \u0430\u043a\u0442\u0438\u0432\u043d\u0430";
        context.method_51433(tr, title, textX, baseH / 2 - 9, alpha << 24 | 0xFFFFFF, true);
        context.method_51433(tr, sub, textX, baseH / 2 + 2, (int)((float)alpha * 0.8f) << 24 | 0xCCCCCC, false);
    }

    private void renderBackground(class_332 context, int alpha, int baseW, int baseH) {
        class_2960 customBg = CustomBackgroundManager.INSTANCE.getBackgroundTexture();
        int r = class_3532.method_15340((int)HudConfig.INSTANCE.cornerRadius, (int)0, (int)20);
        int domColor = this.coverManager.getDominantColor() & 0xFFFFFF;
        if (customBg != null) {
            float bgAlpha = class_3532.method_15363((float)HudConfig.INSTANCE.customBackgroundAlpha, (float)0.0f, (float)1.0f) * ((float)alpha / 255.0f);
            int bgAlphaInt = (int)(bgAlpha * 255.0f);
            if (bgAlphaInt > 2) {
                if (bgAlphaInt > 20) {
                    int auraR = Math.min(24, r + 4);
                    int auraColorOuter = (int)(bgAlpha * 22.0f) << 24 | domColor;
                    int auraColorInner = (int)(bgAlpha * 48.0f) << 24 | domColor;
                    MusicHudRenderer.renderRoundedRect(context, -4, -4, baseW + 8, baseH + 8, auraR, auraColorOuter);
                    MusicHudRenderer.renderRoundedRect(context, -2, -2, baseW + 4, baseH + 4, r + 2, auraColorInner);
                }
                context.method_25290(class_10799.field_56883, customBg, 0, 0, 0.0f, 0.0f, baseW, baseH, baseW, baseH);
                int shineColor = (int)(bgAlpha * 75.0f) << 24 | 0xFFFFFF;
                int shadowColor = (int)(bgAlpha * 85.0f) << 24 | 0;
                MusicHudRenderer.renderRoundedBorder(context, 0, 0, baseW, baseH, r, shineColor, shadowColor);
            }
        } else {
            float bgAlpha = class_3532.method_15363((float)HudConfig.INSTANCE.hudBackgroundAlpha, (float)0.0f, (float)1.0f) * ((float)alpha / 255.0f);
            int bgAlphaInt = (int)(bgAlpha * 255.0f);
            if (bgAlphaInt > 20) {
                int auraR = Math.min(24, r + 4);
                int auraColorOuter = (int)(bgAlpha * 22.0f) << 24 | domColor;
                int auraColorInner = (int)(bgAlpha * 48.0f) << 24 | domColor;
                MusicHudRenderer.renderRoundedRect(context, -4, -4, baseW + 8, baseH + 8, auraR, auraColorOuter);
                MusicHudRenderer.renderRoundedRect(context, -2, -2, baseW + 4, baseH + 4, r + 2, auraColorInner);
            }
            int baseRgb = HudConfig.INSTANCE.hudBackgroundColor & 0xFFFFFF;
            int finalColor = bgAlphaInt << 24 | baseRgb;
            MusicHudRenderer.renderRoundedRect(context, 0, 0, baseW, baseH, r, finalColor);
            int glassWash = (int)(bgAlpha * 38.0f) << 24 | domColor;
            MusicHudRenderer.renderRoundedRect(context, 0, 0, baseW, baseH, r, glassWash);
            int shineColor = (int)(bgAlpha * 75.0f) << 24 | 0xFFFFFF;
            int shadowColor = (int)(bgAlpha * 85.0f) << 24 | 0;
            if (r > 0) {
                context.method_25294(r, 0, baseW - r, 1, shineColor);
                context.method_25294(0, r, 1, baseH - r, shineColor);
                context.method_25294(r, baseH - 1, baseW - r, baseH, shadowColor);
                context.method_25294(baseW - 1, r, baseW, baseH - r, shadowColor);
            } else {
                context.method_25294(0, 0, baseW, 1, shineColor);
                context.method_25294(0, 0, 1, baseH, shineColor);
                context.method_25294(0, baseH - 1, baseW, baseH, shadowColor);
                context.method_25294(baseW - 1, 0, baseW, baseH, shadowColor);
            }
        }
    }

    public static void renderRoundedRect(class_332 context, int x, int y, int width, int height, int radius, int argbColor) {
        int a = argbColor >> 24 & 0xFF;
        if (a == 0) {
            return;
        }
        if (radius <= 0) {
            context.method_25294(x, y, x + width, y + height, argbColor);
            return;
        }
        radius = Math.min(radius, Math.min(width / 2, height / 2));
        context.method_25294(x, y + radius, x + width, y + height - radius, argbColor);
        for (int i = 0; i < radius; ++i) {
            double dy = (double)radius - (double)i - 0.5;
            int dx = (int)Math.round((double)radius - Math.sqrt(Math.max(0.0, (double)(radius * radius) - dy * dy)));
            context.method_25294(x + dx, y + i, x + width - dx, y + i + 1, argbColor);
            context.method_25294(x + dx, y + height - 1 - i, x + width - dx, y + height - i, argbColor);
        }
    }

    public static void renderRoundedBorder(class_332 context, int x, int y, int width, int height, int radius, int topShine, int bottomDark) {
        if (radius <= 0) {
            context.method_25294(x, y, x + width, y + 1, topShine);
            context.method_25294(x, y, x + 1, y + height, topShine);
            context.method_25294(x, y + height - 1, x + width, y + height, bottomDark);
            context.method_25294(x + width - 1, y, x + width, y + height, bottomDark);
            return;
        }
        context.method_25294(x + radius, y, x + width - radius, y + 1, topShine);
        context.method_25294(x, y + radius, x + 1, y + height - radius, topShine);
        context.method_25294(x + radius, y + height - 1, x + width - radius, y + height, bottomDark);
        context.method_25294(x + width - 1, y + radius, x + width, y + height - radius, bottomDark);
    }

    public static void renderBottomRoundedRect(class_332 context, int x, int y, int width, int height, int radius, int argbColor) {
        int a = argbColor >> 24 & 0xFF;
        if (a == 0 || height <= 0 || width <= 0) {
            return;
        }
        if (radius <= 0) {
            context.method_25294(x, y, x + width, y + height, argbColor);
            return;
        }
        radius = Math.min(radius, Math.min(width / 2, height));
        if (height > radius) {
            context.method_25294(x, y, x + width, y + height - radius, argbColor);
        }
        for (int i = 0; i < radius; ++i) {
            double dy = (double)radius - (double)i - 0.5;
            int dx = (int)Math.round((double)radius - Math.sqrt(Math.max(0.0, (double)(radius * radius) - dy * dy)));
            int lineY = y + height - radius + i;
            if (lineY >= y && lineY < y + height) {
                context.method_25294(x + dx, lineY, x + width - dx, lineY + 1, argbColor);
            }
        }
    }

    public static void renderBottomRoundedBorder(class_332 context, int x, int y, int width, int height, int radius, int sideShine, int bottomDark) {
        if (height <= 0 || width <= 0) {
            return;
        }
        if (radius <= 0) {
            context.method_25294(x, y, x + 1, y + height, sideShine);
            context.method_25294(x + width - 1, y, x + width, y + height, bottomDark);
            context.method_25294(x, y + height - 1, x + width, y + height, bottomDark);
            return;
        }
        radius = Math.min(radius, Math.min(width / 2, height));
        if (height > radius) {
            context.method_25294(x, y, x + 1, y + height - radius, sideShine);
            context.method_25294(x + width - 1, y, x + width, y + height - radius, bottomDark);
        }
        for (int i = 0; i < radius; ++i) {
            double dy = (double)radius - (double)i - 0.5;
            int dx = (int)Math.round((double)radius - Math.sqrt(Math.max(0.0, (double)(radius * radius) - dy * dy)));
            int lineY = y + height - radius + i;
            if (lineY >= y && lineY < y + height) {
                context.method_25294(x + dx, lineY, x + dx + 1, lineY + 1, sideShine);
                context.method_25294(x + width - dx - 1, lineY, x + width - dx, lineY + 1, bottomDark);
            }
        }
        context.method_25294(x + radius, y + height - 1, x + width - radius, y + height, bottomDark);
    }

    private void renderContent(class_332 context, TrackState state, class_310 mc, int alpha, long now, boolean mirrorLayout, int baseW, int baseH, float beatBounce) {
        int finalPColor;
        int pColor;
        String pSym;
        float py;
        float px;
        int pAlpha;
        float pAlphaNorm;
        float pNorm;
        float pCycle;
        int pIdx;
        class_327 textRenderer = mc.field_1772;
        int domColor = this.coverManager.getDominantColor() & 0xFFFFFF;
        int r = class_3532.method_15340((int)HudConfig.INSTANCE.cornerRadius, (int)0, (int)20);
        boolean isLarge = "LARGE".equalsIgnoreCase(HudConfig.INSTANCE.hudSize);
        int coverSize = isLarge ? 52 : 40;
        int coverMargin = Math.max(8, r - 1);
        int coverX = mirrorLayout ? baseW - coverSize - coverMargin : coverMargin;
        int coverY = (baseH - coverSize) / 2 - 2;
        int coverRadius = isLarge ? 6 : 5;
        class_2960 coverId = this.coverManager.getCurrentCoverId();
        if (isLarge) {
            int vinylX = mirrorLayout ? coverX - 8 : coverX + 8;
            int vinylR = (coverSize - 10) / 2;
            MusicHudRenderer.renderRoundedRect(context, vinylX, coverY + 5, coverSize - 10, coverSize - 10, vinylR, (int)((float)alpha * 0.35f) << 24 | 0x151520);
            MusicHudRenderer.renderRoundedRect(context, vinylX + vinylR - 3, coverY + 5 + vinylR - 3, 6, 6, 3, (int)((float)alpha * 0.7f) << 24 | (domColor != 0 ? domColor : 58879));
        }
        MusicHudRenderer.renderRoundedRect(context, coverX + 1, coverY + 2, coverSize, coverSize, coverRadius, (int)((float)alpha * 0.4f) << 24 | 0);
        MusicHudRenderer.renderRoundedRect(context, coverX - 1, coverY - 1, coverSize + 2, coverSize + 2, coverRadius + 1, (int)((float)alpha * 0.22f) << 24 | domColor);
        context.method_25290(class_10799.field_56883, coverId, coverX, coverY, 0.0f, 0.0f, coverSize, coverSize, coverSize, coverSize);
        int coverShine = (int)((float)alpha * 0.38f) << 24 | 0xFFFFFF;
        int coverDark = (int)((float)alpha * 0.48f) << 24 | 0;
        MusicHudRenderer.renderRoundedBorder(context, coverX, coverY, coverSize, coverSize, coverRadius, coverShine, coverDark);
        if (state.isPlaying()) {
            for (pIdx = 0; pIdx < 6; ++pIdx) {
                pCycle = 2200.0f + (float)pIdx * 450.0f;
                pNorm = (float)((now + (long)pIdx * 650L) % (long)pCycle) / pCycle;
                pAlphaNorm = (float)Math.sin((double)pNorm * Math.PI);
                pAlpha = (int)(pAlphaNorm * ((float)alpha / 255.0f) * 190.0f);
                if (pAlpha <= 10) continue;
                px = (float)coverX + (float)coverSize * 0.5f + (float)Math.sin((double)pIdx * 1.8 + (double)now * 0.0012) * ((float)coverSize * 0.65f);
                py = (float)coverY + (float)coverSize * 0.5f - pNorm * 28.0f - (beatBounce > 1.0f ? 4.0f : 0.0f);
                pSym = pIdx % 3 == 0 ? "\u266a" : (pIdx % 3 == 1 ? "\u266b" : (pIdx % 2 == 0 ? "\u2726" : "\u2727"));
                pColor = pIdx % 2 == 0 ? (domColor != 0 ? domColor : 58879) : 16766720;
                finalPColor = pAlpha << 24 | pColor & 0xFFFFFF;
                context.method_51433(textRenderer, pSym, (int)px, (int)py, finalPColor, false);
            }
        }
        int textX = mirrorLayout ? coverMargin : coverX + coverSize + 10;
        int textY = isLarge ? 8 : 8;
        int maxTextWidth = baseW - (coverMargin * 2 + coverSize + 10);
        String title = state.title();
        String artist = state.artist();
        if (!title.equals(this.lastTitle) || !artist.equals(this.lastArtist)) {
            this.lastTitle = title;
            this.lastArtist = artist;
            this.marqueeStartTime = now + 2000L;
        }
        int titleColor = alpha << 24 | 0xFFFFFF;
        int artistColor = alpha << 24 | 0xBBBBCC;
        this.renderMarqueeText(context, textRenderer, title, textX, textY, maxTextWidth, titleColor, now, true);
        this.renderMarqueeText(context, textRenderer, artist, textX, textY + (isLarge ? 13 : 12), maxTextWidth, artistColor, now, false);
        boolean isFav = FavoritesManager.INSTANCE.isFavorite(state.artist(), state.title());
        String starIcon = isFav ? "\u2605" : "\u2606";
        int starColor = isFav ? alpha << 24 | 0xFFD700 : (int)((float)alpha * 0.7f) << 24 | 0xFFFFFF;
        String timeText = this.formatTime(state.getInterpolatedPositionMs()) + " / " + this.formatTime(state.durationMs());
        int timeColor = alpha << 24 | 0x9999AA;
        int timeWidth = textRenderer.method_1727(timeText);
        String platformStr = state.platformName() != null && !state.platformName().isEmpty() ? state.platformName() : "\u041c\u0443\u0437\u044b\u043a\u0430";
        int platColor = MusicHudRenderer.getPlatformColor(state.platform());
        if (isLarge && HudConfig.INSTANCE.showEqualizer) {
            int eqY = textY + 26;
            int eqHeight = 13;
            int numBars = 12;
            int barW = 3;
            int barGap = 2;
            int totalEqW = numBars * (barW + barGap) - barGap;
            int eqX = textX;
            for (int b = 0; b < numBars; ++b) {
                float hNorm;
                float freq = 0.007f + (float)b * 0.0022f;
                float phase = (float)b * 0.65f;
                if (state.isPlaying()) {
                    double s = Math.sin((double)now * (double)freq + (double)phase) * 0.45 + Math.cos((double)now * ((double)freq * 0.7) - (double)phase) * 0.35 + 0.55;
                    hNorm = (float)Math.max(0.12, Math.min(1.0, s));
                    if (b < 4) {
                        hNorm = Math.min(1.0f, hNorm + beatBounce / 3.2f * 0.45f);
                    }
                } else {
                    hNorm = 0.12f;
                }
                int barH = Math.max(2, (int)(hNorm * (float)eqHeight));
                int bx = eqX + b * (barW + barGap);
                int by = eqY + eqHeight - barH;
                float ratio = (float)b / (float)(numBars - 1);
                int barR = class_3532.method_48781((float)ratio, (int)(domColor >> 16 & 0xFF), (int)0);
                int barG = class_3532.method_48781((float)ratio, (int)(domColor >> 8 & 0xFF), (int)229);
                int barB = class_3532.method_48781((float)ratio, (int)(domColor & 0xFF), (int)255);
                if (domColor == 0) {
                    barR = 0;
                    barG = (int)(200.0f + 55.0f * ratio);
                    barB = 255;
                }
                int barColor = (int)((float)alpha * 0.85f) << 24 | barR << 16 | barG << 8 | barB;
                context.method_25294(bx, by, bx + barW, eqY + eqHeight, barColor);
                if (!state.isPlaying() || barH <= 3) continue;
                context.method_25294(bx, by - 1, bx + barW, by, alpha << 24 | 0xFFFFFF);
            }
            int badgeX = eqX + totalEqW + 8;
            int badgeY = eqY + 2;
            int trimmedPlatMax = maxTextWidth - totalEqW - timeWidth - 28;
            if (trimmedPlatMax > 15) {
                String trimmedPlatform = textRenderer.method_27523(platformStr, trimmedPlatMax);
                int platW = textRenderer.method_1727(trimmedPlatform);
                MusicHudRenderer.renderRoundedRect(context, badgeX - 2, badgeY - 1, platW + 4, 10, 3, (int)((float)alpha * 0.25f) << 24 | platColor & 0xFFFFFF);
                context.method_51433(textRenderer, trimmedPlatform, badgeX, badgeY, alpha << 24 | platColor & 0xFFFFFF, false);
                badgeX += platW + 6;
            }
            if (Math.abs(state.playbackSpeed() - 1.0f) >= 0.05f) {
                String spdText = String.format(java.util.Locale.US, "\u26A1 %.2fx", Float.valueOf(state.playbackSpeed()));
                int spdW = textRenderer.method_1727(spdText);
                MusicHudRenderer.renderRoundedRect(context, badgeX - 2, badgeY - 1, spdW + 4, 10, 3, (int)((float)alpha * 0.25f) << 24 | 0xFFA500);
                context.method_51433(textRenderer, spdText, badgeX, badgeY, alpha << 24 | 0xFFB732, false);
                badgeX += spdW + 6;
            }
            if (isFav) {
                MusicHudRenderer.renderRoundedRect(context, badgeX - 2, badgeY - 1, 12, 10, 3, (int)((float)alpha * 0.25f) << 24 | 0xFFD700);
            }
            context.method_51433(textRenderer, starIcon, badgeX, badgeY, starColor, isFav);
            context.method_51433(textRenderer, timeText, textX + maxTextWidth - timeWidth, badgeY, timeColor, false);
        } else {
            int eqX = coverX + coverSize - 15;
            int eqY = coverY + coverSize - 12;
            MusicHudRenderer.renderRoundedRect(context, eqX - 1, eqY - 1, 15, 12, 3, (int)((float)alpha * 0.8f) << 24 | 0xA0A12);
            for (int b = 0; b < 4; ++b) {
                float phase = (float)b * 1.35f;
                float speed = 0.008f + (float)b * 0.003f;
                float barH = state.isPlaying() ? (float)(Math.sin((double)now * (double)speed + (double)phase) * 0.45 + 0.55) * 7.5f + 2.0f : 2.0f;
                int bx = eqX + b * 3 + 1;
                int by = eqY + 9 - (int)barH;
                int bColor = alpha << 24 | (state.isPlaying() ? (domColor != 0 ? domColor : 58879) : 0x777788);
                context.method_25294(bx, by, bx + 2, eqY + 9, bColor);
            }
            if (isFav) {
                MusicHudRenderer.renderRoundedRect(context, textX - 2, textY + 24, 13, 12, 3, (int)((float)alpha * 0.25f) << 24 | 0xFFD700);
            }
            context.method_51433(textRenderer, starIcon, textX, textY + 26, starColor, isFav);
            int starW = textRenderer.method_1727(starIcon) + 4;
            int maxPlatformW = maxTextWidth - timeWidth - starW - 6;
            int platX = textX + starW;
            int platY = textY + 26;
            if (maxPlatformW > 15) {
                String trimmedPlatform = textRenderer.method_27523(platformStr, maxPlatformW);
                int platW = textRenderer.method_1727(trimmedPlatform);
                MusicHudRenderer.renderRoundedRect(context, platX - 2, platY - 1, platW + 4, 10, 3, (int)((float)alpha * 0.25f) << 24 | platColor & 0xFFFFFF);
                context.method_51433(textRenderer, trimmedPlatform, platX, platY, alpha << 24 | platColor & 0xFFFFFF, false);
                platX += platW + 5;
            }
            if (Math.abs(state.playbackSpeed() - 1.0f) >= 0.05f && textX + maxTextWidth - timeWidth - platX > 25) {
                String spdText = String.format(java.util.Locale.US, "⚡%.2fx", Float.valueOf(state.playbackSpeed()));
                int spdW = textRenderer.method_1727(spdText);
                MusicHudRenderer.renderRoundedRect(context, platX - 2, platY - 1, spdW + 4, 10, 3, (int)((float)alpha * 0.25f) << 24 | 0xFFA500);
                context.method_51433(textRenderer, spdText, platX, platY, alpha << 24 | 0xFFB732, false);
            }
            context.method_51433(textRenderer, timeText, textX + maxTextWidth - timeWidth, textY + 26, timeColor, false);
        }
        if (HudConfig.INSTANCE.showProgressBar) {
            int barHeight = class_3532.method_15340((int)HudConfig.INSTANCE.progressBarHeight, (int)2, (int)6);
            int barPad = Math.max(r + 2, 8);
            int barW = baseW - barPad * 2;
            int barY = baseH - barHeight - (isLarge ? 4 : 2);
            int barBgColor = (int)((float)alpha * 0.45f) << 24 | 0x14141E;
            int barFillColor = alpha << 24 | (HudConfig.INSTANCE.progressBarColor != 0xFFFFFF ? HudConfig.INSTANCE.progressBarColor : (domColor != 0 ? domColor : 58879));
            MusicHudRenderer.renderRoundedRect(context, barPad, barY, barW, barHeight, barHeight / 2, barBgColor);
            float progress = state.getProgress();
            int progressWidth = (int)((float)barW * progress);
            if (progressWidth > 0) {
                MusicHudRenderer.renderRoundedRect(context, barPad, barY, progressWidth, barHeight, barHeight / 2, barFillColor);
                context.method_25294(barPad, barY, barPad + progressWidth, barY + 1, (int)((float)alpha * 0.45f) << 24 | 0xFFFFFF);
                long cycle = 2600L;
                float shimmerCycle = (float)(now % cycle) / (float)cycle;
                if (shimmerCycle < 0.65f) {
                    float st = shimmerCycle / 0.65f;
                    float waveCenterX = (float)barPad + (float)progressWidth * st;
                    float waveHalfW = 10.0f;
                    int wx1 = (int)Math.max((float)barPad, waveCenterX - waveHalfW);
                    int wx2 = (int)Math.min((float)(barPad + progressWidth), waveCenterX + waveHalfW);
                    if (wx2 > wx1) {
                        int shimmerAlpha = (int)((float)alpha * 0.4f * (1.0f - Math.abs(st - 0.5f) * 0.5f));
                        context.method_25294(wx1, barY, wx2, barY + barHeight, shimmerAlpha << 24 | 0xFFFFFF);
                        int cx = (int)waveCenterX;
                        if (cx >= barPad && cx < barPad + progressWidth) {
                            context.method_25294(cx, barY, cx + 1, barY + barHeight, (int)((float)alpha * 0.7f) << 24 | 0xFFFFFF);
                        }
                    }
                }
                int knobX = barPad + progressWidth;
                int knobH = barHeight + 2;
                int knobY = barY - 1;
                context.method_25294(knobX - 1, knobY, knobX + 1, knobY + knobH, alpha << 24 | 0xFFFFFF);
            }
        }
    }

    public static int getPlatformColor(String platform) {
        if (platform == null) {
            return -16718337;
        }
        return switch (platform.toLowerCase()) {
            case "spotify" -> -14829228;
            case "youtube" -> -56798;
            case "soundcloud" -> -39424;
            case "vk" -> -16746497;
            case "apple" -> -246716;
            case "yandex" -> -13312;
            case "browser" -> -16723201;
            default -> -16718337;
        };
    }

    private void renderMarqueeText(class_332 context, class_327 textRenderer, String text, int x, int y, int maxWidth, int color, long now, boolean isTitle) {
        int textWidth = textRenderer.method_1727(text);
        if (textWidth <= maxWidth) {
            context.method_51433(textRenderer, text, x, y, color, isTitle);
            return;
        }
        long scrollDelay = isTitle ? this.marqueeStartTime : this.marqueeStartTime + 500L;
        long l = scrollDelay;
        if (now < scrollDelay) {
            this.drawClippedText(context, textRenderer, text, x, y, maxWidth, color, 0, isTitle);
            return;
        }
        long elapsed = now - scrollDelay;
        int totalScroll = textWidth - maxWidth + 24;
        float scrollSpeed = 28.0f;
        float cycleTime = (float)totalScroll / scrollSpeed * 1000.0f + 2500.0f;
        float phase = (float)(elapsed % (long)cycleTime) / cycleTime;
        int scrollOffset = phase < 0.75f ? (int)(phase / 0.75f * (float)totalScroll) : 0;
        this.drawClippedText(context, textRenderer, text, x, y, maxWidth, color, scrollOffset, isTitle);
    }

    private void drawClippedText(class_332 context, class_327 textRenderer, String text, int x, int y, int maxWidth, int color, int scrollOffset, boolean shadow) {
        context.method_44379(x, y - 2, x + maxWidth, y + 14);
        context.method_51433(textRenderer, text, x - scrollOffset, y, color, shadow);
        context.method_44380();
    }

    private String formatTime(long ms) {
        if (ms <= 0L) {
            return "0:00";
        }
        long totalSeconds = ms / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%d:%02d", minutes, seconds);
    }
}

