package com.example.yandexmusichud.lyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GeniusLyricsProvider {
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(3000L)).followRedirects(HttpClient.Redirect.NORMAL).build();
    private static final Pattern LYRICS_CONTAINER_PATTERN = Pattern.compile("<div[^>]*data-lyrics-container=[\"']true[\"'][^>]*>(.*?)</div>", 32);
    private static final Pattern OLD_LYRICS_PATTERN = Pattern.compile("<div[^>]*class=[\"']lyrics[\"'][^>]*>(.*?)</div>", 32);
    private static final Pattern BR_TAG_PATTERN = Pattern.compile("<br\\s*/?>", 2);
    private static final Pattern P_TAG_PATTERN = Pattern.compile("</?p[^>]*>", 2);
    private static final Pattern HTML_TAG_PATTERN = Pattern.compile("<[^>]+>");
    private static final Pattern CONTRIBUTORS_PATTERN = Pattern.compile("^\\d+\\s+Contributors.*$", 2);

    public static String fetchLyrics(String title, String artist, long timeoutMs) {
        if (title == null || title.isBlank()) {
            return null;
        }
        try {
            String query = artist != null && !artist.isBlank() ? artist.trim() + " " + title.trim() : title.trim();
            String searchUrl = "https://genius.com/api/search/multi?per_page=5&q=" + URLEncoder.encode(query, StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(searchUrl)).header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36").header("Accept", "application/json").timeout(Duration.ofMillis(timeoutMs > 0L ? timeoutMs : 3000L)).GET().build();
            HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() != 200 || response.body() == null || response.body().isBlank()) {
                return null;
            }
            JsonObject root = JsonParser.parseString((String)response.body()).getAsJsonObject();
            if (!root.has("response") || root.get("response").isJsonNull()) {
                return null;
            }
            JsonObject respObj = root.getAsJsonObject("response");
            if (!respObj.has("sections") || respObj.get("sections").isJsonNull()) {
                return null;
            }
            JsonArray sections = respObj.getAsJsonArray("sections");
            String bestSongUrl = null;
            double bestScore = -1.0;
            for (JsonElement secEl : sections) {
                JsonObject sec;
                if (!secEl.isJsonObject() || !(sec = secEl.getAsJsonObject()).has("type") || !"song".equalsIgnoreCase(sec.get("type").getAsString()) || !sec.has("hits") || sec.get("hits").isJsonNull()) continue;
                JsonArray hits = sec.getAsJsonArray("hits");
                for (JsonElement hitEl : hits) {
                    String url;
                    JsonObject hit;
                    if (!hitEl.isJsonObject() || !(hit = hitEl.getAsJsonObject()).has("result") || hit.get("result").isJsonNull()) continue;
                    JsonObject res = hit.getAsJsonObject("result");
                    String resTitle = res.has("title") && !res.get("title").isJsonNull() ? res.get("title").getAsString() : "";
                    String resArtist = "";
                    if (res.has("primary_artist") && !res.get("primary_artist").isJsonNull()) {
                        JsonObject pa = res.getAsJsonObject("primary_artist");
                        resArtist = pa.has("name") && !pa.get("name").isJsonNull() ? pa.get("name").getAsString() : "";
                    }
                    String string = url = res.has("url") && !res.get("url").isJsonNull() ? res.get("url").getAsString() : "";
                    if (url.isBlank()) continue;
                    double tSim = GeniusLyricsProvider.computeStringSimilarity(title, resTitle);
                    double d = artist != null && !artist.isBlank() ? GeniusLyricsProvider.computeStringSimilarity(artist, resArtist) : 1.0;
                    double aSim = d;
                    double score = tSim * 0.65 + aSim * 0.35;
                    if (!(score > bestScore)) continue;
                    bestScore = score;
                    bestSongUrl = url;
                }
            }
            if (bestSongUrl == null || bestScore < 0.38) {
                return null;
            }
            HttpRequest pageReq = HttpRequest.newBuilder().uri(URI.create(bestSongUrl)).header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36").header("Accept", "text/html,application/xhtml+xml").timeout(Duration.ofMillis(timeoutMs > 0L ? timeoutMs : 3500L)).GET().build();
            HttpResponse<String> pageResp = HTTP_CLIENT.send(pageReq, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (pageResp.statusCode() != 200 || pageResp.body() == null || pageResp.body().isBlank()) {
                return null;
            }
            return GeniusLyricsProvider.parseGeniusHtml(pageResp.body());
        }
        catch (Exception ignored) {
            return null;
        }
    }

    public static String parseGeniusHtml(String html) {
        if (html == null || html.isBlank()) {
            return null;
        }
        ArrayList<String> rawContainers = new ArrayList<String>();
        Matcher m = LYRICS_CONTAINER_PATTERN.matcher(html);
        while (m.find()) {
            rawContainers.add(m.group(1));
        }
        if (rawContainers.isEmpty()) {
            Matcher oldM = OLD_LYRICS_PATTERN.matcher(html);
            while (oldM.find()) {
                rawContainers.add(oldM.group(1));
            }
        }
        if (rawContainers.isEmpty()) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (String container : rawContainers) {
            String[] lines;
            String text = BR_TAG_PATTERN.matcher(container).replaceAll("\n");
            text = P_TAG_PATTERN.matcher(text).replaceAll("\n");
            text = HTML_TAG_PATTERN.matcher(text).replaceAll("");
            text = GeniusLyricsProvider.unescapeHtml(text);
            for (String line : lines = text.split("\\r?\\n")) {
                if ((line = line.trim()).isEmpty() || CONTRIBUTORS_PATTERN.matcher(line).find() || line.contains("Translations") && (line.contains("English") || line.contains("Russian") || line.contains("Espa\u00f1ol")) || line.endsWith("Lyrics") && line.length() < 50 && !line.startsWith("[")) continue;
                sb.append(line).append("\n");
            }
        }
        String result = sb.toString().trim();
        return result.isEmpty() ? null : result;
    }

    private static String unescapeHtml(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ").replace("&#8217;", "\u2019").replace("&#8216;", "\u2018").replace("&#8220;", "\u201c").replace("&#8221;", "\u201d").replace("&#8212;", "-").replace("&#8211;", "-");
    }

    public static double computeStringSimilarity(String s1, String s2) {
        if (s1 == null || s2 == null) {
            return 0.0;
        }
        String a = GeniusLyricsProvider.normalize(s1);
        String b = GeniusLyricsProvider.normalize(s2);
        if (a.isEmpty() || b.isEmpty()) {
            return 0.0;
        }
        if (a.equals(b)) {
            return 1.0;
        }
        if (a.contains(b) || b.contains(a)) {
            return (double)Math.min(a.length(), b.length()) / (double)Math.max(a.length(), b.length());
        }
        String[] wordsA = a.split("\\s+");
        String[] wordsB = b.split("\\s+");
        HashSet<String> setA = new HashSet<String>(Arrays.asList(wordsA));
        HashSet<String> setB = new HashSet<String>(Arrays.asList(wordsB));
        setA.removeIf(w -> w.length() < 2);
        setB.removeIf(w -> w.length() < 2);
        if (setA.isEmpty() || setB.isEmpty()) {
            return 0.0;
        }
        HashSet<String> intersection = new HashSet<String>(setA);
        intersection.retainAll(setB);
        HashSet<String> union = new HashSet<String>(setA);
        union.addAll(setB);
        return (double)intersection.size() / (double)union.size();
    }

    private static String normalize(String s) {
        if (s == null) {
            return "";
        }
        return s.toLowerCase().replaceAll("[^a-z\u0430-\u044f0-9\\s]", "").replaceAll("\\s+", " ").trim();
    }
}

