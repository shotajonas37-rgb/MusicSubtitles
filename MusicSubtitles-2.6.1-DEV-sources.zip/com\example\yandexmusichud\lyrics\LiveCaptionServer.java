package com.example.yandexmusichud.lyrics;

import com.example.yandexmusichud.lyrics.LyricLine;
import com.example.yandexmusichud.lyrics.LyricsManager;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.Executors;

public class LiveCaptionServer {
    public static final int PORT = 38473;
    private final LyricsManager lyricsManager;
    private HttpServer server;

    public LiveCaptionServer(LyricsManager lyricsManager) {
        this.lyricsManager = lyricsManager;
    }

    public void start() {
        try {
            this.server = HttpServer.create(new InetSocketAddress("127.0.0.1", 38473), 0);
            this.server.setExecutor(Executors.newCachedThreadPool(r -> {
                Thread t = new Thread(r, "MusicSubtitles-CaptionServer");
                t.setDaemon(true);
                return t;
            }));
            this.server.createContext("/captions/push", new PushHandler());
            this.server.createContext("/captions/transcript", new TranscriptHandler());
            this.server.createContext("/captions/status", new StatusHandler());
            this.server.start();
            System.out.println("[MusicSubtitles] LiveCaptionServer started on http://127.0.0.1:38473");
        }
        catch (Exception e) {
            System.out.println("[MusicSubtitles] Could not start LiveCaptionServer on port 38473: " + e.getMessage());
        }
    }

    public void stop() {
        if (this.server != null) {
            try {
                this.server.stop(0);
            }
            catch (Exception exception) {

            }
            this.server = null;
        }
    }

    private static void sendCors(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
    }

    private static void sendResponse(HttpExchange exchange, int statusCode, String responseText) throws IOException {
        LiveCaptionServer.sendCors(exchange);
        byte[] bytes = responseText.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody();){
            os.write(bytes);
        }
    }

    private class PushHandler
    implements HttpHandler {
        private PushHandler() {
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            LiveCaptionServer.sendCors(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(200, -1L);
                return;
            }
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                LiveCaptionServer.sendResponse(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }
            try (InputStream is = exchange.getRequestBody();){
                long durationMs;
                String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                JsonObject json = JsonParser.parseString((String)body).getAsJsonObject();
                String text = json.has("text") ? json.get("text").getAsString() : "";
                long l = durationMs = json.has("durationMs") ? json.get("durationMs").getAsLong() : 3500L;
                if (!text.isEmpty()) {
                    LiveCaptionServer.this.lyricsManager.pushLiveCaption(text, durationMs);
                    LiveCaptionServer.sendResponse(exchange, 200, "{\"success\":true}");
                } else {
                    LiveCaptionServer.sendResponse(exchange, 400, "{\"error\":\"Empty text\"}");
                }
            }
            catch (Exception e) {
                LiveCaptionServer.sendResponse(exchange, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    private class TranscriptHandler
    implements HttpHandler {
        private TranscriptHandler() {
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            LiveCaptionServer.sendCors(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(200, -1L);
                return;
            }
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                LiveCaptionServer.sendResponse(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }
            try (InputStream is = exchange.getRequestBody();){
                String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                JsonObject json = JsonParser.parseString((String)body).getAsJsonObject();
                String videoTitle = json.has("videoTitle") ? json.get("videoTitle").getAsString() : "";
                ArrayList<LyricLine> lines = new ArrayList<LyricLine>();
                if (json.has("lines") && json.get("lines").isJsonArray()) {
                    JsonArray arr = json.getAsJsonArray("lines");
                    for (JsonElement elem : arr) {
                        if (!elem.isJsonObject()) continue;
                        JsonObject obj = elem.getAsJsonObject();
                        long startMs = obj.has("startMs") ? obj.get("startMs").getAsLong() : 0L;
                        long endMs = obj.has("endMs") ? obj.get("endMs").getAsLong() : startMs + 3500L;
                        String text = obj.has("text") ? obj.get("text").getAsString() : "";
                        if (text.trim().isEmpty()) continue;
                        lines.add(new LyricLine(startMs, endMs, text.trim(), null));
                    }
                }
                if (!lines.isEmpty()) {
                    LiveCaptionServer.this.lyricsManager.pushTranscript(videoTitle, lines);
                    LiveCaptionServer.sendResponse(exchange, 200, "{\"success\":true,\"count\":" + lines.size() + "}");
                } else {
                    LiveCaptionServer.sendResponse(exchange, 400, "{\"error\":\"No lines provided\"}");
                }
            }
            catch (Exception e) {
                LiveCaptionServer.sendResponse(exchange, 500, "{\"error\":\"" + e.getMessage() + "\"}");
            }
        }
    }

    private static class StatusHandler
    implements HttpHandler {
        private StatusHandler() {
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            LiveCaptionServer.sendCors(exchange);
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(200, -1L);
                return;
            }
            LiveCaptionServer.sendResponse(exchange, 200, "{\"status\":\"ok\",\"service\":\"MusicSubtitles-LiveCaptionServer\",\"port\":38473}");
        }
    }
}

