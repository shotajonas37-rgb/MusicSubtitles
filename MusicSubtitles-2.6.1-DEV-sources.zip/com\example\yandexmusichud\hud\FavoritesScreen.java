package com.example.yandexmusichud.hud;

import com.example.yandexmusichud.favorites.FavoriteTrack;
import com.example.yandexmusichud.favorites.FavoritesManager;
import com.example.yandexmusichud.hud.ModernButtonWidget;
import com.example.yandexmusichud.hud.MusicHudRenderer;
import com.example.yandexmusichud.texture.CoverTextureManager;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_437;

public class FavoritesScreen
extends class_437 {
    private final class_437 parent;
    private class_342 searchField;
    private final List<FavoriteTrack> filteredTracks = new ArrayList<FavoriteTrack>();
    private static final Map<String, class_2960> THUMBNAIL_CACHE = new ConcurrentHashMap<String, class_2960>();
    private int scrollOffset = 0;
    private int maxScroll = 0;

    public FavoritesScreen(class_437 parent) {
        super((class_2561)class_2561.method_43470((String)"\u2b50 \u0418\u0437\u0431\u0440\u0430\u043d\u043d\u0430\u044f \u043c\u0443\u0437\u044b\u043a\u0430"));
        this.parent = parent;
    }

    protected void method_25426() {
        super.method_25426();
        int panelWidth = Math.min(420, this.field_22789 - 20);
        int panelX = (this.field_22789 - panelWidth) / 2;
        int panelY = 25;
        int panelHeight = this.field_22790 - 65;
        this.searchField = new class_342(this.field_22793, panelX + 10, panelY + 10, panelWidth - 20, 18, (class_2561)class_2561.method_43470((String)"\u041f\u043e\u0438\u0441\u043a..."));
        this.searchField.method_47404((class_2561)class_2561.method_43470((String)"\ud83d\udd0d \u041f\u043e\u0438\u0441\u043a \u043f\u043e \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044e \u0438\u043b\u0438 \u0430\u0432\u0442\u043e\u0440\u0443..."));
        this.searchField.method_1863(this::updateFilteredList);
        this.method_37063(this.searchField);
        int btnW = 120;
        this.method_37063(new ModernButtonWidget(this.field_22789 / 2 - btnW - 10, this.field_22790 - 30, btnW, 20, (class_2561)class_2561.method_43470((String)"\u041d\u0430\u0437\u0430\u0434"), b -> this.field_22787.method_1507(this.parent)).setPrimary(true));
        this.method_37063(new ModernButtonWidget(this.field_22789 / 2 + 10, this.field_22790 - 30, btnW, 20, (class_2561)class_2561.method_43470((String)"\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0432\u0441\u0451"), b -> {
            for (FavoriteTrack t : new ArrayList<FavoriteTrack>(FavoritesManager.INSTANCE.getFavorites())) {
                FavoritesManager.INSTANCE.removeFavorite(t.id);
            }
            this.updateFilteredList(this.searchField.method_1882());
        }).setCustomBgColor(-864607710));
        this.updateFilteredList(this.searchField != null ? this.searchField.method_1882() : "");
    }

    private void updateFilteredList(String query) {
        this.filteredTracks.clear();
        String q = query != null ? query.trim().toLowerCase() : "";
        for (FavoriteTrack track : FavoritesManager.INSTANCE.getFavorites()) {
            if (!q.isEmpty() && !track.title.toLowerCase().contains(q) && !track.artist.toLowerCase().contains(q) && (track.album == null || !track.album.toLowerCase().contains(q)) && (track.platformName == null || !track.platformName.toLowerCase().contains(q))) continue;
            this.filteredTracks.add(track);
        }
        int itemHeight = 36;
        int listHeight = this.field_22790 - 65 - 36;
        int totalContentHeight = this.filteredTracks.size() * itemHeight;
        this.maxScroll = Math.max(0, totalContentHeight - listHeight);
        this.scrollOffset = class_3532.method_15340((int)this.scrollOffset, (int)0, (int)this.maxScroll);
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int panelWidth = Math.min(420, this.field_22789 - 20);
        int panelHeight = this.field_22790 - 65;
        int panelX = (this.field_22789 - panelWidth) / 2;
        int panelY = 25;
        MusicHudRenderer.renderRoundedRect(context, panelX, panelY, panelWidth, panelHeight, 6, -586084066);
        MusicHudRenderer.renderRoundedRect(context, panelX, panelY, panelWidth, panelHeight, 6, 0x44FFFFFF);
        context.method_25300(this.field_22793, "\u2b50 \u0418\u0437\u0431\u0440\u0430\u043d\u043d\u0430\u044f \u043c\u0443\u0437\u044b\u043a\u0430 (" + FavoritesManager.INSTANCE.getFavorites().size() + ")", this.field_22789 / 2, panelY - 14, -10496);
        int listX = panelX + 8;
        int listY = panelY + 34;
        int listW = panelWidth - 16;
        int listH = panelHeight - 42;
        int itemH = 36;
        context.method_44379(listX, listY, listX + listW, listY + listH);
        if (this.filteredTracks.isEmpty()) {
            String emptyMsg = FavoritesManager.INSTANCE.getFavorites().isEmpty() ? "\u041d\u0435\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043d\u044b\u0445 \u0442\u0440\u0435\u043a\u043e\u0432. \u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u2606 \u0432 \u043f\u043b\u0430\u0448\u043a\u0435 \u0438\u043b\u0438 \u043a\u043b\u0430\u0432\u0438\u0448\u0443 K!" : "\u041d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e \u043f\u043e \u0432\u0430\u0448\u0435\u043c\u0443 \u0437\u0430\u043f\u0440\u043e\u0441\u0443.";
            context.method_25300(this.field_22793, emptyMsg, panelX + panelWidth / 2, listY + listH / 2 - 4, -2002081110);
        } else {
            for (int i = 0; i < this.filteredTracks.size(); ++i) {
                int itemY = listY + i * itemH - this.scrollOffset;
                if (itemY + itemH < listY || itemY > listY + listH) continue;
                FavoriteTrack track = this.filteredTracks.get(i);
                boolean isHovered = mouseX >= listX && mouseX <= listX + listW && mouseY >= itemY && mouseY <= itemY + itemH - 2;
                int itemBg = isHovered ? 0x66333355 : 0x33222233;
                MusicHudRenderer.renderRoundedRect(context, listX, itemY, listW, itemH - 2, 4, itemBg);
                class_2960 coverId = this.getThumbnailId(track);
                context.method_25290(class_10799.field_56883, coverId, listX + 3, itemY + 2, 0.0f, 0.0f, 30, 30, 30, 30);
                int textLeft = listX + 38;
                int maxTextW = listW - 145;
                String titleText = this.field_22793.method_27523(track.title, maxTextW);
                String artistText = this.field_22793.method_27523(track.artist, maxTextW);
                context.method_51433(this.field_22793, titleText, textLeft, itemY + 4, -1, true);
                context.method_51433(this.field_22793, artistText, textLeft, itemY + 16, -5592406, false);
                String pBadge = track.platformName != null && !track.platformName.isEmpty() ? track.platformName : "\u041c\u0443\u0437\u044b\u043a\u0430";
                int pColor = this.getPlatformColor(track.platform);
                int badgeW = this.field_22793.method_1727(pBadge) + 6;
                int badgeX = listX + listW - 100 - badgeW;
                if (badgeX > textLeft + 60) {
                    MusicHudRenderer.renderRoundedRect(context, badgeX, itemY + 9, badgeW, 14, 3, pColor & 0xFFFFFF | 0x33000000);
                    context.method_51433(this.field_22793, pBadge, badgeX + 3, itemY + 12, pColor, false);
                }
                int playBtnX = listX + listW - 95;
                int playBtnY = itemY + 6;
                int playBtnW = 68;
                int playBtnH = 20;
                boolean playHover = mouseX >= playBtnX && mouseX <= playBtnX + playBtnW && mouseY >= playBtnY && mouseY <= playBtnY + playBtnH;
                int playBg = playHover ? -14112955 : -870416844;
                MusicHudRenderer.renderRoundedRect(context, playBtnX, playBtnY, playBtnW, playBtnH, 3, playBg);
                context.method_25300(this.field_22793, "\u25b6 \u0421\u043b\u0443\u0448\u0430\u0442\u044c", playBtnX + playBtnW / 2, playBtnY + 6, -1);
                int delBtnX = listX + listW - 22;
                int delBtnY = itemY + 6;
                int delBtnW = 20;
                int delBtnH = 20;
                boolean delHover = mouseX >= delBtnX && mouseX <= delBtnX + delBtnW && mouseY >= delBtnY && mouseY <= delBtnY + delBtnH;
                int delBg = delHover ? -3394765 : 0x55555555;
                MusicHudRenderer.renderRoundedRect(context, delBtnX, delBtnY, delBtnW, delBtnH, 3, delBg);
                context.method_25300(this.field_22793, "\u2716", delBtnX + delBtnW / 2, delBtnY + 6, delHover ? -1 : -5592406);
            }
        }
        context.method_44380();
        if (this.maxScroll > 0) {
            int scrollbarX = panelX + panelWidth - 6;
            int scrollbarW = 4;
            int scrollbarTrackH = listH;
            float scrollFraction = (float)this.scrollOffset / (float)this.maxScroll;
            int thumbH = Math.max(16, (int)((float)scrollbarTrackH * ((float)listH / (float)(listH + this.maxScroll))));
            int thumbY = listY + (int)((float)(scrollbarTrackH - thumbH) * scrollFraction);
            context.method_25294(scrollbarX, listY, scrollbarX + scrollbarW, listY + scrollbarTrackH, 0x33000000);
            context.method_25294(scrollbarX, thumbY, scrollbarX + scrollbarW, thumbY + thumbH, -1996488705);
        }
    }

    public boolean method_25402(class_11909 click, boolean bl) {
        int mx = (int)click.comp_4798();
        int my = (int)click.comp_4799();
        if (click.method_74245() == 0) {
            int panelWidth = Math.min(420, this.field_22789 - 20);
            int panelHeight = this.field_22790 - 65;
            int panelX = (this.field_22789 - panelWidth) / 2;
            int panelY = 25;
            int listX = panelX + 8;
            int listY = panelY + 34;
            int listW = panelWidth - 16;
            int listH = panelHeight - 42;
            int itemH = 36;
            if (mx >= listX && mx <= listX + listW && my >= listY && my <= listY + listH) {
                for (int i = 0; i < this.filteredTracks.size(); ++i) {
                    int itemY = listY + i * itemH - this.scrollOffset;
                    if (itemY + itemH < listY || itemY > listY + listH) continue;
                    FavoriteTrack track = this.filteredTracks.get(i);
                    int playBtnX = listX + listW - 95;
                    int playBtnY = itemY + 6;
                    int playBtnW = 68;
                    int playBtnH = 20;
                    if (mx >= playBtnX && mx <= playBtnX + playBtnW && my >= playBtnY && my <= playBtnY + playBtnH) {
                        FavoritesManager.playTrack(track);
                        if (this.field_22787 != null && this.field_22787.method_1483() != null) {
                            this.field_22787.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)((class_3414)class_3417.field_15015.comp_349()), (float)1.2f, (float)0.7f));
                        }
                        return true;
                    }
                    int delBtnX = listX + listW - 22;
                    int delBtnY = itemY + 6;
                    int delBtnW = 20;
                    int delBtnH = 20;
                    if (mx < delBtnX || mx > delBtnX + delBtnW || my < delBtnY || my > delBtnY + delBtnH) continue;
                    FavoritesManager.INSTANCE.removeFavorite(track.id);
                    this.updateFilteredList(this.searchField.method_1882());
                    return true;
                }
            }
        }
        return super.method_25402(click, bl);
    }

    public boolean handleMouseScroll(double amount) {
        if (this.maxScroll > 0) {
            this.scrollOffset = class_3532.method_15340((int)((int)((double)this.scrollOffset - amount * 24.0)), (int)0, (int)this.maxScroll);
            return true;
        }
        return false;
    }

    private int getPlatformColor(String platform) {
        if (platform == null) {
            return -13312;
        }
        return switch (platform.toLowerCase()) {
            case "spotify" -> -14829228;
            case "youtube" -> -65536;
            case "soundcloud" -> -43776;
            case "vk" -> -16746497;
            case "apple" -> -246716;
            case "yandex" -> -13312;
            case "browser" -> -16723201;
            default -> -5197632;
        };
    }

    private class_2960 getThumbnailId(FavoriteTrack track) {
        String idKey;
        if (track == null || track.coverBase64 == null || track.coverBase64.isEmpty()) {
            return CoverTextureManager.DEFAULT_COVER;
        }
        String string = idKey = track.id != null ? track.id : "unknown";
        if (THUMBNAIL_CACHE.containsKey(idKey)) {
            return THUMBNAIL_CACHE.get(idKey);
        }
        try {
            byte[] bytes = Base64.getDecoder().decode(track.coverBase64);
            class_1011 img = class_1011.method_4309((InputStream)new ByteArrayInputStream(bytes));
            class_2960 texUri = class_2960.method_60655((String)"yandexmusichud", (String)("favorites_thumb_" + Math.abs(idKey.hashCode())));
            class_1043 texture = new class_1043(() -> "fav_thumb", img);
            class_310.method_1551().method_1531().method_4616(texUri, (class_1044)texture);
            THUMBNAIL_CACHE.put(idKey, texUri);
            return texUri;
        }
        catch (Exception e) {
            return CoverTextureManager.DEFAULT_COVER;
        }
    }
}

