package com.example.yandexmusichud;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.ducking.SmartDuckingManager;
import com.example.yandexmusichud.helper.HelperProcessManager;
import com.example.yandexmusichud.hud.IntroScreen;
import com.example.yandexmusichud.hud.KeybindSetupScreen;
import com.example.yandexmusichud.hud.MusicHudRenderer;
import com.example.yandexmusichud.hud.SystemDiagnosticsScreen;
import com.example.yandexmusichud.hud.TwitchSettingsScreen;
import com.example.yandexmusichud.twitch.TwitchManager;
import com.example.yandexmusichud.keybinds.MusicControlKeybinds;
import com.example.yandexmusichud.lyrics.LiveCaptionServer;
import com.example.yandexmusichud.lyrics.LyricsManager;
import com.example.yandexmusichud.lyrics.LyricsRenderer;
import com.example.yandexmusichud.network.NowPlayingClient;
import com.example.yandexmusichud.stats.SessionStatsManager;
import com.example.yandexmusichud.texture.CoverTextureManager;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.List;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;

public class YandexMusicHudMod
implements ClientModInitializer {
    public static final String MOD_ID = "yandexmusichud";
    public static YandexMusicHudMod INSTANCE;
    private HelperProcessManager helperManager;
    private CoverTextureManager coverManager;
    private NowPlayingClient nowPlayingClient;
    private MusicHudRenderer hudRenderer;
    private LyricsManager lyricsManager;
    private LyricsRenderer lyricsRenderer;
    private LiveCaptionServer captionServer;

    public LyricsManager getLyricsManager() {
        return this.lyricsManager;
    }

    public void restartHelper() {
        new Thread(() -> {
            if (this.helperManager != null) {
                this.helperManager.stop();
                int p = this.helperManager.start();
                if (p > 0) {
                    HudConfig.INSTANCE.helperPort = p;
                    this.nowPlayingClient.start(p);
                }
            }
        }, "MusicSubtitles-HelperRestarter").start();
    }

    public void onInitializeClient() {
        INSTANCE = this;
        HudConfig.load();
        this.coverManager = new CoverTextureManager();
        this.nowPlayingClient = new NowPlayingClient(this.coverManager);
        this.hudRenderer = new MusicHudRenderer(this.nowPlayingClient, this.coverManager);
        this.helperManager = new HelperProcessManager();
        this.lyricsManager = new LyricsManager();
        this.lyricsRenderer = new LyricsRenderer(this.lyricsManager, this.nowPlayingClient);
        this.lyricsRenderer.register();
        MusicControlKeybinds.register();
        this.captionServer = new LiveCaptionServer(this.lyricsManager);
        this.captionServer.start();
        this.exportUserscript();
        TwitchManager.getInstance().start();
        com.example.yandexmusichud.donationalerts.DonationAlertsManager.getInstance().start();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            LiteralArgumentBuilder root = ClientCommandManager.literal("musicsubtitles");
            root.then(ClientCommandManager.literal("cancel").executes(ctx -> {
                this.lyricsManager.disableCurrentTrack();
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §cСубтитры для текущей песни отключены."));
                return 1;
            }));
            root.then(ClientCommandManager.literal("enable").executes(ctx -> {
                this.lyricsManager.enableCurrentTrack();
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §aСубтитры для текущей песни включены."));
                return 1;
            }));
            root.then(ClientCommandManager.literal("reload").executes(ctx -> {
                this.lyricsManager.reloadCurrentTrack();
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §eКэш субтитров сброшен, выполняется повторный поиск..."));
                return 1;
            }));
            root.then(ClientCommandManager.literal("diag").executes(ctx -> {
                class_310 mc = class_310.method_1551();
                mc.execute(() -> mc.method_1507((class_437)new SystemDiagnosticsScreen(mc.field_1755, new KeybindSetupScreen(mc.field_1755))));
                return 1;
            }));
            root.then(ClientCommandManager.literal("keybinds").executes(ctx -> {
                class_310 mc = class_310.method_1551();
                mc.execute(() -> mc.method_1507((class_437)new KeybindSetupScreen(mc.field_1755)));
                return 1;
            }));
            root.then(ClientCommandManager.literal("intro").executes(ctx -> {
                class_310 mc = class_310.method_1551();
                mc.execute(() -> mc.method_1507((class_437)new IntroScreen(mc.field_1755)));
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §aЗапуск заставки Music Subtitles..."));
                return 1;
            }));
            root.then(ClientCommandManager.literal("youtube").executes(ctx -> {
                Path scriptPath = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID).resolve("youtube_captions_sync.user.js");
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §eЮзерскрипт субтитров YouTube сохранён в:\n§f" + scriptPath.toString() + "\n§bУстановите его в Tampermonkey/Violentmonkey для мгновенного переноса субтитров из браузера в Minecraft!"));
                return 1;
            }));
            root.then(ClientCommandManager.literal("twitch").executes(ctx -> {
                class_310 mc = class_310.method_1551();
                mc.execute(() -> mc.method_1507((class_437)new TwitchSettingsScreen(mc.field_1755)));
                return 1;
            }));
            root.then(ClientCommandManager.literal("da").executes(ctx -> {
                class_310 mc = class_310.method_1551();
                mc.execute(() -> mc.method_1507((class_437)new com.example.yandexmusichud.hud.DonationAlertsSettingsScreen(mc.field_1755)));
                return 1;
            }));
            root.then(ClientCommandManager.literal("donationalerts").executes(ctx -> {
                class_310 mc = class_310.method_1551();
                mc.execute(() -> mc.method_1507((class_437)new com.example.yandexmusichud.hud.DonationAlertsSettingsScreen(mc.field_1755)));
                return 1;
            }));
            root.then(ClientCommandManager.literal("anim").executes(ctx -> {
                String current = HudConfig.INSTANCE.subtitlesAnimation;
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §fТекущая анимация субтитров: §e" + current + "\n§7Доступные режимы: §abounce §7(Караоке прыжок), §bwave §7(Неоновая волна), §dpop §7(Упругий поп-ап), §6pulse §7(Пульс в такт), §eslide §7(Слайд-появление), §fclassic §7(Классика)\n§7Использование: §e/musicsubtitles anim <режим> §7или §e/musicsubtitles nextanim"));
                return 1;
            }).then(ClientCommandManager.argument("mode", (ArgumentType)StringArgumentType.word()).suggests((ctx, builder) -> class_2172.method_9265(List.of("bounce", "wave", "pop", "pulse", "slide", "classic"), (SuggestionsBuilder)builder)).executes(ctx -> {
                String mode = StringArgumentType.getString((CommandContext)ctx, "mode").toLowerCase();
                String mapped = switch (mode) {
                    case "wave" -> "WAVE_FLOAT";
                    case "pop" -> "ELASTIC_POP";
                    case "pulse" -> "PULSE_GLOW";
                    case "slide" -> "SLIDE_FADE";
                    case "classic" -> "CLASSIC";
                    default -> "KARAOKE_BOUNCE";
                };
                HudConfig.INSTANCE.subtitlesAnimation = mapped;
                HudConfig.save();
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §aАнимация субтитров изменена на: §e" + mapped));
                return 1;
            })));
            root.then(ClientCommandManager.literal("nextanim").executes(ctx -> {
                String[] all = new String[]{"KARAOKE_BOUNCE", "WAVE_FLOAT", "ELASTIC_POP", "PULSE_GLOW", "SLIDE_FADE", "CLASSIC"};
                int curIdx = 0;
                for (int i = 0; i < all.length; ++i) {
                    if (!all[i].equalsIgnoreCase(HudConfig.INSTANCE.subtitlesAnimation)) continue;
                    curIdx = i;
                    break;
                }
                String next = all[(curIdx + 1) % all.length];
                HudConfig.INSTANCE.subtitlesAnimation = next;
                HudConfig.save();
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §aПереключено на анимацию: §e" + next));
                return 1;
            }));
            root.then(ClientCommandManager.literal("youtube").executes(ctx -> {
                ((FabricClientCommandSource)ctx.getSource()).sendFeedback((class_2561)class_2561.method_43470("§6[Музыка] §fСинхронизация YouTube активна на порту §e38473§f.\n§7Для мгновенных субтитров прямо из YouTube-видео установите скрипт §byoutube_captions_sync.user.js §7(в Tampermonkey/Violentmonkey)."));
                return 1;
            }));

            dispatcher.register(root);
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> this.hudRenderer.render(drawContext, tickCounter));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MusicControlKeybinds.handleTick(this.nowPlayingClient, this.coverManager);
            SessionStatsManager.INSTANCE.onTick(this.nowPlayingClient.getState());
            SmartDuckingManager.INSTANCE.onTick();
            TwitchManager.getInstance().checkPendingCommand();
            if (!IntroScreen.hasShownIntro && HudConfig.INSTANCE.showIntroSplash && client.method_53466() && client.method_18506() == null && client.field_1755 instanceof class_442) {
                IntroScreen.hasShownIntro = true;
                System.out.println("[MusicSubtitles] Minecraft finished loading! Displaying cinematic intro splash before TitleScreen.");
                client.method_1507((class_437)new IntroScreen(client.field_1755));
            }
            if (client.field_1724 != null && (!client.field_1690.field_1842 || HudConfig.INSTANCE.subtitlesVisibleInF1)) {
                int screenWidth = client.method_22683().method_4486();
                int screenHeight = client.method_22683().method_4502();
                this.lyricsManager.update(this.nowPlayingClient.getState(), screenWidth, screenHeight);
            }
        });
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            this.startHelper();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            if (this.captionServer != null) {
                this.captionServer.stop();
            }
            if (this.lyricsManager != null) {
                this.lyricsManager.shutdown();
            }
            this.nowPlayingClient.stop();
            this.coverManager.shutdown();
            this.helperManager.stop();
            TwitchManager.getInstance().disconnect();
            com.example.yandexmusichud.donationalerts.DonationAlertsManager.getInstance().disconnect();
        });
    }

    private void exportUserscript() {
        try {
            Path configDir = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID);
            Files.createDirectories(configDir, new FileAttribute[0]);
            Path targetFile = configDir.resolve("youtube_captions_sync.user.js");
            try (InputStream is = this.getClass().getResourceAsStream("/assets/yandexmusichud/youtube_captions_sync.user.js");){
                if (is != null) {
                    Files.copy(is, targetFile, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
        catch (Exception exception) {

        }
    }

    private void startHelper() {
        Thread startThread = new Thread(() -> {
            int port = this.helperManager.start();
            if (port > 0) {
                HudConfig.INSTANCE.helperPort = port;
                this.nowPlayingClient.start(port);
            } else if (HudConfig.INSTANCE.helperPort > 0) {
                this.nowPlayingClient.start(HudConfig.INSTANCE.helperPort);
            }
        }, "MusicSubtitles-HelperStarter");
        startThread.setDaemon(true);
        startThread.start();
    }
}

