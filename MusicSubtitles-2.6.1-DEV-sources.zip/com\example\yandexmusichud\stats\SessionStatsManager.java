package com.example.yandexmusichud.stats;

import com.example.yandexmusichud.network.TrackState;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class SessionStatsManager {
    public static final SessionStatsManager INSTANCE = new SessionStatsManager();
    private final long sessionStartTime = System.currentTimeMillis();
    private long totalActiveListeningMs = 0L;
    private long lastTickTime = System.currentTimeMillis();
    private int totalTracksPlayed = 0;
    private String lastCountedTrackKey = "";
    private final Map<String, Integer> artistCount = new ConcurrentHashMap<String, Integer>();
    private final Map<String, Integer> trackCount = new ConcurrentHashMap<String, Integer>();

    private SessionStatsManager() {
    }

    public void onTick(TrackState state) {
        long now = System.currentTimeMillis();
        long delta = now - this.lastTickTime;
        this.lastTickTime = now;
        if (state != null && state.isActive() && "playing".equalsIgnoreCase(state.status())) {
            String trackKey;
            String title;
            if (delta > 0L && delta < 5000L) {
                this.totalActiveListeningMs += delta;
            }
            String artist = state.artist() != null ? state.artist().trim() : "";
            String string = title = state.title() != null ? state.title().trim() : "";
            if (!title.isEmpty() && !(trackKey = (artist + "___" + title).toLowerCase()).equals(this.lastCountedTrackKey)) {
                this.lastCountedTrackKey = trackKey;
                ++this.totalTracksPlayed;
                if (!artist.isEmpty()) {
                    this.artistCount.merge(artist, 1, Integer::sum);
                }
                this.trackCount.merge(title, 1, Integer::sum);
            }
        }
    }

    public long getTotalActiveListeningMs() {
        return this.totalActiveListeningMs;
    }

    public String getFormattedListeningTime() {
        long seconds = this.totalActiveListeningMs / 1000L;
        long hours = seconds / 3600L;
        long minutes = seconds % 3600L / 60L;
        long secs = seconds % 60L;
        if (hours > 0L) {
            return String.format("%d \u0447. %d \u043c\u0438\u043d.", hours, minutes);
        }
        if (minutes > 0L) {
            return String.format("%d \u043c\u0438\u043d. %d \u0441\u0435\u043a.", minutes, secs);
        }
        return String.format("%d \u0441\u0435\u043a.", secs);
    }

    public int getTotalTracksPlayed() {
        return this.totalTracksPlayed;
    }

    public String getTopArtist() {
        return this.artistCount.entrySet().stream().max(Map.Entry.comparingByValue()).map(e -> (String)e.getKey() + " (" + String.valueOf(e.getValue()) + " \u0442\u0440.)").orElse("\u2014");
    }

    public String getTopTrack() {
        return this.trackCount.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse("\u2014");
    }

    public void shareStatsToChat() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) {
            return;
        }
        String timeStr = this.getFormattedListeningTime();
        int count = this.totalTracksPlayed;
        String topArtist = this.getTopArtist();
        String playerName = mc.field_1724.method_5477().getString();
        String msg = String.format("\u00a76[\u266b] \u00a7e%s: \u00a7f\u041c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u0430\u044f \u0441\u0435\u0441\u0441\u0438\u044f \u2014 \u00a7b%d \u00a7f\u0442\u0440\u0435\u043a\u043e\u0432 (\u00a7a%s\u00a7f), \u0442\u043e\u043f \u0430\u0440\u0442\u0438\u0441\u0442: \u00a7d%s", playerName, count, timeStr, topArtist);
        if (mc.field_1705 != null && mc.field_1705.method_1743() != null) {
            mc.field_1705.method_1743().method_1812((class_2561)class_2561.method_43470((String)msg));
        }
    }
}

