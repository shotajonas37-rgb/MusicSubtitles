package com.example.yandexmusichud.lyrics;

import com.example.yandexmusichud.config.HudConfig;
import com.example.yandexmusichud.hud.MusicHudRenderer;
import com.example.yandexmusichud.lyrics.LyricLine;
import com.example.yandexmusichud.lyrics.LyricsManager;
import com.example.yandexmusichud.lyrics.SubtitleBubble;
import com.example.yandexmusichud.network.NowPlayingClient;
import com.example.yandexmusichud.network.TrackState;
import java.util.List;
import java.util.Objects;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector4f;

public class LyricsRenderer {
    private final LyricsManager lyricsManager;
    private final NowPlayingClient client;

    public LyricsRenderer(LyricsManager lyricsManager, NowPlayingClient client) {
        this.lyricsManager = lyricsManager;
        this.client = client;
    }

    public void register() {
        HudRenderCallback.EVENT.register(this::render2D);
        WorldRenderEvents.END_MAIN.register(context -> {
            class_4597 consumers;
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null || mc.field_1773 == null) {
                return;
            }
            if (mc.field_1690.field_1842 && !HudConfig.INSTANCE.subtitlesVisibleInF1) {
                return;
            }
            TrackState state = this.client.getState();
            if (!HudConfig.INSTANCE.subtitlesEnabled || !"WORLD_3D".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode) && !"WORLD_BLOCK".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode) && !"WORLD_SURFACE".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode)) {
                return;
            }
            boolean hasLiveBubbles = false;
            for (SubtitleBubble b : this.lyricsManager.getActiveBubbles()) {
                if (b.isLiveCaption) {
                    hasLiveBubbles = true;
                    break;
                }
            }
            if ((!state.isActive() || "stopped".equalsIgnoreCase(state.status())) && !hasLiveBubbles) {
                return;
            }
            int trackOffset = state.isActive() ? HudConfig.INSTANCE.getTrackSyncOffset(state.artist(), state.title()) : 0;
            long currentPosMs = state.isActive() ? Math.max(0L, state.getInterpolatedPositionMs() + (long)HudConfig.INSTANCE.subtitlesOffsetMs + (long)trackOffset + LyricsManager.PERCEPTUAL_LEAD_MS) : 0L;
            long now = System.currentTimeMillis();
            class_4587 matrices = context.matrices();
            Object object = consumers = context.consumers() != null ? context.consumers() : mc.method_22940().method_23000();
            if (matrices == null || consumers == null) {
                return;
            }
            class_4184 camera = mc.field_1773.method_19418();
            class_243 cameraPos = camera.method_71156();
            class_327 textRenderer = mc.field_1772;
            for (SubtitleBubble bubble : this.lyricsManager.getActiveBubbles()) {
                if (bubble.worldPos == null) continue;
                float overallAlpha = bubble.getOverallAlpha(currentPosMs, now);
                if (overallAlpha <= 0.02f) continue;
                float baseScale = (bubble.isSurfaceAttached ? 0.03f : 0.035f) * HudConfig.INSTANCE.subtitlesScale;
                float animScale = bubble.getScale(now);
                matrices.method_22903();
                matrices.method_46416((float)(bubble.worldPos.field_1352 - cameraPos.field_1352), (float)(bubble.worldPos.field_1351 - cameraPos.field_1351) + bubble.getExitOffsetY(currentPosMs) * 0.02f, (float)(bubble.worldPos.field_1350 - cameraPos.field_1350));
                if (bubble.worldRot != null) {
                    matrices.method_22907((Quaternionfc)bubble.worldRot);
                }
                matrices.method_22905(-baseScale, -baseScale, baseScale);
                matrices.method_22905(animScale, animScale, animScale);
                double distSq = bubble.worldPos.method_1025(cameraPos);
                float proxFade = distSq < 0.64 ? (float)Math.sqrt(distSq) / 0.8f : 1.0f;
                float finalOverallAlpha = overallAlpha * Math.max(0.05f, proxFade);
                this.render3DSubtitleDoubleSided(matrices, consumers, textRenderer, bubble, currentPosMs, finalOverallAlpha);
                matrices.method_22909();
            }
        });
    }

    private void render3DSubtitleDoubleSided(class_4587 matrices, class_4597 consumers, class_327 textRenderer, SubtitleBubble bubble, long currentPosMs, float overallAlpha) {
        Vector4f origin = new Vector4f(0.0f, 0.0f, 0.0f, 1.0f).mul((Matrix4fc)matrices.method_23760().method_23761());
        Vector4f front = new Vector4f(0.0f, 0.0f, -1.0f, 1.0f).mul((Matrix4fc)matrices.method_23760().method_23761());
        boolean isFront = front.z < origin.z;
        Runnable drawFront = () -> {
            matrices.method_22903();
            this.draw3DFace(matrices, consumers, textRenderer, bubble, currentPosMs, overallAlpha);
            matrices.method_22909();
        };
        Runnable drawBack = () -> {
            matrices.method_22903();
            matrices.method_22907((Quaternionfc)new Quaternionf().rotationY((float)Math.PI));
            this.draw3DFace(matrices, consumers, textRenderer, bubble, currentPosMs, overallAlpha);
            matrices.method_22909();
        };
        if (bubble.isSurfaceAttached) {
            drawFront.run();
            drawBack.run();
            return;
        }
        if (isFront) {
            drawBack.run();
            drawFront.run();
        } else {
            drawFront.run();
            drawBack.run();
        }
    }

    private void draw3DFace(class_4587 matrices, class_4597 consumers, class_327 textRenderer, SubtitleBubble bubble, long currentPosMs, float overallAlpha) {
        LyricLine line = bubble.line;
        String text = line.text;
        int max3DWidth = 260;
        List<LyricLine.SubLine> subLines = line.getSubLines(textRenderer, max3DWidth);
        Objects.requireNonNull(textRenderer);
        int fontHeight = 9;
        int lineHeight = fontHeight + 3;
        int glyphHeight = (subLines.size() - 1) * lineHeight + fontHeight;
        int maxWidth = 0;
        for (LyricLine.SubLine sl : subLines) {
            if (sl.width() <= maxWidth) continue;
            maxWidth = sl.width();
        }
        float padX = 5.0f;
        float padY = 2.5f;
        float startY = -((float)glyphHeight / 2.0f);
        float panelX = (float)(-maxWidth) / 2.0f - padX;
        float panelY = startY - padY;
        float panelW = (float)maxWidth + padX * 2.0f;
        float panelH = (float)glyphHeight + padY * 2.0f;
        if (HudConfig.INSTANCE.subtitlesBgEnabled) {
            int bgAlpha = (int)(HudConfig.INSTANCE.subtitlesBgAlpha * overallAlpha * 230.0f);
            int bgColor = HudConfig.INSTANCE.subtitlesBgColor;
            int r = bgColor >> 16 & 0xFF;
            int g = bgColor >> 8 & 0xFF;
            int b = bgColor & 0xFF;
            LyricsRenderer.drawQuad(matrices.method_23760().method_23761(), consumers, panelX, panelY, 0.0f, panelW, panelH, r, g, b, bgAlpha, bubble.isSurfaceAttached);
            if (consumers instanceof class_4597.class_4598) {
                class_4597.class_4598 immediate = (class_4597.class_4598)consumers;
                immediate.method_22993();
            }
        }
        matrices.method_22903();
        matrices.method_46416(0.0f, 0.0f, 0.02f);
        Matrix4f textMatrix = matrices.method_23760().method_23761();
        int light = 0xF000F0;
        class_327.class_6415 layerType = HudConfig.INSTANCE.subtitlesSeeThrough || bubble.isSurfaceAttached ? class_327.class_6415.field_33994 : class_327.class_6415.field_33993;
        int textRgb = HudConfig.INSTANCE.subtitlesColor & 0xFFFFFF;
        boolean hasShadow = HudConfig.INSTANCE.subtitlesTextShadow;
        String animMode = HudConfig.INSTANCE.subtitlesAnimation;
        int activeColor = HudConfig.INSTANCE.subtitlesActiveColor;
        long now = System.currentTimeMillis();
        long effectivePosMs = bubble.isLiveCaption ? (now - bubble.spawnSystemTimeMs) : currentPosMs;
        for (int lineIdx = 0; lineIdx < subLines.size(); ++lineIdx) {
            LyricLine.SubLine sl = subLines.get(lineIdx);
            float y = startY + (float)lineIdx * (float)lineHeight;
            int charX = -sl.width() / 2;
            for (int i = sl.charStart(); i < sl.charEnd(); ++i) {
                char c = text.charAt(i);
                String charStr = String.valueOf(c);
                int charW = textRenderer.method_1727(charStr);
                float charAlpha = line.getCharAlpha(i, effectivePosMs);
                float finalAlpha = charAlpha * overallAlpha;
                if (finalAlpha >= 0.04f) {
                    float charAnimY = line.getCharAnimationOffsetY(i, effectivePosMs, now, animMode);
                    int color = line.getCharColor(i, effectivePosMs, now, animMode, textRgb, finalAlpha, activeColor);
                    float drawY = y + charAnimY;
                    if (hasShadow) {
                        int shadowAlpha = (int)(finalAlpha * 140.0f);
                        if (shadowAlpha > 3) {
                            int shadowColor = shadowAlpha << 24 | 0x05060A;
                            textRenderer.method_27521(charStr, (float)charX + 0.8f, drawY + 1.0f, shadowColor, false, textMatrix, consumers, layerType, 0, light);
                        }
                        int cr = (color >> 16 & 0xFF) * 35 / 100;
                        int cg = (color >> 8 & 0xFF) * 35 / 100;
                        int cb = (color & 0xFF) * 35 / 100;
                        int bevelAlpha = (int)(finalAlpha * 180.0f);
                        if (bevelAlpha > 3) {
                            int bevelColor = bevelAlpha << 24 | cr << 16 | cg << 8 | cb;
                            textRenderer.method_27521(charStr, (float)charX + 0.2f, drawY + 0.7f, bevelColor, false, textMatrix, consumers, layerType, 0, light);
                        }
                    }
                    textRenderer.method_27521(charStr, (float)charX, drawY, color, false, textMatrix, consumers, layerType, 0, light);
                }
                charX += charW;
            }
        }
        matrices.method_22909();
        if (consumers instanceof class_4597.class_4598) {
            class_4597.class_4598 immediate = (class_4597.class_4598)consumers;
            immediate.method_22993();
        }
    }

    private static void drawQuad(Matrix4f matrix, class_4597 consumers, float x, float y, float z, float w, float h, int r, int g, int b, int a, boolean seeThrough) {
        class_1921 layer = HudConfig.INSTANCE.subtitlesSeeThrough || seeThrough ? class_12249.method_76001() : class_12249.method_75999();
        class_4588 buffer = consumers.method_73477(layer);
        buffer.method_22918((Matrix4fc)matrix, x, y, z).method_1336(r, g, b, a).method_60803(0xF000F0);
        buffer.method_22918((Matrix4fc)matrix, x, y + h, z).method_1336(r, g, b, a).method_60803(0xF000F0);
        buffer.method_22918((Matrix4fc)matrix, x + w, y + h, z).method_1336(r, g, b, a).method_60803(0xF000F0);
        buffer.method_22918((Matrix4fc)matrix, x + w, y, z).method_1336(r, g, b, a).method_60803(0xF000F0);
    }

    private void render2D(class_332 context, class_9779 tickCounter) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        if (mc.field_1690.field_1842 && !HudConfig.INSTANCE.subtitlesVisibleInF1) {
            return;
        }
        TrackState state = this.client.getState();
        int screenWidth = mc.method_22683().method_4486();
        if (!HudConfig.INSTANCE.subtitlesEnabled || "WORLD_3D".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode) || "WORLD_BLOCK".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode) || "WORLD_SURFACE".equalsIgnoreCase(HudConfig.INSTANCE.subtitlesMode)) {
            return;
        }
        boolean hasLiveBubbles = false;
        for (SubtitleBubble b : this.lyricsManager.getActiveBubbles()) {
            if (b.isLiveCaption) {
                hasLiveBubbles = true;
                break;
            }
        }
        if ((!state.isActive() || "stopped".equalsIgnoreCase(state.status())) && !hasLiveBubbles) {
            return;
        }
        int trackOffset = state.isActive() ? HudConfig.INSTANCE.getTrackSyncOffset(state.artist(), state.title()) : 0;
        long currentPosMs = state.isActive() ? Math.max(0L, state.getInterpolatedPositionMs() + (long)HudConfig.INSTANCE.subtitlesOffsetMs + (long)trackOffset + LyricsManager.PERCEPTUAL_LEAD_MS) : 0L;
        long now = System.currentTimeMillis();
        class_327 textRenderer = mc.field_1772;
        for (SubtitleBubble bubble : this.lyricsManager.getActiveBubbles()) {
            if (bubble.worldPos != null) continue;
            float overallAlpha = bubble.getOverallAlpha(currentPosMs, now);
            if (overallAlpha <= 0.02f) continue;
            float scale = Math.max(0.2f, bubble.getScale(now) * HudConfig.INSTANCE.subtitlesScale);
            float offX = bubble.getOffsetX(now);
            float offY = bubble.getOffsetY(now);
            context.method_51448().pushMatrix();
            context.method_51448().translate(bubble.screenX + offX, bubble.screenY + offY + bubble.getExitOffsetY(currentPosMs));
            context.method_51448().scale(scale, scale);
            this.render2DBubble(context, textRenderer, bubble, currentPosMs, overallAlpha, screenWidth, now);
            context.method_51448().popMatrix();
        }
    }

    private void render2DBubble(class_332 context, class_327 textRenderer, SubtitleBubble bubble, long currentPosMs, float overallAlpha, int screenWidth, long now) {
        LyricLine line = bubble.line;
        String text = line.text;
        int maxAllowedWidth = (int)((float)screenWidth * 0.65f);
        List<LyricLine.SubLine> subLines = line.getSubLines(textRenderer, maxAllowedWidth);
        Objects.requireNonNull(textRenderer);
        int fontHeight = 9;
        int lineHeight = fontHeight + 3;
        int glyphHeight = (subLines.size() - 1) * lineHeight + fontHeight;
        int maxWidth = 0;
        for (LyricLine.SubLine sl : subLines) {
            if (sl.width() <= maxWidth) continue;
            maxWidth = sl.width();
        }
        int padX = 6;
        int padY = 3;
        if (HudConfig.INSTANCE.subtitlesBgEnabled) {
            int bgAlpha = (int)(HudConfig.INSTANCE.subtitlesBgAlpha * overallAlpha * 255.0f);
            int bgColor = bgAlpha << 24 | HudConfig.INSTANCE.subtitlesBgColor & 0xFFFFFF;
            int r = Math.max(0, Math.min(HudConfig.INSTANCE.subtitlesBgRadius, 15));
            MusicHudRenderer.renderRoundedRect(context, -padX, -padY, maxWidth + padX * 2, glyphHeight + padY * 2, r, bgColor);
        }
        int textRgb = HudConfig.INSTANCE.subtitlesColor & 0xFFFFFF;
        boolean hasShadow = HudConfig.INSTANCE.subtitlesTextShadow;
        String animMode = HudConfig.INSTANCE.subtitlesAnimation;
        int activeColor = HudConfig.INSTANCE.subtitlesActiveColor;
        long effectivePosMs = bubble.isLiveCaption ? (now - bubble.spawnSystemTimeMs) : currentPosMs;
        for (int lineIdx = 0; lineIdx < subLines.size(); ++lineIdx) {
            LyricLine.SubLine sl = subLines.get(lineIdx);
            int yOffset = lineIdx * lineHeight;
            int charX = 0;
            for (int i = sl.charStart(); i < sl.charEnd(); ++i) {
                char c = text.charAt(i);
                String charStr = String.valueOf(c);
                int charW = textRenderer.method_1727(charStr);
                float charAlpha = line.getCharAlpha(i, effectivePosMs);
                float finalAlpha = charAlpha * overallAlpha;
                if (finalAlpha >= 0.05f) {
                    float charAnimY = line.getCharAnimationOffsetY(i, effectivePosMs, now, animMode);
                    int color = line.getCharColor(i, effectivePosMs, now, animMode, textRgb, finalAlpha, activeColor);
                    int baseY = (int)((float)yOffset + charAnimY);
                    if (hasShadow) {
                        int shadowAlpha = (int)(finalAlpha * 145.0f);
                        if (shadowAlpha > 3) {
                            int shadowColor = shadowAlpha << 24 | 0x05060A;
                            context.method_51433(textRenderer, charStr, charX + 1, baseY + 1, shadowColor, false);
                        }
                        int cr = (color >> 16 & 0xFF) * 35 / 100;
                        int cg = (color >> 8 & 0xFF) * 35 / 100;
                        int cb = (color & 0xFF) * 35 / 100;
                        int bevelAlpha = (int)(finalAlpha * 180.0f);
                        if (bevelAlpha > 3) {
                            int bevelColor = bevelAlpha << 24 | cr << 16 | cg << 8 | cb;
                            context.method_51433(textRenderer, charStr, charX, baseY + 1, bevelColor, false);
                        }
                    }
                    context.method_51433(textRenderer, charStr, charX, baseY, color, false);
                }
                charX += charW;
            }
        }
    }
}

